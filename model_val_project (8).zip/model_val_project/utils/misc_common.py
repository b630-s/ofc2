import streamlit as st
def styled_header(title: str):
    st.markdown(
        f"""
        <h3 style="text-align:start; color:#a3a3c2; font-family: 'Arial', sans-serif; font-size:20px; padding:10px;">
        {title}
        </h3>
        """,
        unsafe_allow_html=True,
    )