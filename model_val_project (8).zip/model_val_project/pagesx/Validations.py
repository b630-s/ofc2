import streamlit as st
from utils.db_common import *
from streamlit_extras.bottom_container import bottom
from streamlit_extras.stylable_container import stylable_container

st.write("page1 --validations")


col = st.columns((10,2), gap='small')

with col[0]:
    st.write(" validation related details page")
    e1= st.empty()
    e2 = st.empty()
    e3 = st.empty()


with col[1]:
    st.write("second col - place options/widgets etc here to navigate or work on vlaidations page.")
    if st.checkbox('Show Models'):
        with e1:
            display_table_data(Model, db)

    if st.checkbox('Show Model Validations'):
        with e2:
            display_table_data(ModelValidation, db)

    if st.checkbox('Show Findings'):
        with e3:
            display_table_data(Finding, db)

    if st.checkbox('Show Documents'):
        with e1:
            display_table_data(Document, db)



with bottom():
    
    with stylable_container(
        key="green_button",
        css_styles="""
             {
                background-color: #114433;
                color: cyan;
                border-radius: 2px;
                padding:5px;
            }
            """,
    ):
        c1,c2 = st.columns([0.9,0.1])
        c2.button("I'm fixed")