import streamlit as st
from database.crud import (
    get_all_findings,
    create_finding,
    get_finding,
    update_finding,
    delete_finding,
    get_all_model_validations,
)
from utils.db_common import *
import pandas as pd
from datetime import datetime


def findings_sidebar():
    st.sidebar.title("Filter Findings")

    finding_statuses = ["open", "closed", "in progress"]
    risk_categories = [
        "model",
        "operational",
        "compliance",
        "financial",
        "technical",
    ]

    selected_status = st.sidebar.selectbox("Finding Status", ["All"] + finding_statuses)
    selected_risk_category = st.sidebar.selectbox(
        "Risk Category", ["All"] + risk_categories
    )

    return selected_status, selected_risk_category


def findings_information_section(db, finding):
    with st.form("findings_information_form"):
        st.markdown("#### Finding Information")

        col1, col2 = st.columns(2)
        with col1:
            finding_type = st.selectbox(
                "Finding Type",
                ["numeric", "text"],
                index=["numeric", "text"].index(finding.finding_type),
            )
            finding_value = st.text_area(
                "Finding Value", value=finding.finding_value or ""
            )
            finding_status = st.selectbox(
                "Finding Status",
                ["open", "closed", "in progress"],
                index=["open", "closed", "in progress"].index(finding.finding_status),
            )
        with col2:
            risk_category = st.selectbox(
                "Risk Category",
                ["model", "operational", "compliance", "financial", "technical"],
                index=(
                    [
                        "model",
                        "operational",
                        "compliance",
                        "financial",
                        "technical",
                    ].index(finding.risk_category)
                    if finding.risk_category
                    else 0
                ),
            )
            risk_description = st.text_area(
                "Risk Description", value=finding.risk_description or ""
            )
            risk_score = st.number_input(
                "Risk Score", value=finding.risk_score or 0, min_value=0, max_value=100
            )
            mitigation_plan = st.text_area(
                "Mitigation Plan", value=finding.mitigation_plan or ""
            )
            assessment_status = st.selectbox(
                "Assessment Status",
                ["open", "mitigated", "closed"],
                index=(
                    ["open", "mitigated", "closed"].index(finding.assessment_status)
                    if finding.assessment_status
                    else 0
                ),
            )

        finding_comments = st.text_area(
            "Additional Comments", value=finding.finding_comments or ""
        )

        submit_button = st.form_submit_button("Update Finding Information")
        if submit_button:
            update_data = {
                "finding_type": finding_type,
                "finding_value": finding_value,
                "finding_status": finding_status,
                "risk_category": risk_category,
                "risk_description": risk_description,
                "risk_score": risk_score,
                "mitigation_plan": mitigation_plan,
                "assessment_status": assessment_status,
                "finding_comments": finding_comments,
            }
            update_finding(db, finding.finding_id, update_data)
            st.success("Finding Information updated successfully.")


def display_findings_table(findings):
    st.write("### Findings Overview")
    df = pd.DataFrame(
        [
            {
                "Finding ID": finding.finding_id,
                "Finding Type": finding.finding_type,
                "Finding Value": finding.finding_value,
                "Status": finding.finding_status,
                "Risk Category": finding.risk_category,
                "Risk Score": finding.risk_score,
                "Assessment Status": finding.assessment_status,
            }
            for finding in findings
        ]
    )
    st.dataframe(df)


def findings_page(db):
    # st.title("Findings Management")

    # Sidebar Filters
    selected_status, selected_risk_category = findings_sidebar()

    # Fetch and filter findings
    all_findings = get_all_findings(db)
    filtered_findings = [
        finding
        for finding in all_findings
        if (selected_status == "All" or finding.finding_status == selected_status)
        and (
            selected_risk_category == "All"
            or finding.risk_category == selected_risk_category
        )
    ]

    if "active_finding_id" in st.session_state.keys():
        active_finding = get_finding(db, st.session_state["active_finding_id"])
        if active_finding:
            findings_information_section(db, active_finding)
        else:
            st.error("Finding not found.")
    else:
        display_findings_table(filtered_findings)

    if st.sidebar.button("Add New Finding"):
        all_validations = get_all_model_validations(db)
        validation_options = {v.validation_id: v.validation_name for v in all_validations}
        if not validation_options:
            st.warning("No validations available. Please add validations before creating findings.")
            return
        
        with st.form("add_finding_form"):
            active_validation_id = ""
            st.markdown("#### Add New Finding")
            
            if "active_validation_id" in st.session_state:

                selected_validation_id = st.session_state["active_validation_id"]

            selected_validation_id = st.selectbox(
                "Select Validation",
                options=list(validation_options.keys()),
                format_func=lambda v_id: f"{validation_options[v_id]} (ID: {v_id})",
                index=list(validation_options.keys()).index(st.session_state["active_validation_id"])
                if "active_validation_id" in st.session_state and st.session_state["active_validation_id"] in validation_options
                else 0,
            )
            finding_type = st.selectbox("Finding Type", ["numeric", "text"])
            finding_value = st.text_area("Finding Value")
            finding_status = st.selectbox(
                "Finding Status", ["open", "closed", "in progress"]
            )
            risk_category = st.selectbox(
                "Risk Category",
                ["model", "operational", "compliance", "financial", "technical"],
            )
            risk_description = st.text_area("Risk Description")
            risk_score = st.number_input("Risk Score", min_value=0, max_value=100)
            mitigation_plan = st.text_area("Mitigation Plan")
            assessment_status = st.selectbox(
                "Assessment Status", ["open", "mitigated", "closed"]
            )
            finding_comments = st.text_area("Comments")

            submit_button = st.form_submit_button("Create Finding")
            if submit_button:
                new_finding_data = {
                    "validation_id": selected_validation_id,
                    "finding_type": finding_type,
                    "finding_value": finding_value,
                    "finding_status": finding_status,
                    "risk_category": risk_category,
                    "risk_description": risk_description,
                    "risk_score": risk_score,
                    "mitigation_plan": mitigation_plan,
                    "assessment_status": assessment_status,
                    "finding_comments": finding_comments,
                }
                create_finding(db, new_finding_data)
                st.success("New Finding created successfully!")


def load_findings(db):
    findings_page(db)
