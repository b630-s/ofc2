# Architecture

## Purpose

DCX is being prototyped as a portable, sovereign-ready lakehouse platform that can run across public cloud and on-prem Kubernetes environments without redesigning the data platform layer for each provider.

The current implementation in this repository is an AWS prototype on EKS, but the design intent is broader:

- keep Kubernetes as the primary control surface
- keep the data plane based on open components
- keep workload code portable across EKS, AKS, GKE, OpenShift, and on-prem Kubernetes
- isolate cloud-specific behavior to the infrastructure boundary and deployment wiring

This document is the current architecture source of truth for the repository. Material that used to live in `docs/decisions.md` and `docs/portability-notes.md` is folded into this document so design rationale and implementation details stay together.

## Architectural Goals

The current design is optimized around a few deliberate goals:

### 1. Portability Above Kubernetes

The platform should not need a redesign when moving between AWS, Azure, GCP, OpenShift, or on-prem Kubernetes. Infrastructure adapters can change, but the platform and workload layers should remain structurally the same.

### 2. Open Components In The Data Plane

The committed current stack uses upstream or open-source building blocks:

- Apache Kafka for ingestion
- Apache Spark for compute
- Apache Airflow OSS for orchestration
- Polaris for Iceberg catalog services
- Apache Iceberg for the table format
- Prometheus and Grafana for observability

Flink remains aligned with the long-term direction, but it is intentionally deferred from the current committed AWS scope.

### 3. Kubernetes-Native Runtime Model

The platform uses Kubernetes namespaces, service accounts, operators, Helm deployments, and Kubernetes APIs as the main operational model rather than cloud-specific orchestration services.

### 4. Cloud Coupling Only At The Infra Boundary

For the AWS prototype, acceptable coupling is limited to:

- EKS for the managed Kubernetes control plane
- EC2 for worker compute
- VPC, subnets, and NAT for networking
- EBS through the EBS CSI driver for persistent volumes
- S3 for the current object store

The platform above Kubernetes should not need to know it is running on AWS.

### 5. Portable Workload Identity And Storage Contracts

Application code should not call AWS control-plane APIs as part of its normal behavior. The workloads are expected to interact with:

- Kubernetes-native service account identity
- S3-compatible object storage configuration
- Polaris and Iceberg interfaces

On EKS, IRSA is acceptable as the AWS implementation detail behind Kubernetes service-account identity, but the application contract remains Kubernetes plus object-store and catalog configuration rather than direct AWS SDK coupling.

## Layered Platform Model

The repository currently implements four layers:

### 1. Infrastructure Layer

Provides:

- VPC and subnet layout
- private routing and NAT
- EKS control plane
- managed node groups
- EBS CSI integration
- S3 bucket access path and workload IAM roles

### 2. Kubernetes Platform Layer

Provides:

- namespaces
- shared service accounts and RBAC
- Spark Operator
- Strimzi
- Airflow
- Polaris
- Prometheus and Grafana
- optional ingress-nginx

### 3. Data Platform Layer

Provides:

- Kafka cluster and topics
- Spark execution environment
- Airflow orchestration baseline
- Polaris catalog bootstrap
- Iceberg table path
- S3-backed storage integration

### 4. Workload Layer

Provides:

- the reference orders pipeline
- Spark jobs and SparkApplication manifests
- sample Kafka ingestion data
- runtime secrets for shared Polaris access

## Repository Deployment Shape

The current repository is organized around one AWS-focused prototype implementation:

- `infra/aws-proto/`
  Terraform and helper scripts for AWS network, EKS, IAM, and S3 wiring.
- `platform/`
  Shared Kubernetes manifests, Helm values, and deployment scripts for the platform baseline.
- `reference-workloads/`
  Example workloads that validate the platform end to end.

This is intentionally practical rather than abstract. The Terraform layout is flattened into one AWS-specific folder because the current implementation is explicitly AWS-focused and easier to operate that way during the prototype window.

## Infrastructure Architecture

### Current Environment And Naming

The current prototype values in `infra/aws-proto/terraform.tfvars` define the active environment shape:

- project name: `dc-platform-bss`
- environment: `proto`
- AWS region: `us-east-1`
- EKS cluster name: `dc-platform-bss-eks-proto`

Many resource names follow the general pattern:

- `${project_name}-${environment}-...`

Some names are explicitly fixed in `terraform.tfvars`, especially:

- cluster name
- IAM role names
- lakehouse bucket name

The intent is to keep operator-facing names stable and easy to trace during the prototype.

### Network Topology

The AWS network layer is deliberately small and explicit:

- one VPC
- two public subnets
- two private subnets
- two availability zones
- DNS support and DNS hostnames enabled
- one NAT gateway

Current subnet purpose:

- public subnets support load balancer attachment paths where needed
- private subnets host the EKS worker nodes

The EKS cluster itself uses the private subnets. The subnets are tagged so Kubernetes can distinguish external and internal load balancer targets.

Current rationale:

- this is the smallest practical EKS shape that still spans two AZs
- it keeps cost and troubleshooting complexity lower than a multi-NAT or more segmented layout
- it gives enough separation for a prototype that still wants realistic cluster behavior

Current tradeoff:

- a single NAT gateway is cheaper and simpler, but it is not the final highly available production posture

### EKS Control Plane

The repository provisions one EKS cluster using the `terraform-aws-modules/eks/aws` module.

Current characteristics:

- Kubernetes version `1.34`
- public cluster endpoint access enabled
- IRSA enabled
- cluster creator admin permissions enabled
- control plane logs enabled for:
  - `api`
  - `audit`
  - `authenticator`
  - `controllerManager`
  - `scheduler`

Current rationale:

- EKS removes most control-plane operations from the prototype scope
- public endpoint access simplifies early operator access from an EC2 jump box or CloudShell
- control-plane logs improve prototype debugging and validation

### Managed Node Groups

The cluster intentionally separates infrastructure concerns with two managed node groups:

#### Core Node Group

Current default shape:

- instance type: `t3.medium`
- desired size: `2`
- min size: `2`
- max size: `2`
- root disk: `50 GiB`
- labels:
  - `NodeGroupType=core`
  - `WorkloadClass=platform`

This node group is intended to host shared platform services such as:

- Spark Operator
- Airflow control-plane components
- Polaris
- Prometheus and Grafana

#### Workload Node Group

Current default shape:

- instance type: `t3.medium`
- desired size: `2`
- min size: `2`
- max size: `3`
- root disk: `50 GiB`
- labels:
  - `NodeGroupType=workload`
  - `WorkloadClass=tenant`

This node group is intended to host tenant-facing or data-path workloads such as:

- Kafka broker pods
- Spark drivers and executors
- later workload-specific runtime pods

#### Scheduling Rationale

The core/workload split is one of the most important current design choices.

Reasons:

- shared platform services should not compete directly with tenant or data-processing workloads
- a dedicated core pool makes operator troubleshooting easier
- a dedicated workload pool provides a clean future path for quota, autoscaling, taints, and tenancy controls

Current deliberate restraint:

- the repository uses labels and node selectors today
- it does not rely heavily on taints yet

Reason:

- labels give safe first-order separation without risking accidental scheduling failures for add-ons and early platform components

### Add-Ons And Storage Primitives

The infrastructure layer enables the core EKS add-ons:

- CoreDNS
- kube-proxy
- VPC CNI

It also installs the AWS EBS CSI add-on separately and wires it to a dedicated IRSA role.

Current rationale:

- EBS CSI is required for PVC-backed stateful components in the current platform shape
- keeping it separate makes the cloud storage boundary explicit

### Object Storage Path

The current AWS prototype uses Amazon S3 as the lakehouse object store.

Current implementation:

- the deploy script checks or creates a shared lakehouse bucket
- the deploy workflow applies bucket hardening settings such as AES256 encryption, versioning, and public-access blocking when it creates or normalizes the bucket
- a private S3 gateway endpoint is attached to the private route tables

Current rationale:

- S3 is the agreed object store for the current AWS phase
- the S3 gateway endpoint prevents node-to-S3 traffic from relying on the NAT gateway
- the bucket remains usable through a portable S3-compatible interface model for Spark, Airflow, and Polaris

Important boundary:

- the platform treats object storage as an abstraction
- the current implementation happens to back that abstraction with S3
- later environments can substitute MinIO, Ceph, or another S3-compatible store without redesigning the platform layer

### IAM And Identity Architecture

The AWS prototype uses a mix of shared infra roles and workload-scoped IRSA roles.

Current named roles:

- `dc-platform-bss-eks-cluster-role`
- `dc-platform-bss-eks-node-role`
- `dc-platform-bss-ebs-csi-role`
- `dc-platform-bss-polaris-s3-role`
- `dc-platform-bss-spark-s3-role`
- `dc-platform-bss-airflow-s3-role`

Current model:

- the cluster role and node role are shared infra roles
- EBS CSI has its own IRSA role
- Polaris, Spark, and Airflow each get their own S3 access role

The corresponding Kubernetes service accounts are:

- `spark/spark-sa`
- `airflow/airflow-sa`
- `polaris/polaris-sa`

The platform deployment script annotates those service accounts with their IAM role ARNs after resolving outputs from Terraform or reading operator-provided environment variables.

Current rationale:

- service-level role separation is a practical compromise between portability and least privilege
- it keeps runtime identity attached to Kubernetes service accounts
- it allows tighter policy scoping later without changing the workload contract

Important implementation detail:

- the deploy script treats several IAM roles and the lakehouse bucket as externally managed shared resources
- it checks whether they exist and creates them if missing
- Terraform references them, but Terraform destroy does not remove them

Reason:

- that keeps destroy safer for shared resources
- it allows a pre-created admin-owned setup while still supporting a self-bootstrapping prototype workflow

## Platform Architecture

### Namespace Layout

The platform baseline creates dedicated namespaces for major concerns:

- `platform-system`
- `monitoring`
- `kafka`
- `spark`
- `airflow`
- `polaris`
- `ingress-nginx`

Current rationale:

- this keeps platform components isolated by concern
- it gives a clear path for later namespace-level RBAC, quotas, and tenancy policies
- it keeps troubleshooting clearer than one large shared namespace

### Deployment Model

The main deployment script is `platform/scripts/03-0-deploy-platform.sh`.

It currently performs these stages:

1. preflight checks for `kubectl`, Helm, cluster connectivity, and required role ARNs
2. namespace and shared service-account setup
3. service-account annotation for IRSA
4. Helm repository configuration
5. installation of shared platform services

Pinned chart versions are part of the design:

- Airflow `1.20.0`
- Spark Operator `2.4.0`
- Strimzi `0.51.0`
- ingress-nginx `4.14.1`
- kube-prometheus-stack `80.13.3`
- Polaris `1.3.0-incubating`

Current rationale:

- prototype validation should be reproducible
- upstream chart drift should not change behavior silently
- operator and CRD behavior is version-sensitive, especially for Strimzi and Spark

### Shared Service Accounts And RBAC

The platform owns the primary runtime service accounts rather than letting Helm charts create their own.

Current service-account design:

- `spark-sa` in `spark`
- `airflow-sa` in `airflow`
- `polaris-sa` in `polaris`

Current RBAC scope:

- Spark receives namespaced rights needed to create and manage runtime resources such as pods, services, configmaps, and PVCs
- Airflow receives namespaced rights needed to inspect events and pod execution behavior
- Polaris currently relies on its service account primarily for IRSA-backed object-store access rather than expanded custom RBAC

Current rationale:

- the repository keeps identity and cloud role binding under explicit platform control
- this avoids hidden chart-generated service-account assumptions
- it is a cleaner base for later hardening

### Spark Platform Shape

Spark is represented by two pieces:

- the Spark Operator installed in `platform-system`
- Spark jobs executed in the `spark` namespace

Current implementation details:

- the operator is pinned to the core node group
- `sparkJobNamespace` is `spark`
- operator metrics and webhook are enabled
- the Spark service account is pre-created and reused

Current rationale:

- the operator is control-plane infrastructure, so it belongs on the core node group
- actual drivers and executors should remain free to run in the workload area
- this separation matches the core/workload node-group model

### Kafka Platform Shape

Kafka is deployed through Strimzi and then instantiated as a shared in-cluster Kafka cluster.

Current implementation details:

- Strimzi operator runs from the platform deployment
- the shared Kafka cluster is `reference-kafka`
- KRaft mode is enabled
- node pools are enabled
- only internal listeners are exposed:
  - plain on `9092`
  - TLS on `9093`
- broker replication defaults are currently `1`
- two Kafka node pools are defined:
  - `broker`
    - `1` replica
    - `20 GiB` persistent claim
    - scheduled to nodes labeled `NodeGroupType=workload`
  - `controller`
    - `1` replica
    - `10 GiB` persistent claim with shared KRaft metadata storage
    - scheduled to nodes labeled `NodeGroupType=workload`

Current rationale:

- the current Kafka shape is intentionally small and internal-only
- it is enough to validate the event-ingestion path without introducing external exposure complexity
- scheduling brokers to the workload pool preserves the core pool for shared platform control-plane components
- the separate controller node pool makes the KRaft metadata role explicit rather than collapsing controller and broker concerns into one pool

Current tradeoff:

- single-broker and replication-factor-1 settings are prototype-only choices, not production posture

### Airflow Platform Shape

Airflow is currently deployed with the KubernetesExecutor and an in-cluster PostgreSQL database.

Current implementation details:

- executor: `KubernetesExecutor`
- in-cluster PostgreSQL enabled through the chart
- Redis disabled
- Airflow control-plane services pinned to the core node group, including:
  - API server
  - scheduler
  - dagProcessor
  - triggerer
  - webserver
- Airflow uses the shared `airflow-sa`
- metadata persistence uses a PVC with the configured platform storage class
- remote logs are not yet shipped to object storage
- ingress is disabled
- the webserver service is `ClusterIP`

Current rationale:

- KubernetesExecutor fits the Kubernetes-native operating model
- an in-cluster PostgreSQL instance is the simplest correct portable choice for this prototype
- this keeps Airflow deployable on managed cloud Kubernetes and on-prem Kubernetes without immediately taking a dependency on a cloud-managed database

Current tradeoffs:

- in-cluster PostgreSQL is not the final production posture
- pod-local logs are operationally simple but should later move to S3-compatible remote logging

### Polaris Platform Shape

Polaris is a required part of the current design rather than an optional add-on.

Current implementation details:

- Polaris is installed from the official Apache Helm chart
- it uses the shared `polaris-sa`
- runtime persistence is configured as `relational-jdbc`
- the repository provisions an in-cluster PostgreSQL backing store for Polaris metadata
- a `polaris-persistence` Kubernetes secret supplies the JDBC connection and credentials
- service type is `ClusterIP`
- management service is headless
- ingress is disabled
- metrics and ServiceMonitor integration are enabled
- Polaris is scheduled onto the core node group
- internal authentication is currently enabled
- `ALLOW_SETTING_S3_ENDPOINTS` is enabled in advanced config

Current rationale:

- the architecture requires an open Iceberg catalog service
- Polaris gives an open control point for catalog and namespace management
- in-cluster PostgreSQL keeps the initial deployment portable and self-contained

Current tradeoffs and follow-up:

- the catalog bootstrap is a separate post-install step
- internal-auth defaults and generated secrets are acceptable for the prototype but not a hardened environment
- later hardening should move toward managed secrets and more deliberate authentication posture

### Monitoring And Ingress

Monitoring is part of the required platform baseline. Ingress is optional.

Current monitoring implementation:

- kube-prometheus-stack is installed by default
- Grafana is enabled
- Alertmanager is disabled
- Prometheus persistence is enabled with a `20 GiB` PVC
- retention is `7d`
- monitoring control-plane components are pinned to the core node group
- Grafana persistence is disabled

Current rationale:

- the prototype needs visibility into cluster health, operator health, and workload execution before it can be considered valid
- monitoring is more important to the baseline than public ingress exposure

Ingress current posture:

- ingress-nginx exists as an optional installation path
- it is disabled by default

Reason:

- ingress exposure varies more by environment than the core platform services do

## Workload Architecture

### Reference Orders Workload

The current repository includes one canonical reference workload under `reference-workloads/orders-reference/`.

The workload demonstrates the intended staged lakehouse path:

1. ingest events into Kafka
2. read Kafka into raw parquet
3. transform raw parquet into curated parquet
4. write curated data into Iceberg through Polaris

Current assets include:

- baked-in Spark job code
- SparkApplication manifests
- helper scripts for data load, validation, and secret creation
- a repo-owned Spark runtime image build

### Spark Image Pattern

The current image strategy is intentionally simple:

- base image: `spark:3.5.3-python3`
- repo-owned job code is baked into the image
- common Spark Kafka and Iceberg dependencies are resolved at build time
- AWS-specific runtime pieces remain in SparkApplication runtime configuration rather than the base image

Current rationale:

- this is more production-like than ConfigMap-mounted code
- it keeps job packaging repeatable
- it still preserves portability by avoiding a hard-coded cloud-specific base image

### Shared Catalog Versus Workload-Owned Tables

The platform layer and workload layer intentionally split responsibility:

- the platform bootstrap creates shared Polaris structures such as the `reference` catalog, `bronze` and `silver` namespaces, and the Spark principal wiring
- the workload creates its own use-case-specific tables during runtime

Current rationale:

- shared catalog structure belongs to the platform
- business table semantics belong to the workload
- this is a cleaner separation for multi-tenant evolution later

### Current Runtime Flow

The current end-to-end reference sequence is:

1. deploy AWS infrastructure
2. connect `kubectl` to the EKS cluster
3. deploy the shared platform baseline
4. deploy Kafka resources
5. bootstrap Polaris admin
6. bootstrap the shared reference catalog and Spark principal
7. load sample order events into Kafka
8. verify Kafka ingestion
9. create the runtime secret for the Spark-side Polaris principal
10. submit the three staged Spark jobs

This is the current proof that the repo can support a full path from event ingestion through open-table output.

## Portability And Design Boundaries

The architecture currently draws the portability line like this:

### AWS-Specific Today

- Terraform under `infra/aws-proto/`
- VPC, NAT, subnet, and route-table behavior
- EKS as the cluster implementation
- EBS CSI as the storage class implementation
- S3 as the concrete object store
- IRSA as the AWS mechanism behind service-account-linked cloud access

### Intended To Stay Portable

- namespace layout
- service-account model
- Helm-driven platform installs
- Spark, Airflow, Kafka, Polaris, Iceberg stack
- workload packaging and execution pattern
- S3-compatible storage contract used by workloads
- catalog and table-management model

This is the key design promise of the repository:

- infrastructure adapters can change
- the platform and workload architecture should not need a redesign

## Current Limitations And Follow-Ups

The current implementation is intentionally prototype-biased. The main known limitations are:

- Airflow still uses an in-cluster PostgreSQL instance rather than an external production-grade metadata database
- Airflow logs are still pod-local rather than remote-shipped to S3-compatible storage
- Kafka is currently a small single-broker internal-only cluster
- ingress exposure is not part of the default baseline
- Polaris authentication and secret handling are still prototype-grade
- the external shared bucket and IAM roles are intentionally outside normal Terraform destroy ownership
- Flink is not yet part of the committed implementation

These are not contradictions in the architecture. They are deliberate sequencing choices so the prototype can validate the portable platform shape first, then harden specific parts later.

## Design Outcome

If the current prototype succeeds, it should demonstrate all of the following:

- an AWS EKS deployment can host the full baseline platform
- the data plane can remain based on open components
- the platform can expose a portable operational model above Kubernetes
- workloads can move through Kafka, Spark, Polaris, Iceberg, and S3-compatible storage without embedding cloud-specific control-plane logic
- future non-AWS environments should be able to reuse the same platform and workload architecture with only infrastructure substitutions
