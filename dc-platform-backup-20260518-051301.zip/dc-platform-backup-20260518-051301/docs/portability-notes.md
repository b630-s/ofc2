# Portability Notes

The portability guidance that used to live here is now consolidated into `docs/architecture.md`.

Use `docs/architecture.md` for the current explanation of:

- what is intentionally AWS-specific
- what must remain portable above Kubernetes
- why Airflow, Polaris, Spark, Kafka, and storage are wired the way they are today
- which current implementation choices are prototype shortcuts versus long-term design direction
