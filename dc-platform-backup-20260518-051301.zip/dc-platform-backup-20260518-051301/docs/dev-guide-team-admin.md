# Developer Guide For Team Admins

## Purpose

This guide is for the teammate who owns or operates the shared EKS-based platform environment and needs to onboard other developers quickly.

Use this document when you want to:

- grant teammates access to the shared EKS cluster
- keep the access model simple
- let developers inspect all namespaces, nodes, Kafka resources, Spark resources, and platform services
- get the team unblocked quickly for development

This guide assumes:

- the AWS infrastructure has already been deployed
- the platform has already been deployed
- you want a simple broad-access approach rather than fine-grained namespace RBAC

## Recommended Simple Access Model

If the goal is to get the team working quickly, the simplest approach is:

- create an EKS access entry for each teammate's IAM user or IAM role
- attach the AWS-managed EKS cluster admin access policy

That gives the teammate broad Kubernetes access across the cluster, including:

- all namespaces
- nodes
- pods
- logs
- Kafka resources
- Spark resources
- Airflow, Polaris, and monitoring resources

This is intentionally broad access. It is appropriate for a small shared prototype team, but it is not the least-privilege production model.

## Important Boundary

This access model gives teammates broad Kubernetes access to the EKS cluster.

It does **not** automatically give them full AWS account admin access.

They still need enough AWS IAM permission on their own identity to:

- call EKS APIs
- run `aws eks update-kubeconfig`
- describe the cluster

## When This Works Best

Use this model when:

- the team is small
- the environment is shared
- speed matters more than strict isolation
- the main goal is to let engineers start building and debugging workloads quickly

Do not use this as the long-term access model for a larger or production-grade environment without revisiting RBAC and IAM boundaries.

## Cluster Information To Confirm First

Before granting access, confirm the cluster details you will use:

- cluster name: `dc-platform-bss-eks-proto`
- AWS region: `us-east-1`

These come from:

- `infra/aws-proto/terraform.tfvars`

## Grant Broad Cluster Access

For each teammate, you need their IAM principal ARN.

This will be one of:

- an IAM user ARN
- an IAM role ARN

Examples:

- `arn:aws:iam::<account-id>:user/<user-name>`
- `arn:aws:iam::<account-id>:role/<role-name>`

### Step 1. Create An EKS Access Entry

For an IAM user:

```bash
aws eks create-access-entry \
  --cluster-name dc-platform-bss-eks-proto \
  --principal-arn arn:aws:iam::<account-id>:user/<user-name>
```

For an IAM role:

```bash
aws eks create-access-entry \
  --cluster-name dc-platform-bss-eks-proto \
  --principal-arn arn:aws:iam::<account-id>:role/<role-name>
```

### Step 2. Attach Broad Cluster Access

Attach the AWS-managed cluster admin access policy with cluster-wide scope.

For an IAM user:

```bash
aws eks associate-access-policy \
  --cluster-name dc-platform-bss-eks-proto \
  --principal-arn arn:aws:iam::<account-id>:user/<user-name> \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy \
  --access-scope type=cluster
```

For an IAM role:

```bash
aws eks associate-access-policy \
  --cluster-name dc-platform-bss-eks-proto \
  --principal-arn arn:aws:iam::<account-id>:role/<role-name> \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy \
  --access-scope type=cluster
```

## What Teammates Should Do Next

After you grant access, the teammate should:

1. configure their own AWS credentials
2. clone the repo
3. connect their kubeconfig to the cluster
4. verify they can see the shared services

Their connect command is:

```bash
aws eks update-kubeconfig --region us-east-1 --name dc-platform-bss-eks-proto
```

Then they should verify:

```bash
kubectl get nodes
kubectl get ns
kubectl get pods -A
kubectl get kafka -n kafka
kubectl get sparkapplications -n spark
```

## What You Should Share With Them

After granting access, send teammates:

- AWS account ID
- AWS region
- EKS cluster name
- repo URL
- branch or commit to use
- lakehouse bucket name
- Polaris catalog and namespace conventions
- image registry or repository for Spark images
- the developer onboarding guide

Point them to:

- `docs/dev-guide.md`
- `docs/architecture.md`
- `SETUP_README.md`

## Quick Handoff Message Template

You can send teammates something like this:

```text
You now have access to the shared EKS prototype cluster.

Cluster:
- region: us-east-1
- cluster: dc-platform-bss-eks-proto

Connect:
aws eks update-kubeconfig --region us-east-1 --name dc-platform-bss-eks-proto

Verify:
kubectl get nodes
kubectl get ns
kubectl get pods -A
kubectl get kafka -n kafka
kubectl get sparkapplications -n spark

Start with:
- docs/dev-guide.md
- reference-workloads/orders-reference/orders-setup-readme.md
```

## Troubleshooting

### `create-access-entry` Or `associate-access-policy` Fails

Likely cause:

- your own IAM identity does not have enough EKS permissions to grant access to other principals

What that means:

- you may still be the Kubernetes cluster creator and have cluster access
- but you do not necessarily have AWS-side permission to manage EKS access entries

In that case, ask your AWS admin to run the same commands for each teammate.

### Teammate Can Log Into AWS But Cannot Use `kubectl`

Checks:

```bash
aws sts get-caller-identity
aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto
aws eks list-access-entries --cluster-name dc-platform-bss-eks-proto
```

If the access entry exists, have the teammate rerun:

```bash
aws eks update-kubeconfig --region us-east-1 --name dc-platform-bss-eks-proto
```

### Teammate Can Connect But Still Sees Authorization Errors

Check that the access policy association exists and uses cluster scope.

Useful command:

```bash
aws eks list-associated-access-policies \
  --cluster-name dc-platform-bss-eks-proto \
  --principal-arn arn:aws:iam::<account-id>:user/<user-name>
```

## Later Hardening

This guide intentionally favors speed and simplicity.

Later, if the team grows or the environment becomes more sensitive, you should move toward:

- dedicated IAM roles for teams
- reduced namespace scope
- custom Kubernetes RBAC
- separate dev and shared environments

For the current prototype, though, broad cluster access is a reasonable way to get everyone productive quickly.
