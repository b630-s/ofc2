# Decisions

The architectural decisions that used to live here are now consolidated into `docs/architecture.md`.

This avoids design drift between:

- high-level architecture
- implementation-specific decisions
- portability rationale

Use `docs/architecture.md` as the current source of truth for:

- platform principles
- AWS boundary decisions
- workload identity decisions
- object storage and catalog choices
- prototype tradeoffs and follow-ups
