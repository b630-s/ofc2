#!/usr/bin/env bash

set -euo pipefail

failure=0

POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
POLARIS_SERVICE="${POLARIS_SERVICE:-polaris}"
POLARIS_LOCAL_PORT="${POLARIS_LOCAL_PORT:-18181}"
POLARIS_BASE_URL="${POLARIS_BASE_URL:-http://127.0.0.1:${POLARIS_LOCAL_PORT}}"
POLARIS_ADMIN_CLIENT_ID="${POLARIS_ADMIN_CLIENT_ID:-}"
POLARIS_ADMIN_CLIENT_SECRET="${POLARIS_ADMIN_CLIENT_SECRET:-}"
REFERENCE_CATALOG="${REFERENCE_CATALOG:-reference}"
REFERENCE_PRINCIPAL="${REFERENCE_PRINCIPAL:-reference_spark_user}"
REFERENCE_PRINCIPAL_ROLE="${REFERENCE_PRINCIPAL_ROLE:-reference_spark_role}"
REFERENCE_CATALOG_ROLE="${REFERENCE_CATALOG_ROLE:-reference_catalog_role}"

PF_PID=""
PF_LOG=""
TOKEN=""

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[validate-polaris] %s\n' "$*"
}

show_targets() {
  cat <<EOF
[validate-polaris] Validation target values:
[validate-polaris]   POLARIS_NAMESPACE=${POLARIS_NAMESPACE}
[validate-polaris]   POLARIS_SERVICE=${POLARIS_SERVICE}
[validate-polaris]   POLARIS_BASE_URL=${POLARIS_BASE_URL}
[validate-polaris]   REFERENCE_CATALOG=${REFERENCE_CATALOG}
[validate-polaris]   REFERENCE_PRINCIPAL=${REFERENCE_PRINCIPAL}
[validate-polaris]   REFERENCE_PRINCIPAL_ROLE=${REFERENCE_PRINCIPAL_ROLE}
[validate-polaris]   REFERENCE_CATALOG_ROLE=${REFERENCE_CATALOG_ROLE}
[validate-polaris]   REFERENCE_NAMESPACES=bronze,silver
EOF
}

cleanup() {
  if [[ -n "${PF_PID}" ]]; then
    kill "${PF_PID}" >/dev/null 2>&1 || true
    wait "${PF_PID}" 2>/dev/null || true
  fi

  if [[ -n "${PF_LOG}" ]]; then
    rm -f "${PF_LOG}"
  fi
}

trap cleanup EXIT

preflight() {
  require_cmd kubectl
  require_cmd curl
  require_cmd jq

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Run platform/scripts/02-connect-cluster.sh first." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_ADMIN_CLIENT_ID}" || -z "${POLARIS_ADMIN_CLIENT_SECRET}" ]]; then
    echo "Set POLARIS_ADMIN_CLIENT_ID and POLARIS_ADMIN_CLIENT_SECRET before running this script." >&2
    exit 1
  fi
}

ensure_port_forward() {
  if curl -sf \
    -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
    -d 'grant_type=client_credentials' \
    -d 'scope=PRINCIPAL_ROLE:ALL' \
    "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" >/dev/null 2>&1; then
    log "Using existing reachable Polaris endpoint at ${POLARIS_BASE_URL}"
    return
  fi

  PF_LOG="$(mktemp)"
  log "Starting local port-forward to service/${POLARIS_SERVICE} in namespace ${POLARIS_NAMESPACE}"
  kubectl port-forward -n "${POLARIS_NAMESPACE}" "service/${POLARIS_SERVICE}" "${POLARIS_LOCAL_PORT}:8181" >"${PF_LOG}" 2>&1 &
  PF_PID="$!"

  for _ in $(seq 1 20); do
    if curl -sf \
      -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
      -d 'grant_type=client_credentials' \
      -d 'scope=PRINCIPAL_ROLE:ALL' \
      "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" >/dev/null 2>&1; then
      log "Polaris endpoint is reachable at ${POLARIS_BASE_URL}"
      return
    fi
    sleep 1
  done

  echo "Failed to reach Polaris at ${POLARIS_BASE_URL} after starting port-forward." >&2
  if [[ -f "${PF_LOG}" ]]; then
    cat "${PF_LOG}" >&2
  fi
  exit 1
}

fetch_token() {
  log "Requesting Polaris OAuth token"
  TOKEN="$(curl -sf \
    -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
    -d 'grant_type=client_credentials' \
    -d 'scope=PRINCIPAL_ROLE:ALL' \
    "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" | jq -r '.access_token')"

  if [[ -z "${TOKEN}" || "${TOKEN}" == "null" ]]; then
    echo "Failed to obtain Polaris access token." >&2
    exit 1
  fi
}

api_expect() {
  local method="$1"
  local path="$2"
  local acceptable_csv="$3"
  local body_file status

  body_file="$(mktemp)"
  status="$(curl -sS -o "${body_file}" -w '%{http_code}' \
    -X "${method}" \
    -H "Authorization: Bearer ${TOKEN}" \
    "${POLARIS_BASE_URL}${path}")"

  if [[ ",${acceptable_csv}," != *",${status},"* ]]; then
    echo "Polaris API call failed: ${method} ${path} returned HTTP ${status}" >&2
    cat "${body_file}" >&2 || true
    rm -f "${body_file}"
    exit 1
  fi

  printf '%s\n' "${body_file}"
}

check_filter() {
  local label="$1"
  local path="$2"
  local jq_filter="$3"
  local target="${4:-}"
  local body_file

  log "Checking ${label}"
  body_file="$(api_expect GET "${path}" "200")"
  if [[ -n "${target}" ]]; then
    if ! jq -e --arg target "${target}" "${jq_filter}" "${body_file}" >/dev/null 2>&1; then
      echo "${label} validation failed for endpoint ${path}." >&2
      cat "${body_file}" >&2 || true
      failure=1
    fi
  elif ! jq -e "${jq_filter}" "${body_file}" >/dev/null 2>&1; then
    echo "${label} validation failed for endpoint ${path}." >&2
    cat "${body_file}" >&2 || true
    failure=1
  fi
  rm -f "${body_file}"
}

main() {
  preflight
  show_targets
  ensure_port_forward
  fetch_token

  check_filter \
    "reference catalog exists" \
    "/api/management/v1/catalogs" \
    '.catalogs[]? | select(.name == $target)' \
    "${REFERENCE_CATALOG}"

  check_filter \
    "reference principal exists" \
    "/api/management/v1/principals" \
    '.principals[]? | select(.name == $target)' \
    "${REFERENCE_PRINCIPAL}"

  check_filter \
    "reference principal role exists" \
    "/api/management/v1/principal-roles" \
    '.roles[]? | select(.name == $target)' \
    "${REFERENCE_PRINCIPAL_ROLE}"

  check_filter \
    "reference catalog role exists" \
    "/api/management/v1/catalogs/${REFERENCE_CATALOG}/catalog-roles" \
    '.roles[]? | select(.name == $target)' \
    "${REFERENCE_CATALOG_ROLE}"

  check_filter \
    "reference principal is bound to reference principal role" \
    "/api/management/v1/principals/${REFERENCE_PRINCIPAL}/principal-roles" \
    '.roles[]? | select(.name == $target)' \
    "${REFERENCE_PRINCIPAL_ROLE}"

  check_filter \
    "reference principal role is bound to reference catalog role" \
    "/api/management/v1/principal-roles/${REFERENCE_PRINCIPAL_ROLE}/catalog-roles/${REFERENCE_CATALOG}" \
    '.roles[]? | select(.name == $target)' \
    "${REFERENCE_CATALOG_ROLE}"

  check_filter \
    "reference catalog role has CATALOG_MANAGE_CONTENT" \
    "/api/management/v1/catalogs/${REFERENCE_CATALOG}/catalog-roles/${REFERENCE_CATALOG_ROLE}/grants" \
    '.grants[]? | select(.type == "catalog" and .privilege == "CATALOG_MANAGE_CONTENT")'

  check_filter \
    "bronze namespace exists" \
    "/api/catalog/v1/${REFERENCE_CATALOG}/namespaces/bronze" \
    '.namespace[]? | select(. == "bronze")'

  check_filter \
    "silver namespace exists" \
    "/api/catalog/v1/${REFERENCE_CATALOG}/namespaces/silver" \
    '.namespace[]? | select(. == "silver")'

  if [[ "${failure}" -ne 0 ]]; then
    echo "Polaris configuration validation failed." >&2
    exit 1
  fi

  echo "Polaris configuration validation passed."
}

main "$@"
