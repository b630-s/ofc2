#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../../.." && pwd)"
WORKLOAD_ROOT="${REPO_ROOT}/reference-workloads/orders-reference"
# shellcheck source=../../scripts/lib/load-platform-config.sh
source "${WORKLOAD_ROOT}/scripts/lib/load-platform-config.sh"
load_reference_workload_config "${REPO_ROOT}" "${WORKLOAD_ROOT}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

render_check() {
  local file_path="$1"
  envsubst < "${file_path}" >/dev/null
  printf '[render-check] ok: %s\n' "${file_path#${REPO_ROOT}/}"
}

preflight() {
  require_cmd envsubst

  if [[ -z "${REFERENCE_SPARK_IMAGE:-}" ]]; then
    REFERENCE_SPARK_IMAGE="example.invalid/dc-platform-reference-spark:test"
  fi
}

main() {
  preflight

  render_check "${WORKLOAD_ROOT}/kafka/topics.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-kafka-to-raw.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-raw-to-curated.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-curated-to-iceberg.yaml"
}

main "$@"
