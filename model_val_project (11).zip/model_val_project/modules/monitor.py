import streamlit as st
from st_aggrid import AgGrid
import pandas as pd
from database.crud import (
    get_model_for_validation,
    get_all_models,
    get_all_model_validations,
    get_invocations_with_details,
    add_or_update_invocation_metrics,
)
from utils.db_common import *

from utils.misc_common import *

import pandas as pd

# import streamlit as st
import time
from sqlalchemy.orm import Session
import random
import json
import streamlit_antd_components as sac
from utils.misc_common import *


BUSINESS_LINES = ["Retail", "Finance", "Healthcare", "Manufacturing", "Technology"]
METADATA_CATEGORIES = [
    "All",
    "Binary Classification",
    "Regression",
    "Quant Metrics",
    "Financial Metrics",
]

METRICS_LIST = {
    ("Retail", "Binary Classification"): [
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score",
    ],
    ("Finance", "Quant Metrics"): ["Sharpe Ratio", "Sortino Ratio", "Beta", "Alpha"],
    ("Healthcare", "Regression"): [
        "Mean Absolute Error (MAE)",
        "Mean Squared Error (MSE)",
        "R-Squared (R²)",
    ],
    ("Technology", "All"): ["ROC AUC", "Log Loss", "Confusion Matrix"],
    ("Manufacturing", "Quant Metrics"): [
        "Volatility",
        "Value at Risk (VaR)",
        "Expected Shortfall (ES)",
    ],
}


def display_invocation_list(invocations_list):
    """
    Display a list of invocations in a Streamlit app with filtering and search capabilities.

    Args:
        invocations_list (List[Dict]): A list of invocations with details from the Model and Validation tables.
    """
    # Create a DataFrame from the invocations list
    invocations_df = pd.DataFrame(
        [
            {
                "Invocation ID": invocation["invocation_id"],
                "Timestamp": invocation["invocation_timestamp"],
                "Model Version": invocation["model_version"],
                "Metrics": invocation["metrics"],
                "Status": invocation["status"],
                "Model Name": invocation["model_name"],
                "Asset Class": invocation["asset_class"],
                "Validation Name": invocation["validation_name"],
                "Validation Date": invocation["validation_date"],
                "Validation Status": invocation["validation_status"],
            }
            for invocation in invocations_list
        ]
    )

    # Sidebar for search and filter options
    st.sidebar.header("Filter Invocations")

    # Filter options
    model_names = invocations_df["Model Name"].dropna().unique().tolist()
    validation_names = invocations_df["Validation Name"].dropna().unique().tolist()
    statuses = invocations_df["Status"].dropna().unique().tolist()

    selected_model_name = st.sidebar.selectbox(
        "Model Name", options=["All"] + model_names, key=str(random.randint(1, 1000))
    )
    selected_validation_name = st.sidebar.selectbox(
        "Validation Name",
        options=["All"] + validation_names,
        key=str(random.randint(1000, 2000)),
    )
    selected_status = st.sidebar.selectbox(
        "Status", options=["All"] + statuses, key=str(random.randint(2000, 3000))
    )
    search_text = st.sidebar.text_input(
        "Search by Invocation ID or Metrics", key=str(random.randint(3000, 4000))
    )

    # Apply filters
    if selected_model_name != "All":
        invocations_df = invocations_df[
            invocations_df["Model Name"] == selected_model_name
        ]
    if selected_validation_name != "All":
        invocations_df = invocations_df[
            invocations_df["Validation Name"] == selected_validation_name
        ]
    if selected_status != "All":
        invocations_df = invocations_df[invocations_df["Status"] == selected_status]
    if search_text:
        invocations_df = invocations_df[
            invocations_df["Invocation ID"]
            .astype(str)
            .str.contains(search_text, case=False)
            | invocations_df["Metrics"]
            .astype(str)
            .str.contains(search_text, case=False)
        ]

    # Display the filtered DataFrame in a Streamlit table
    event = st.dataframe(
        data=invocations_df,
        use_container_width=True,
        hide_index=True,
        selection_mode="single-row",
        on_select="rerun",
        key=str(random.randint(7000, 8000)),
    )

    # Handle row selection
    if len(event.selection["rows"]):
        selected_row = event.selection["rows"][0]
        invocation_id = invocations_df.iloc[selected_row]["Invocation ID"]
        st.session_state["active_invocation_id"] = invocation_id

        # Optionally display further details or trigger additional functionality
        # st.write(f"Selected Invocation ID: {invocation_id}")

def format_metrics_display(metrics):
    
    metrics_df = pd.DataFrame(metrics.items(), columns=["Metric Name", "Value"])
    return metrics_df

def update_metric_with_steps(db: Session, invocation_id: int):
    c,_ , d = st.columns([2.5, .5, 0.8])

    with d:
        actions = sac.buttons(
            [
                sac.ButtonsItem(label="Metrics"),
                sac.ButtonsItem(
                    label="Update KPIs", icon="chart-bar"
                ),  # For updating KPIs
                sac.ButtonsItem(
                    label="Load Results", icon="cloud-download"
                ),  # For loading monitoring results
                sac.ButtonsItem(
                    label="Save Results", icon="save"
                ),  # For documenting results
                sac.ButtonsItem(
                    label="Gen Report", icon="file-text"
                ),  # For generating monitoring report
            ],
            label="Actions",
            align="center",
            direction="vertical",
            size="sm",
            radius="lg",
            variant="filled",
            gap="sm",
            color="indigo",
        )
    with c:
        ec = st.empty()
    
    
    
    if actions == "Update KPIs":
        ec.empty()
        with ec.container():
            styled_header(actions)
            business_line = st.selectbox("Business Line", ["All"] + BUSINESS_LINES)

            # Step 2: Select Metadata Category
            metadata_category = st.selectbox("Metadata Category", METADATA_CATEGORIES)

            # Step 3: Filter and Select Metric
            filtered_metrics = []
            if business_line != "All":
                for key, metrics in METRICS_LIST.items():
                    if key[0] == business_line and (
                        metadata_category == "All" or key[1] == metadata_category
                    ):
                        filtered_metrics.extend(metrics)
            else:
                for key, metrics in METRICS_LIST.items():
                    if metadata_category == "All" or key[1] == metadata_category:
                        filtered_metrics.extend(metrics)

            metric_name = st.selectbox(
                " Metric",
                filtered_metrics if filtered_metrics else ["No metrics available"],
            )

            if st.button("Evaluate"):
                if metric_name != "No metrics available":
                    st.info(f"Evaluating metric '{metric_name}'... Please wait.")
                    time.sleep(3)  # Simulate delay
                    st.success("Metric evaluated successfully.")

                    updated_metrics = add_or_update_invocation_metrics(
                        db,
                        invocation_id,
                        {metric_name: 0.5},  # Assigning a sample value
                    )

                    # ec.empty()
                    ec.empty()
                    with ec.container():
                        invocation = db.query(ModelInvocation).filter(ModelInvocation.invocation_id == invocation_id).first()
                        current_metrics = json.loads(invocation.metrics) if invocation and invocation.metrics else {}

                        if current_metrics:
                            metrics_df = format_metrics_display(current_metrics)
                            st.dataframe(metrics_df, width=None, use_container_width=True)
                    
                    # st.success(
                    #     f"Metric '{metric_name}' assigned successfully with value 0.5!"
                    # )
                    # st.json(updated_metrics)
                    # actions="Metrics"

    else:
        invocation = db.query(ModelInvocation).filter(ModelInvocation.invocation_id == invocation_id).first()
        current_metrics = json.loads(invocation.metrics) if invocation and invocation.metrics else {}

        if current_metrics:
            ec.empty()
            with ec.container():
                styled_header("Metrics Details")
                metrics_df = format_metrics_display(current_metrics)
                st.dataframe(metrics_df, width=None, use_container_width=True)
        else:
            st.info("No metrics available.")


def load_monitor(model_id):
    styled_header("Monitoring Details")
    v = None
    e = st.empty()
    if "active_validation_id" in st.session_state.keys():
        v = int(st.session_state["active_validation_id"])
    if v:
        e.empty()
        with e.container():
            l = get_invocations_with_details(db, v)
            display_invocation_list(l)
            with st.expander("Monitoring Actions", expanded=True):
                update_metric_with_steps(db, v)
            # l = get_invocations_with_details(db, v)
            # display_invocation_list(l)

    else:
        st.warning(f"No Validation Selected yet!")

        # add_or_update_invocation_metrics(db, active_invocation_id)
