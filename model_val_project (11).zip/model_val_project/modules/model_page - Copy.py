import streamlit as st
from database.crud import get_all_models, create_model, get_model, update_model
from database.crud import get_all_model_validations
import pandas as pd
from utils.db_common import *
from datetime import datetime
from database.models import (
    MODEL_TYPES,
    MATERIALITY_LEVELS,
    COMPLEXITY_LEVELS,
    RISK_RATINGS,
    VALIDATION_FREQUENCIES,
    MODEL_STATUSES,
    FRAMEWORKS,
    LANGUAGES,
    INVOCATION_METHODS,
)

from streamlit_extras.stylable_container import stylable_container
def model_information_section(db, model):
    with st.form("model_information_form"):
        st.markdown("#### Model General Information")
        col1, col2 = st.columns(2)
        with col1:
            model_name = st.text_input("Model Name", value=model.model_name, max_chars=100)
            model_type = st.selectbox("Model Type", MODEL_TYPES, index=MODEL_TYPES.index(model.model_type) if model.model_type in MODEL_TYPES else 0)
            business_line = st.text_input("Business Line", value=model.business_line, max_chars=100)
            business_name = st.text_input("Business Name", value=model.business_name, max_chars=100)
        with col2:
            model_tier = st.text_input("Model Tier", value=model.model_tier)
            questionnaire_tier = st.text_input("Questionnaire Tier", value=model.questionnaire_tier)
            algorithm = st.text_input("Algorithm", value=model.algorithm, max_chars=100)
            model_developer = st.text_input("Developer/Team", value=model.model_developer, max_chars=100)

        submit_button = st.form_submit_button("Update Model Information")
        if submit_button:
            update_data = {
                "model_name": model_name,
                "model_type": model_type,
                "business_line": business_line,
                "business_name": business_name,
                "model_tier": model_tier,
                "questionnaire_tier": questionnaire_tier,
                "algorithm": algorithm,
                "model_developer": model_developer
            }
            update_model(db, model.model_id, update_data)
            st.success("Model Information updated successfully.")

def risk_and_complexity_section(db, model):
    with st.form("risk_complexity_form"):
        st.markdown("#### Risk and Complexity")
        col1, col2 = st.columns(2)
        with col1:
            materiality = st.selectbox("Materiality", MATERIALITY_LEVELS, index=MATERIALITY_LEVELS.index(model.materiality) if model.materiality in MATERIALITY_LEVELS else 0)
            complexity = st.selectbox("Complexity", COMPLEXITY_LEVELS, index=COMPLEXITY_LEVELS.index(model.complexity) if model.complexity in COMPLEXITY_LEVELS else 0)
        with col2:
            risk_rating = st.selectbox("Risk Rating", RISK_RATINGS, index=RISK_RATINGS.index(model.risk_rating) if model.risk_rating in RISK_RATINGS else 0)

        submit_button = st.form_submit_button("Update Risk and Complexity")
        if submit_button:
            update_data = {
                "materiality": materiality,
                "complexity": complexity,
                "risk_rating": risk_rating
            }
            update_model(db, model.model_id, update_data)
            st.success("Risk and Complexity updated successfully.")

def framework_and_language_section(db, model):
    with st.form("framework_language_form"):
        st.markdown("#### Framework and Language")
        col1, col2 = st.columns(2)
        with col1:
            model_framework = st.selectbox("Model Framework", FRAMEWORKS, index=FRAMEWORKS.index(model.model_framework) if model.model_framework in FRAMEWORKS else 0)
            custom_framework = st.text_input("Custom Framework", value=model.custom_framework) if model.model_framework == "custom" else ""
        with col2:
            model_language = st.selectbox("Model Language", LANGUAGES, index=LANGUAGES.index(model.model_language) if model.model_language in LANGUAGES else 0)
            custom_language = st.text_input("Custom Language", value=model.custom_language) if model.model_language == "custom" else ""

        submit_button = st.form_submit_button("Update Framework and Language")
        if submit_button:
            update_data = {
                "model_framework": model_framework,
                "custom_framework": custom_framework,
                "model_language": model_language,
                "custom_language": custom_language
            }
            update_model(db, model.model_id, update_data)
            st.success("Framework and Language updated successfully.")

def deployment_and_invocation_section(db, model):
    with st.form("deployment_invocation_form"):
        st.markdown("#### Deployment and Invocation")
        deployment_endpoint = st.text_input("Deployment Endpoint", value=model.deployment_endpoint)
        input_schema = st.text_area("Input Schema", value=model.input_schema)
        output_schema = st.text_area("Output Schema", value=model.output_schema)
        input_example = st.text_area("Input Example", value=model.input_example)
        output_example = st.text_area("Output Example", value=model.output_example)
        invocation_method = st.selectbox("Invocation Method", INVOCATION_METHODS, index=INVOCATION_METHODS.index(model.invocation_method) if model.invocation_method in INVOCATION_METHODS else 0)
        custom_invocation_method = st.text_input("Custom Invocation Method", value=model.custom_invocation_method) if model.invocation_method == "custom" else ""

        submit_button = st.form_submit_button("Update Deployment and Invocation")
        if submit_button:
            update_data = {
                "deployment_endpoint": deployment_endpoint,
                "input_schema": input_schema,
                "output_schema": output_schema,
                "input_example": input_example,
                "output_example": output_example,
                "invocation_method": invocation_method,
                "custom_invocation_method": custom_invocation_method
            }
            update_model(db, model.model_id, update_data)
            st.success("Deployment and Invocation updated successfully.")

def validation_details_section(db, model):
    with st.form("validation_details_form"):
        st.markdown("#### Validation Details")
        col1, col2 = st.columns(2)
        with col1:
            validation_frequency = st.selectbox("Validation Frequency", VALIDATION_FREQUENCIES, index=VALIDATION_FREQUENCIES.index(model.validation_frequency) if model.validation_frequency in VALIDATION_FREQUENCIES else 0)
            validation_days = st.number_input("Validation Days", value=model.validation_days or 0, min_value=0)
        with col2:
            last_validation_date = st.date_input("Last Validation Date", value=model.last_validation_date)
            next_validation_date = st.date_input("Next Validation Date", value=model.next_validation_date)

        submit_button = st.form_submit_button("Update Validation Details")
        if submit_button:
            update_data = {
                "validation_frequency": validation_frequency,
                "validation_days": validation_days,
                "last_validation_date": last_validation_date,
                "next_validation_date": next_validation_date
            }
            update_model(db, model.model_id, update_data)
            st.success("Validation Details updated successfully.")

def model_status_section(db, model):
    with st.form("model_status_form"):
        st.markdown("#### Model Status")
        model_status = st.selectbox("Model Status", MODEL_STATUSES, index=MODEL_STATUSES.index(model.model_status) if model.model_status in MODEL_STATUSES else 0)
        validation_rating = st.text_input("Validation Rating", value=model.validation_rating)

        submit_button = st.form_submit_button("Update Model Status")
        if submit_button:
            update_data = {
                "model_status": model_status,
                "validation_rating": validation_rating
            }
            update_model(db, model.model_id, update_data)
            st.success("Model Status updated successfully.")

def display_validations_for_model(db, model_id):
    # Fetch all validations for the given model ID
    validations = [v for v in get_all_model_validations(db) if v.model_id == model_id]

    if not validations:
        st.info("No validations found for this model.")
        return

    validation_data = [{
        "Validation ID": validation.validation_id,
        "Validation Name": validation.validation_name,
        "Validation Date": validation.validation_date,
        "Validator Name": validation.validator_name,
        "Status": validation.validation_status,
        "Score": validation.validation_score,
        "Comments": validation.validation_comments,
        "Validation ID": validation.validation_id,
        "Model ID": validation.model_id,
        "Validation Name": validation.validation_name,
        "Validation Date": validation.validation_date,
        "Validator Name": validation.validator_name,
        "Status": validation.validation_status,
        "Score": validation.validation_score,
        "Comments": validation.validation_comments,
        "Associated Documents": len(validation.documents),  
        "Action Plans Count": len(validation.action_plans)
    } for validation in validations]

    validations_df = pd.DataFrame(validation_data)

    # Display the table
    # st.markdown("##### Validations for Selected Model")
    st.dataframe(validations_df)



def view_edit_model(db, model_id):
    model = get_model(db, model_id)

    if not model:
        st.error("Model not found.")
        return

    st.subheader("Model Details")
    e0x=st.empty()
    
    e1x = st.empty()
    with st.sidebar:
        with stylable_container(
            key="green_button",
            css_styles="""
                {
                    background-color: #112233;
                    color: cyan;
                    border-radius: 2px;
                    padding:5px;
                }
                """,
        ):
            optx = st.radio(
                "Select a view",
                [
                    ":clipboard: Model Information",
                    ":shield: Risk and Complexity",
                    ":gear: Framework and Language",
                    ":rocket: Deployment",
                    ":mag: Validation Details",
                    ":dart: Model Status",
                ],
                #     captions = [
                #     "Basic model details and metadata.",
                #     "Assess risk levels and complexity.",
                #     "Select frameworks and languages.",
                #     "Configure deployment settings.",
                #     "Review validation and performance.",
                #     "Define and monitor model status."
                # ],
            )
        if st.checkbox("Show Related Validations"):
            with e0x:
                with st.expander("Expand to view validations", expanded=True):
                    st.markdown("<h6 style='color: #4A90E2; font-weight: bold;'>Related Validations</h6>", unsafe_allow_html=True)
                    display_validations_for_model(db, model_id)
        # Main logic to call sections based on selected option
    if optx == ":clipboard: Model Information":
        model_information_section(db,model)
    elif optx == ":shield: Risk and Complexity":
        risk_and_complexity_section(db,model)
    elif optx == ":gear: Framework and Language":
        framework_and_language_section(db,model)
    elif optx == ":rocket: Deployment":
        deployment_and_invocation_section(db,model)
    elif optx == ":mag: Validation Details":
        validation_details_section(db,model)
    elif optx == ":dart: Model Status":
        model_status_section(db,model)

     

def models_page(db):

    if "active_model_id" in st.session_state.keys():
        m = int(st.session_state["active_model_id"])
        view_edit_model(db, m)

def add_model_form(db):
    st.subheader("Add New Model")

    with st.form("add_model_form"):

        with st.container():
            st.markdown("### Model Information")
            col1, col2 = st.columns(2)
            with col1:
                model_name = st.text_input("Model Name", max_chars=100)
                model_type = st.selectbox(
                    "Model Type", ["Financial", "ML", "Statistical", "Custom"]
                )
                business_line = st.text_input("Business Line", max_chars=100)
            with col2:
                algorithm = st.text_input("Algorithm", max_chars=100)
                model_developer = st.text_input("Developer/Team", max_chars=100)

        with st.container():
            st.markdown("### Risk and Complexity")
            col1, col2 = st.columns(2)
            with col1:
                materiality = st.selectbox("Materiality", ["High", "Medium", "Low"])
                complexity = st.selectbox(
                    "Complexity", ["Simple", "Moderate", "Complex"]
                )
            with col2:
                risk_rating = st.selectbox("Risk Rating", ["Low", "Medium", "High"])

        with st.container():
            st.markdown("### Validation Details")
            col1, col2 = st.columns(2)
            with col1:
                validation_frequency = st.selectbox(
                    "Validation Frequency",
                    ["Annual", "Semi-Annual", "Quarterly", "Custom"],
                )
                last_validation_date = st.date_input(
                    "Last Validation Date", value=datetime.now()
                )
            with col2:
                next_validation_date = st.date_input(
                    "Next Validation Date", value=datetime.now()
                )
        with st.container():
            st.markdown("### Model Status")
            model_status = st.selectbox(
                "Model Status", ["Active", "Inactive", "Deprecated"]
            )

        # Submit Button
        submit_button = st.form_submit_button(label="Add Model")

        # Submit Action
        if submit_button:
            if model_name:
                new_model_data = {
                    "model_name": model_name,
                    "model_type": model_type,
                    "business_line": business_line,
                    "algorithm": algorithm,
                    "model_developer": model_developer,
                    "materiality": materiality,
                    "complexity": complexity,
                    "risk_rating": risk_rating,
                    "validation_frequency": validation_frequency,
                    "last_validation_date": last_validation_date,
                    "next_validation_date": next_validation_date,
                    "model_status": model_status,
                    "creation_date": datetime.now(),
                }

                create_model(db, new_model_data)
                st.success(f"Model '{model_name}' has been added successfully!")
            else:
                st.error("Model name is required.")
