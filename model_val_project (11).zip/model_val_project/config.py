import os
from pathlib import Path

# Base directory for document paths
BASE_DIR = Path(__file__).resolve().parent

# Database configuration
DATABASE_URL = "sqlite:///./database.db"

# Define any other configuration settings here
# For example, document paths or API keys

# Document paths
DOCUMENTS_DIR = BASE_DIR / "static" / "docs"

# Application settings
APP_TITLE = "Model Management System"
APP_DESCRIPTION = "A Streamlit application for managing models, validations, findings, and documents."

# Logging configuration (optional)
LOG_LEVEL = "DEBUG"  # Options: DEBUG, INFO, WARNING, ERROR, CRITICAL

# Other environment-specific settings
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")  # Default to 'development'

# Function to print configuration for debugging (optional)
def print_config():
    print("Configuration:")
    print(f"  Database URL: {DATABASE_URL}")
    print(f"  Documents Directory: {DOCUMENTS_DIR}")
    print(f"  Application Title: {APP_TITLE}")
    print(f"  Application Description: {APP_DESCRIPTION}")
    print(f"  Log Level: {LOG_LEVEL}")
    print(f"  Environment: {ENVIRONMENT}")

if __name__ == "__main__":
    print_config()