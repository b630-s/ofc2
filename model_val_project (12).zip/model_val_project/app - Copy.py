import streamlit as st
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import (
    Base,
    Model,
    ModelValidation,
    Finding,
    Document,
    ModelInvocation,
    ActionPlan,
)
import database.crud
from database.crud import (
    get_model_for_validation,
    get_all_models,
    get_all_model_validations,
)
from utils.db_common import *

from datetime import datetime
import pandas as pd
import altair as alt
import plotly.express as px
from streamlit_extras.bottom_container import bottom

from modules.home import load_home, display_model_list, display_validation_list
from modules.model_page import models_page
from modules.settings_page import settings_page
from modules.benchmark_page import load_overview
from modules.validation_page import validations_page
from modules.risk_tiers import load_risk_tiers
from modules.findings import load_findings
from modules.documentation import load_documentation
from modules.monitor import load_monitor
from modules.tests_pages import load_tests

from utils.misc_common import *


st.set_page_config(
    page_title="Model Validator",
    page_icon="🏂",
    layout="wide",
    initial_sidebar_state="expanded",
)

alt.themes.enable("dark")
st.markdown(
    """
    <style>
    /* padding for the Streamlit app container */
    .block-container {
        padding-top: 3rem !important;  /* Adjust top padding */
        padding-bottom: 0px !important;  /* Adjust bottom padding */
            padding-left: 10px !important;
            padding-right: 10px !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Streamlit layout
# st.title("Model Management System")

from streamlit_option_menu import option_menu

col1x, col2x, col3x = st.columns([1, 0.02, 1])
with col1x:
    # st.subheader("Model Validation and Risk Assessment")
    st.markdown(
        """
    <style>
        .main-title {

            font-size: 2rem;
            color: #4A90E2;
            font-weight: bold;
            text-align: center;
            margin-top:    -18px;
            margin-bottom: 3px;
        }
        .subtitle {
            font-family: 'Roboto', sans-serif; /* Clean sans-serif font for modernity */
            font-size: 0.9rem;
            color: #a6a6a6;
            
            text-align: center;
            margin-top: -10px;
            padding: 0px;
        }
        .title-container {
            background-color: #F5F5F5;
            padding: 1.1px;
            border-radius: 1px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
    <div >
        <div class="main-title">Model Validation and Risk Assessment</div>
        <div class="subtitle">Driving Confidence Through Robust Validation Solutions</div>
    </div>
    """,
        unsafe_allow_html=True,
    )
st.markdown(
    """
    <hr style="border: none; height: .5px; background-color: #a3a3c2;margin: 0; padding: 0;" />
    """,
    unsafe_allow_html=True
)

with col3x:
    actives_e = st.empty()

# st.subheader("Model Validation and Risk Assessment")

m = None
mn = None
v = None
vn = None


def load_actives(elem):
    global m, mn, v, vn
    if "active_model_id" in st.session_state.keys():
        m = st.session_state["active_model_id"]
    # st.write(m)
    if "active_model_name" in st.session_state.keys():
        mn = st.session_state["active_model_name"]
    # st.write(mn)
    if "active_validation_id" in st.session_state.keys():
        v = st.session_state["active_validation_id"]
        # vn  = st.session_state["active_validation_name"]
    if "active_validation_name" in st.session_state.keys():
        # v = st.session_state["active_validation_id"]
        vn = st.session_state["active_validation_name"]

    with elem:
        with st.container():
            col1xx, col3xx = st.columns([1, 1])
            with col1xx:
                # st.code("Model: ", mn, " /", m)
                st.code(f"""M:{mn}/{m}""", language="python")
            with col3xx:
                st.code(f"""V:{vn}/{v}""", language="python")
                # st.write("Validation: ", vn, " /", v)


import streamlit_antd_components as sac

import streamlit as st

st.markdown(
    """
    <style>
    .st-emotion-cache-1mi2ry5 { 
        padding: 0px; 
    }
    </style>
    """,
    unsafe_allow_html=True
)
st.sidebar.image("logo1.png")

with st.sidebar:
    # e_names = st.empty()
    load_actives(actives_e)

    # st.markdown("""
    # <style>
    # .stButton>button {
    #     width: 80px;
    #     height: 30px;
    #     font-size: 12px;
    #     padding: 0;
    #     margin: 0px;  /* Reduce margin for tighter spacing */
    #     border-radius: 3px;  /* Smaller border radius for square look */
    # }
    # </style>
    # """, unsafe_allow_html=True)
    # labels = ["Model", "Validation", "Data", "Benchmark",   "Test", "More"]

    # clicked = ''

    # for row in range(3):
    #     cols = st.columns(3, gap="small")
    #     for col, label in zip(cols, labels[row*3:(row+1)*3]):
    #         with col:
    #             if st.button(label):
    #                 clicked=label
    # st.write(clicked)


# # Display selected chips
# st.write(f"Selected sections: {chip_selection}")



col1, col2 = st.columns([0.85, 0.15])
with col1:
    model_empty = st.empty()
with col2:
    selected_menu = option_menu(
        None,
        [
            "Home",
            "Model Details",
            "Validation",
            "Risk/Tiers",
            "Findings",
            "Documentation",
            "Monitor",
            "Benchmark",
            "Tests",
        ],
        icons=[
            "house",
            "shield-check",
            "exclamation-triangle",
            "flag",
            "file-earmark",
            "activity",
            "clipboard-data",
            "bezier",
        ],
        key="menu_main",
        orientation="vertical",
        default_index=0,
        styles={
            "container": {"padding": "0!important", "background-color": "#4A90E2"},
            "icon": {"color": "orange", "font-size": "14px"},
            "nav-link": {
                "font-size": "14px",
                "text-align": "start",
                "margin": "5px",
                "padding": "5px",
                "--hover-color": "#330066",
            },
            "nav-link-selected": {"background-color": "#34568B"},
        },
    )

# model_empty = st.empty()
# if "active_model_id" in st.session_state:
with st.sidebar:
    sb_col1, sb_col2 = st.columns([1, 4])
    with sb_col1:
        st.markdown(
    """
    <style>
    div.stButton > button {
        font-size: 10px; /* Default button font size */
        background-color: #262730;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 1px 1px; /* Adjust padding for button content */
        margin: 0px; /* Remove extra margins */
        cursor: pointer;
        width: 60px; /* Set fixed width for buttons */
        text-align: center; /* Ensure text is centered */
        display: flex;
        flex-direction: column; /* Stack icon and label vertically */
        align-items: center; /* Center-align content */
        justify-content: center; /* Center the icon and label */
    }
    div.stButton > button:hover {
        background-color: #005a9e;
    }
    div.stButton > button div[data-testid="stMarkdownContainer"] > p {
        font-size: 10px !important; /* Small font size for text */
        margin: 0; /* Remove extra margins */
        padding: 0; /* Fix typo in 'padding' */
    }
    </style>
    """,
    unsafe_allow_html=True,
)
        button_data = [
    {"label": f"""\n Model""", "icon": "📊"},
    {"label": "Validation", "icon": "✅"},
    {"label": "Datasets", "icon": "📂"},
    {"label": "Risks", "icon": "📉"},
    {"label": "Performance", "icon": "📈"},
    {"label": "Documents", "icon": "📄"},
    {"label": "Benchmark", "icon": "📌"},
    {"label": "Alerts", "icon": "🔔"},
]

    # Initialize a variable to store which button was clicked
    clicked_button = None

    # Start the grid container
    st.markdown('<div class="grid-container">', unsafe_allow_html=True)

    # Render each button dynamically
    for button in button_data:
        # Use Streamlit's button for interactivity
        if st.button(f"{button['icon']} {button['label']}", key=button['label']):
            clicked_button = button['label']

    # Close the grid container
    st.markdown('</div>', unsafe_allow_html=True)

    # Display the clicked button

    with sb_col2:
        pass
if clicked_button:
    st.write(f"You clicked {clicked_button}!")
    

#     st.markdown(
#     """
#     <style>
#     .grid-container {
#         display: grid;
#         grid-template-columns: repeat(3, 1fr); /* 3 equal columns */
#         gap: 5px; /* Minimal gap between buttons */
#         justify-items: center; /* Center items in each grid cell */
#         align-items: center; /* Center items vertically */
#     }
#     .grid-container button {
#         font-size: 8px; /* Small font size */
#         background-color: #0078d7;
#         color: white;
#         border: none;
#         border-radius: 5px;
#         padding: 5px 10px; /* Adjust button size */
#         cursor: pointer;
#     }
#     .grid-container button:hover {
#         background-color: #005a9e;
#     }
#     </style>
#     """,
#     unsafe_allow_html=True,
# )

    # Define button labels
    

if selected_menu == "Home":
    # if
    sidebar_option = st.sidebar.radio(
        "Navigation",
        [
            "Model Studio",
            "Validation Studio",
            # "Add a Model",
            # "Add a Validation",
            "Settings",
        ],
        index=None,
    )

    if sidebar_option == "Model Studio":
        # st.write("again")

        # container1 = st.container()
        with model_empty.container():
            styled_header("Select a Model")
            models_list = get_all_models(db)  # Fetch all models
            display_model_list(models_list)
            load_actives(actives_e)
            # st.rerun()

    elif sidebar_option == "Validation Studio":

        validations_list = get_all_model_validations(
            db
        )  # Assuming get_all_validations() returns a list of validation objects
        # model_empty = st.empty()
        # container1 = st.container()
        with model_empty.container():
            styled_header("Load a Validation")
            display_validation_list(validations_list)
            load_actives(actives_e)

    elif sidebar_option == "Settings":

        validations_list = get_all_model_validations(
            db
        )  # Assuming get_all_validations() returns a list of validation objects
        # model_empty = st.empty()
        # container1 = st.container()
        with model_empty.container():
            st.write("## Settings")
            settings_page()
            load_actives(actives_e)

    # load_home(sidebar_option)  # Load home page content

elif selected_menu == "Model Details":
    model_empty.empty()
    with model_empty.container():
        models_page(db)

elif selected_menu == "Validation":
    model_empty.empty()
    with model_empty.container():
        validations_page(db)
    # load_validation(db)
elif selected_menu == "Risk/Tiers":
    model_empty.empty()
    with model_empty.container():
        load_risk_tiers(st.session_state["active_model_id"])
elif selected_menu == "Findings":
    model_empty.empty()
    with model_empty.container():
        load_findings(db)
elif selected_menu == "Documentation":
    model_empty.empty()
    with model_empty.container():
        load_documentation(db)
elif selected_menu == "Monitor":
    load_monitor(st.session_state["active_validation_id"])

elif selected_menu == "Benchmark":
    model_empty.empty()
    with model_empty.container():
        load_overview(db, "xyz")
elif selected_menu == "Tests":
    model_empty.empty()
    with model_empty.container():
        load_tests(db)


# if selected == "General":
# pg = st.navigation(

#     {
#         "General1": [st.Page("pages/Models.py"),st.Page("pages/Validations.py")],
#         # "General1": [],
#         "Setup": [st.Page("pages/page_2.py")],
#     }
# )
# pg.run()
# if selected == "Reviews":
#     pg = st.navigation(
#         {
#             "Something1": [st.Page("pages/page_1.py")],
#             "Whatever": [st.Page("pages/page_2.py")],
#         }
#     )
#     pg.run()
