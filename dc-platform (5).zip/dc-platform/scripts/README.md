# Scripts Guide

This folder contains the operator steps that run after AWS infrastructure is created.

## Current Run Order

1. Create AWS infrastructure:
   `../infra/aws-proto/deploy-infra.sh --apply`

2. Connect your shell to the EKS cluster:
   `./02-connect-cluster.sh`

3. Install platform services:
   `./03-deploy-platform.sh`

4. Validate the platform install:
   `./04-validate-platform.sh`

5. Deploy sample workloads later:
   `./05-deploy-workloads.sh`

6. Clean up platform services when needed:
   `./06-cleanup-platform.sh`

AWS destroy remains separate:

- `../infra/aws-proto/destroy-infra.sh`

## What Each Script Does

- `00-aws-access-smoke-test.sh`
  Creates a small AWS-only smoke environment to verify IAM and infra permissions before the main Terraform path.

- `02-connect-cluster.sh`
  Updates kubeconfig so `kubectl` and Helm point to the EKS cluster created by Terraform.

- `03-deploy-platform.sh`
  Installs namespaces, service accounts, Strimzi, Spark Operator, Airflow, Polaris, and Prometheus/Grafana.

- `04-validate-platform.sh`
  Checks that the base platform components are healthy.

- `05-deploy-workloads.sh`
  Placeholder for sample workload deployment.

- `06-cleanup-platform.sh`
  Removes platform services from Kubernetes without deleting AWS infrastructure.

## Before Running 03

Make sure `02-connect-cluster.sh` has already completed successfully.

Recommended quick check:

```bash
kubectl get nodes
kubectl get pods -n kube-system
```

## Helm Requirement

`03-deploy-platform.sh` requires Helm.

If Helm is missing in CloudShell, install it with:

```bash
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

Verify:

```bash
helm version
```

## Polaris Password

Before running `03-deploy-platform.sh`, set the Polaris database password:

```bash
export POLARIS_DB_PASSWORD='polaris'
```

For the prototype, `polaris` is acceptable. This is not production-grade.

## AWS Prototype Storage Note

The current Airflow values assume:

```text
storageClass: gp2
```

for the Airflow PostgreSQL PVC in AWS.

This is intentional for the current EKS prototype so Airflow persistence does not depend on a default StorageClass being present in the cluster.

## Typical Commands

From the repo root:

```bash
./infra/aws-proto/deploy-infra.sh --apply
./scripts/02-connect-cluster.sh
export POLARIS_DB_PASSWORD='polaris'
./scripts/03-deploy-platform.sh
./scripts/04-validate-platform.sh
```

From inside the `scripts/` folder:

```bash
./02-connect-cluster.sh
export POLARIS_DB_PASSWORD='polaris'
./03-deploy-platform.sh
./04-validate-platform.sh
```

## Notes

- `03-deploy-platform.sh` tries to resolve the Spark, Airflow, and Polaris IAM role ARNs from Terraform outputs automatically.
- If Terraform state is not available locally, export those role ARNs manually before running `03`.
- `06-cleanup-platform.sh` does not destroy AWS resources.

## Quick Verification

After `04-validate-platform.sh` passes, these are the most important checks.

Kubernetes:

```bash
kubectl get pods -n platform-system
kubectl get pods -n monitoring
kubectl get pods -n airflow
kubectl get pods -n polaris
kubectl get pvc -A
```

AWS Console:

- EKS cluster `dc-platform-bss-eks-proto` is `Active`
- EKS add-ons are healthy, especially `aws-ebs-csi-driver`
- both managed node groups exist:
  - `core`
  - `workload`
- EC2 worker nodes are running
- S3 bucket `dc-platform-bss-proto-lakehouse-790158-us-east-1` exists
- shared IAM roles exist

## Cleanup Safety

Before running cleanup or destroy, verify that `kubectl` is connected to the intended cluster:

```bash
kubectl config current-context
kubectl get nodes
```

Important:

- `06-cleanup-platform.sh` deletes resources from the **currently connected Kubernetes cluster**
- it does **not** independently verify the cluster name before deleting
- always run `02-connect-cluster.sh` first, or manually confirm the active kubeconfig context

To remove everything created by this workflow:

1. Remove platform services from the currently connected cluster:

```bash
./06-cleanup-platform.sh
```

2. Destroy Terraform-managed AWS infrastructure:

```bash
../infra/aws-proto/destroy-infra.sh
```

What is not deleted automatically:

- shared IAM roles
- external S3 bucket `dc-platform-bss-proto-lakehouse-790158-us-east-1`
