Reference tenant bundle for the shared example Spark namespace.

This bundle owns:
- the `spark` namespace used by the reference workloads
- the `spark-sa` service account
- namespace-scoped RBAC for SparkApplication runtime objects
- the `iceberg-client-config` ConfigMap used by Polaris-backed Spark Iceberg jobs

This bundle does not install the Spark Operator itself. That stays in:
- `platform/addons/spark-operator/`

It also consumes the shared Polaris-side Iceberg client template from:
- `platform/addons/polaris/iceberg-client-config.yaml`

Identity handoff:
- the current reference tenant uses the Terraform workload identity key `spark`
- `platform/scripts/20-deploy-platform.sh` annotates `spark/spark-sa` from Terraform output `workload_identities`
- this bundle's `deploy.sh` can also annotate `spark-sa` directly when Terraform output or `SPARK_S3_ROLE_ARN` is available

Typical usage:

```bash
./platform/tenants/reference/deploy.sh
```

If you need to force a manual role ARN:

```bash
export SPARK_S3_ROLE_ARN='<spark-role-arn>'
./platform/tenants/reference/deploy.sh
```

This directory is the template for future team or app tenants such as:
- `platform/tenants/team-a/`
- `platform/tenants/spark-orders/`
