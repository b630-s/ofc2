#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/aws}"
SPARK_NAMESPACE="${SPARK_NAMESPACE:-spark}"
SPARK_SERVICE_ACCOUNT="${SPARK_SERVICE_ACCOUNT:-spark-sa}"
POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
POLARIS_SERVICE="${POLARIS_SERVICE:-polaris}"
POLARIS_CATALOG_URI="${POLARIS_CATALOG_URI:-http://${POLARIS_SERVICE}.${POLARIS_NAMESPACE}.svc.cluster.local:8181/api/catalog}"
POLARIS_ADDON_DIR="${REPO_ROOT}/platform/addons/polaris"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[tenant-reference] %s\n' "$*"
}

resolve_role_arn() {
  if [[ -n "${SPARK_S3_ROLE_ARN:-}" ]]; then
    printf '%s\n' "${SPARK_S3_ROLE_ARN}"
    return 0
  fi

  if ! command -v terraform >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -json workload_identities 2>/dev/null \
    | jq -r '.spark.role_arn // empty'
}

main() {
  require_cmd kubectl
  require_cmd envsubst

  log "Applying reference tenant namespace, service account, and RBAC"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"
  kubectl apply -f "${SCRIPT_DIR}/rbac.yaml"

  log "Applying shared Iceberg client config into ${SPARK_NAMESPACE}"
  TARGET_NAMESPACE="${SPARK_NAMESPACE}" envsubst < "${POLARIS_ADDON_DIR}/iceberg-client-config.yaml" | kubectl apply -f -

  local role_arn=""
  role_arn="$(resolve_role_arn || true)"
  if [[ -n "${role_arn}" ]]; then
    log "Annotating ${SPARK_NAMESPACE}/${SPARK_SERVICE_ACCOUNT} with IAM role ${role_arn}"
    kubectl annotate serviceaccount "${SPARK_SERVICE_ACCOUNT}" \
      --namespace "${SPARK_NAMESPACE}" \
      eks.amazonaws.com/role-arn="${role_arn}" \
      --overwrite
  else
    log "No Spark role ARN resolved during tenant deploy; platform deploy can still annotate it later"
  fi
}

main "$@"
