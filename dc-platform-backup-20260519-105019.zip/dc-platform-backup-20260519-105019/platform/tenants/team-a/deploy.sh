#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/aws}"
TEAM_A_NAMESPACE="${TEAM_A_NAMESPACE:-team-a}"
TEAM_A_SERVICE_ACCOUNT="${TEAM_A_SERVICE_ACCOUNT:-spark-team-a-sa}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[tenant-team-a] %s\n' "$*"
}

resolve_role_arn() {
  if [[ -n "${TEAM_A_S3_ROLE_ARN:-}" ]]; then
    printf '%s\n' "${TEAM_A_S3_ROLE_ARN}"
    return 0
  fi

  if ! command -v terraform >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -json workload_identities 2>/dev/null \
    | jq -r '.team_a.role_arn // empty'
}

main() {
  require_cmd kubectl

  log "Applying Team A tenant namespace, service account, and RBAC"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"
  kubectl apply -f "${SCRIPT_DIR}/rbac.yaml"

  local role_arn=""
  role_arn="$(resolve_role_arn || true)"
  if [[ -n "${role_arn}" ]]; then
    log "Annotating ${TEAM_A_NAMESPACE}/${TEAM_A_SERVICE_ACCOUNT} with IAM role ${role_arn}"
    kubectl annotate serviceaccount "${TEAM_A_SERVICE_ACCOUNT}" \
      --namespace "${TEAM_A_NAMESPACE}" \
      eks.amazonaws.com/role-arn="${role_arn}" \
      --overwrite
  else
    log "No Team A role ARN resolved during tenant deploy; platform deploy can still annotate it later once Terraform output exists"
  fi
}

main "$@"
