#!/usr/bin/env bash

set -euo pipefail

failure=0
VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[validate] %s\n' "$*"
}

show_namespace_pods() {
  local namespace="$1"
  echo "Current pods in namespace ${namespace}:"
  kubectl get pods -n "${namespace}" -o wide || true
}

check_nodes() {
  log "Checking Kubernetes node readiness"
  kubectl get nodes
  if ! kubectl get nodes --no-headers | awk 'BEGIN { bad=0 } $2 != "Ready" { bad=1 } END { exit bad }'; then
    echo "Node readiness check failed." >&2
    failure=1
  fi
}

check_rollout() {
  local namespace="$1"
  local kind="$2"
  local name="$3"
  local label="$4"
  local timeout="${5:-${VALIDATION_TIMEOUT}}"

  log "Checking ${label} (${kind}/${name}) in namespace ${namespace}"

  if ! kubectl get "${kind}" "${name}" -n "${namespace}" >/dev/null 2>&1; then
    echo "${label} resource ${kind}/${name} not found in namespace ${namespace}." >&2
    show_namespace_pods "${namespace}"
    failure=1
    return
  fi

  if ! kubectl rollout status "${kind}/${name}" -n "${namespace}" --timeout="${timeout}"; then
    echo "${label} is not ready." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_condition() {
  local namespace="$1"
  local kind="$2"
  local name="$3"
  local condition="$4"
  local label="$5"
  local timeout="${6:-${VALIDATION_TIMEOUT}}"

  log "Checking ${label} (${kind}/${name}) in namespace ${namespace}"

  if ! kubectl get "${kind}" "${name}" -n "${namespace}" >/dev/null 2>&1; then
    echo "${label} resource ${kind}/${name} not found in namespace ${namespace}." >&2
    show_namespace_pods "${namespace}"
    failure=1
    return
  fi

  if ! kubectl wait "${kind}/${name}" -n "${namespace}" --for="condition=${condition}" --timeout="${timeout}" >/dev/null 2>&1; then
    echo "${label} did not reach condition ${condition}." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_resource_exists() {
  local namespace="$1"
  local kind="$2"
  local name="$3"
  local label="$4"

  log "Checking ${label} (${kind}/${name}) in namespace ${namespace}"

  if ! kubectl get "${kind}" "${name}" -n "${namespace}" >/dev/null 2>&1; then
    echo "${label} resource ${kind}/${name} not found in namespace ${namespace}." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_optional_pod_ready() {
  local namespace="$1"
  local name="$2"
  local label="$3"
  local timeout="${4:-${VALIDATION_TIMEOUT}}"

  log "Checking optional ${label} (pod/${name}) in namespace ${namespace}"

  if ! kubectl get pod "${name}" -n "${namespace}" >/dev/null 2>&1; then
    log "Optional ${label} pod/${name} not found in namespace ${namespace}; skipping"
    return
  fi

  if ! kubectl wait "pod/${name}" -n "${namespace}" --for=condition=Ready --timeout="${timeout}" >/dev/null 2>&1; then
    echo "Optional ${label} is not ready." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_pods_by_label_ready() {
  local namespace="$1"
  local selector="$2"
  local label="$3"
  local timeout="${4:-${VALIDATION_TIMEOUT}}"

  log "Checking ${label} pods in namespace ${namespace} with selector ${selector}"

  if ! kubectl get pods -n "${namespace}" -l "${selector}" --no-headers 2>/dev/null | grep -q .; then
    echo "${label} pods were not found in namespace ${namespace} with selector ${selector}." >&2
    show_namespace_pods "${namespace}"
    failure=1
    return
  fi

  if ! kubectl wait pod -n "${namespace}" -l "${selector}" --for=condition=Ready --timeout="${timeout}" >/dev/null 2>&1; then
    echo "${label} pods are not ready." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_job_complete() {
  local namespace="$1"
  local name="$2"
  local label="$3"
  local timeout="${4:-300s}"

  log "Checking ${label} (job/${name}) in namespace ${namespace}"

  if ! kubectl get job "${name}" -n "${namespace}" >/dev/null 2>&1; then
    log "${label} job/${name} not found in namespace ${namespace}; treating this as acceptable if the dependent services are already healthy"
    return
  fi

  if ! kubectl wait --namespace "${namespace}" --for=condition=complete "job/${name}" --timeout="${timeout}" >/dev/null 2>&1; then
    echo "${label} did not complete." >&2
    show_namespace_pods "${namespace}"
    failure=1
  fi
}

check_monitoring() {
  check_rollout "monitoring" "deployment" "kube-prometheus-stack-operator" "Prometheus operator"
  check_rollout "monitoring" "deployment" "kube-prometheus-stack-grafana" "Grafana"
  check_rollout "monitoring" "deployment" "kube-prometheus-stack-kube-state-metrics" "kube-state-metrics"
  check_rollout "monitoring" "statefulset" "prometheus-kube-prometheus-stack-prometheus" "Prometheus server"
}

check_metrics_server() {
  check_rollout "platform-system" "deployment" "metrics-server" "Metrics Server"
  check_condition "" "apiservice" "v1beta1.metrics.k8s.io" "Available" "Metrics API service"
}

check_airflow() {
  check_rollout "airflow" "statefulset" "airflow-postgresql" "Airflow PostgreSQL"
  check_job_complete "airflow" "airflow-run-airflow-migrations" "Airflow database migration job"
  check_rollout "airflow" "deployment" "airflow-api-server" "Airflow API server"
  check_rollout "airflow" "deployment" "airflow-scheduler" "Airflow scheduler"
  check_rollout "airflow" "deployment" "airflow-dag-processor" "Airflow DAG processor"
  check_rollout "airflow" "deployment" "airflow-statsd" "Airflow statsd"
  if kubectl get statefulset airflow-triggerer -n airflow >/dev/null 2>&1; then
    check_rollout "airflow" "statefulset" "airflow-triggerer" "Airflow triggerer"
  elif kubectl get deployment airflow-triggerer -n airflow >/dev/null 2>&1; then
    check_rollout "airflow" "deployment" "airflow-triggerer" "Airflow triggerer"
  else
    echo "Airflow triggerer resource not found as either statefulset/airflow-triggerer or deployment/airflow-triggerer in namespace airflow." >&2
    show_namespace_pods "airflow"
    failure=1
  fi
}

check_polaris() {
  check_rollout "polaris" "statefulset" "polaris-postgresql" "Polaris PostgreSQL"
  check_rollout "polaris" "deployment" "polaris" "Polaris"
}

check_kafka() {
  check_condition "${KAFKA_NAMESPACE}" "kafka" "reference-kafka" "Ready" "Kafka cluster"
  check_resource_exists "${KAFKA_NAMESPACE}" "kafkanodepool" "controller" "Kafka controller node pool"
  check_resource_exists "${KAFKA_NAMESPACE}" "kafkanodepool" "broker" "Kafka broker node pool"
  check_pods_by_label_ready "${KAFKA_NAMESPACE}" "strimzi.io/cluster=reference-kafka,strimzi.io/pool-name=controller" "Kafka controller"
  check_pods_by_label_ready "${KAFKA_NAMESPACE}" "strimzi.io/cluster=reference-kafka,strimzi.io/pool-name=broker" "Kafka broker"
  check_condition "${KAFKA_NAMESPACE}" "kafkatopic" "orders-raw" "Ready" "Kafka topic orders_raw"
  check_condition "${KAFKA_NAMESPACE}" "kafkatopic" "orders-dlq" "Ready" "Kafka topic orders_dlq"
  check_optional_pod_ready "${KAFKA_NAMESPACE}" "kafka-test-client" "Kafka test client"
}

main() {
  require_cmd kubectl

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster." >&2
    exit 1
  fi

  check_nodes
  check_rollout "platform-system" "deployment" "strimzi-cluster-operator" "Strimzi operator"
  check_rollout "platform-system" "deployment" "spark-operator-controller" "Spark operator controller"
  check_rollout "platform-system" "deployment" "spark-operator-webhook" "Spark operator webhook"
  check_monitoring
  check_metrics_server
  check_airflow
  check_polaris
  check_kafka

  if [[ "${failure}" -ne 0 ]]; then
    echo "Platform validation failed." >&2
    exit 1
  fi

  echo "Platform validation passed."
}

main "$@"
