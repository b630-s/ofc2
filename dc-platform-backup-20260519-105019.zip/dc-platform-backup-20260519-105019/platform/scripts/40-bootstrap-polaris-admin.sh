#!/usr/bin/env bash

set -euo pipefail

POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
POLARIS_REALM="${POLARIS_REALM:-POLARIS}"
POLARIS_ADMIN_CLIENT_ID="${POLARIS_ADMIN_CLIENT_ID:-}"
POLARIS_ADMIN_CLIENT_SECRET="${POLARIS_ADMIN_CLIENT_SECRET:-}"
POLARIS_PERSISTENCE_SECRET="${POLARIS_PERSISTENCE_SECRET:-polaris-persistence}"
POLARIS_ADMIN_TOOL_IMAGE="${POLARIS_ADMIN_TOOL_IMAGE:-apache/polaris-admin-tool:1.3.0-incubating}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[platform-polaris-admin] %s\n' "$*"
}

preflight() {
  require_cmd kubectl

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Run platform/scripts/aws/10-connect-cluster.sh first." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_ADMIN_CLIENT_ID}" || -z "${POLARIS_ADMIN_CLIENT_SECRET}" ]]; then
    echo "Set POLARIS_ADMIN_CLIENT_ID and POLARIS_ADMIN_CLIENT_SECRET before running this script." >&2
    exit 1
  fi

  if ! kubectl get secret "${POLARIS_PERSISTENCE_SECRET}" -n "${POLARIS_NAMESPACE}" >/dev/null 2>&1; then
    echo "Polaris persistence secret ${POLARIS_PERSISTENCE_SECRET} was not found in namespace ${POLARIS_NAMESPACE}." >&2
    exit 1
  fi
}

main() {
  preflight

  local bootstrap_credentials jdbc_url db_user db_password
  bootstrap_credentials="${POLARIS_REALM},${POLARIS_ADMIN_CLIENT_ID},${POLARIS_ADMIN_CLIENT_SECRET}"
  jdbc_url="$(kubectl get secret "${POLARIS_PERSISTENCE_SECRET}" -n "${POLARIS_NAMESPACE}" -o jsonpath='{.data.jdbcUrl}' | base64 --decode)"
  db_user="$(kubectl get secret "${POLARIS_PERSISTENCE_SECRET}" -n "${POLARIS_NAMESPACE}" -o jsonpath='{.data.username}' | base64 --decode)"
  db_password="$(kubectl get secret "${POLARIS_PERSISTENCE_SECRET}" -n "${POLARIS_NAMESPACE}" -o jsonpath='{.data.password}' | base64 --decode)"

  if kubectl get pod polaris-bootstrap -n "${POLARIS_NAMESPACE}" >/dev/null 2>&1; then
    log "Deleting existing pod/polaris-bootstrap before rerun"
    kubectl delete pod polaris-bootstrap -n "${POLARIS_NAMESPACE}" --wait=true >/dev/null
  fi

  log "Running one-off Polaris admin tool bootstrap pod against the live PostgreSQL metastore"
  kubectl run polaris-bootstrap \
    -n "${POLARIS_NAMESPACE}" \
    --image="${POLARIS_ADMIN_TOOL_IMAGE}" \
    --restart=Never \
    --rm -i \
    --env="polaris.persistence.type=relational-jdbc" \
    --env="quarkus.datasource.jdbc.url=${jdbc_url}" \
    --env="quarkus.datasource.username=${db_user}" \
    --env="quarkus.datasource.password=${db_password}" \
    -- \
    bootstrap \
    -r "${POLARIS_REALM}" \
    -c "${bootstrap_credentials}"

  echo
  echo "Polaris admin bootstrap completed."
  echo "Keep using these exports for the next step:"
  echo "export POLARIS_ADMIN_CLIENT_ID=${POLARIS_ADMIN_CLIENT_ID}"
  echo "export POLARIS_ADMIN_CLIENT_SECRET=${POLARIS_ADMIN_CLIENT_SECRET}"
  echo
  echo "Next step:"
  echo "./platform/scripts/50-bootstrap-polaris-reference.sh"
}

main "$@"
