#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"
KUBE_PROMETHEUS_STACK_CHART_VERSION="${KUBE_PROMETHEUS_STACK_CHART_VERSION:-80.13.3}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-gp2}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-monitoring] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd helm

  local monitoring_values_file
  monitoring_values_file="$(render_storage_class_template "${SCRIPT_DIR}/values.yaml")"

  log "Applying monitoring namespace"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"

  log "Installing monitoring stack into ${MONITORING_NAMESPACE}"
  helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
    --namespace "${MONITORING_NAMESPACE}" \
    --create-namespace \
    --reset-values \
    --version "${KUBE_PROMETHEUS_STACK_CHART_VERSION}" \
    --values "${monitoring_values_file}" \
    --wait \
    --timeout 15m

  rm -f "${monitoring_values_file}"
}

main "$@"
