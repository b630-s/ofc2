#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

POLARIS_CHART_VERSION="${POLARIS_CHART_VERSION:-1.3.0-incubating}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-gp2}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-polaris] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd helm

  if [[ -z "${POLARIS_DB_PASSWORD:-}" ]]; then
    echo "POLARIS_DB_PASSWORD is required to deploy Polaris." >&2
    exit 1
  fi

  local polaris_postgresql_manifest
  polaris_postgresql_manifest="$(render_storage_class_template "${SCRIPT_DIR}/postgresql.yaml")"

  log "Applying Polaris namespace and service account"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"

  log "Creating Polaris persistence secret"
  kubectl create secret generic polaris-persistence \
    --namespace polaris \
    --from-literal=jdbcUrl="jdbc:postgresql://polaris-postgresql.polaris.svc.cluster.local:5432/polaris" \
    --from-literal=username="polaris" \
    --from-literal=password="${POLARIS_DB_PASSWORD}" \
    --from-literal=POSTGRES_DB="polaris" \
    --from-literal=POSTGRES_USER="polaris" \
    --from-literal=POSTGRES_PASSWORD="${POLARIS_DB_PASSWORD}" \
    --dry-run=client \
    --output yaml \
    | kubectl apply -f -

  log "Deploying Polaris PostgreSQL backing store"
  kubectl apply -f "${polaris_postgresql_manifest}"

  kubectl rollout status statefulset/polaris-postgresql \
    --namespace polaris \
    --timeout=10m

  log "Installing Polaris into polaris namespace using IRSA via polaris-sa"
  helm upgrade --install polaris polaris/polaris \
    --namespace polaris \
    --create-namespace \
    --devel \
    --reset-values \
    --version "${POLARIS_CHART_VERSION}" \
    --values "${SCRIPT_DIR}/values.yaml" \
    --wait \
    --timeout 15m

  echo "Polaris service installed."
  echo "Catalog bootstrap is still a separate step after install."

  rm -f "${polaris_postgresql_manifest}"
}

main "$@"
