#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

AIRFLOW_CHART_VERSION="${AIRFLOW_CHART_VERSION:-1.20.0}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-gp2}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-airflow] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd helm

  local airflow_values_file
  airflow_values_file="$(render_storage_class_template "${SCRIPT_DIR}/values.yaml")"

  log "Applying airflow namespace and service account"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"

  log "Installing Airflow into airflow namespace"
  helm upgrade --install airflow apache-airflow/airflow \
    --namespace airflow \
    --create-namespace \
    --reset-values \
    --version "${AIRFLOW_CHART_VERSION}" \
    --values "${airflow_values_file}" \
    --wait \
    --timeout 15m

  rm -f "${airflow_values_file}"
}

main "$@"
