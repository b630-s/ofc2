#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
SPARK_OPERATOR_CHART_VERSION="${SPARK_OPERATOR_CHART_VERSION:-2.4.0}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-spark-operator] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  log "Installing Spark Operator into ${PLATFORM_NAMESPACE}"
  helm upgrade --install spark-operator spark-operator/spark-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${SPARK_OPERATOR_CHART_VERSION}" \
    --values "${SCRIPT_DIR}/values.yaml" \
    --wait \
    --timeout 10m
}

main "$@"
