#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
STRIMZI_CHART_VERSION="${STRIMZI_CHART_VERSION:-0.51.0}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-strimzi] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  log "Applying Kafka workload namespace"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"

  log "Installing Strimzi operator into ${PLATFORM_NAMESPACE}"
  helm upgrade --install strimzi-kafka-operator strimzi/strimzi-kafka-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${STRIMZI_CHART_VERSION}" \
    --values "${SCRIPT_DIR}/values.yaml" \
    --wait \
    --timeout 10m
}

main "$@"
