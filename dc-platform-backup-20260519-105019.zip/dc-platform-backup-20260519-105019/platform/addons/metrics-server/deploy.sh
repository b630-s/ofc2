#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
METRICS_SERVER_CHART_VERSION="${METRICS_SERVER_CHART_VERSION:-3.13.0}"

# Requires the Helm repository to be configured for standalone use:
# helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-metrics-server] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  log "Installing metrics-server into ${PLATFORM_NAMESPACE}"
  helm upgrade --install metrics-server metrics-server/metrics-server \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${METRICS_SERVER_CHART_VERSION}" \
    --values "${SCRIPT_DIR}/values.yaml" \
    --wait \
    --timeout 10m
}

main "$@"
