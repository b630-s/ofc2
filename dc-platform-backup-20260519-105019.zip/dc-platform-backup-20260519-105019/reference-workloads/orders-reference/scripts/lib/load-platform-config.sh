#!/usr/bin/env bash

load_reference_env_file() {
  local env_file="$1"
  local mode="${2:-default}"
  local line key
  local nounset_was_on=0

  [[ -f "${env_file}" ]] || return 0

  case $- in
    *u*) nounset_was_on=1 ;;
  esac

  while IFS= read -r line || [[ -n "${line}" ]]; do
    [[ -n "${line}" ]] || continue
    [[ "${line}" == \#* ]] && continue
    [[ "${line}" == *=* ]] || continue

    key="${line%%=*}"
    [[ "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue

    if [[ "${mode}" == "override" ]]; then
      if [[ -n "${REFERENCE_CONFIG_ORIGINAL_ENV[${key}]+x}" ]]; then
        continue
      fi
      set +u
      eval "export ${line}"
      if [[ "${nounset_was_on}" -eq 1 ]]; then
        set -u
      fi
      continue
    fi

    if [[ -n "${REFERENCE_CONFIG_ORIGINAL_ENV[${key}]+x}" || -n "${!key+x}" ]]; then
      continue
    fi

    set +u
    eval "export ${line}"
    if [[ "${nounset_was_on}" -eq 1 ]]; then
      set -u
    fi
  done < "${env_file}"
}

load_reference_workload_config() {
  local repo_root="$1"
  local workload_root="${2:-}"

  declare -gA REFERENCE_CONFIG_ORIGINAL_ENV=()

  while IFS='=' read -r key _; do
    [[ "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
    REFERENCE_CONFIG_ORIGINAL_ENV["${key}"]=1
  done < <(env)

  if [[ -n "${workload_root}" ]]; then
    load_reference_env_file "${repo_root}/platform/config/platform-config.env" "default"
    load_reference_env_file "${repo_root}/platform/config/platform-secrets.env" "default"
    load_reference_env_file "${workload_root}/config/platform-config.env" "default"
    load_reference_env_file "${workload_root}/config/platform-secrets.env" "default"
    load_reference_env_file "${workload_root}/config/workload-defaults.env" "default"
    load_reference_env_file "${workload_root}/config/workload.local.env" "override"
  fi
}
