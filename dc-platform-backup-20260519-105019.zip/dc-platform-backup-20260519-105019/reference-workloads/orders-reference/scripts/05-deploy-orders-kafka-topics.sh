#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
WORKLOAD_ROOT="${REPO_ROOT}/reference-workloads/orders-reference"
# shellcheck source=lib/load-platform-config.sh
source "${WORKLOAD_ROOT}/scripts/lib/load-platform-config.sh"
load_reference_workload_config "${REPO_ROOT}" "${WORKLOAD_ROOT}"

KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"
KAFKA_CLUSTER_NAME="${KAFKA_CLUSTER_NAME:-reference-kafka}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

preflight() {
  require_cmd kubectl
  require_cmd envsubst

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Run platform/scripts/aws/10-connect-cluster.sh first." >&2
    exit 1
  fi
}

main() {
  preflight
  envsubst < "${WORKLOAD_ROOT}/kafka/topics.yaml" | kubectl apply -f -
}

main "$@"
