output "vpc_id" {
  value = module.vpc.vpc_id
}

output "private_subnet_ids" {
  value = module.vpc.private_subnets
}

output "public_subnet_ids" {
  value = module.vpc.public_subnets
}

output "private_route_table_ids" {
  value = module.vpc.private_route_table_ids
}

output "s3_gateway_endpoint_id" {
  value = aws_vpc_endpoint.s3.id
}

output "lakehouse_bucket_name" {
  value = data.aws_s3_bucket.lakehouse.bucket
}

output "eks_cluster_name" {
  value = module.eks.cluster_name
}

output "eks_cluster_endpoint" {
  value = module.eks.cluster_endpoint
}

output "cluster_oidc_issuer_url" {
  value = module.eks.cluster_oidc_issuer_url
}

output "oidc_provider_arn" {
  value = module.eks.oidc_provider_arn
}

output "ebs_csi_role_arn" {
  value = data.aws_iam_role.ebs_csi.arn
}

output "workload_identities" {
  description = "Full workload identity map for platform services that bind Kubernetes service accounts to AWS roles."
  value = {
    for name, identity in local.workload_identities :
    name => {
      namespace       = identity.namespace
      service_account = identity.service_account
      role_name       = identity.role_name
      role_arn        = data.aws_iam_role.workload_identity[name].arn
    }
  }
}
