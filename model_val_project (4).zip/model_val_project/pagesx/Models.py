import streamlit as st
from utils.db_common import *
from streamlit_extras.bottom_container import bottom
from streamlit_extras.stylable_container import stylable_container
from database.crud import  get_all_models


st.write("# Models Listing")

models_list = get_all_models(db)  # Fetch all models

def display_model_list(models_list):
    global sidebar_option
    models_df = pd.DataFrame([{
        "Model ID": model.model_id,
        "Model Name": model.model_name,
        "Type": model.model_type,
        "Business Line": model.business_line,
        "Algorithm": model.algorithm,
        "Developer": model.model_developer,
        "Materiality": model.materiality,
        "Complexity": model.complexity,
        "Risk Rating": model.risk_rating,
        "Status": model.model_status,
        "Last Validation Date": model.last_validation_date,
        "Next Validation Date": model.next_validation_date
    } for model in models_list])
    
    # Add a radio button selection
    # selected_model = st.radio(
    #     "Select a Model",
    #     models_df["Model Name"].tolist(),
    #     index=0
    # )

    event = st.dataframe(data=models_df, use_container_width=True, hide_index=True, selection_mode='single-row', on_select='rerun')   
    if len(event.selection['rows']):
        selected_row = event.selection['rows'][0]
        st.write(event)
        st.write(selected_row)
        # Highlight selected model and update session state
        selected_model_id = selected_row #  models_df[models_df["Model Name"] == selected_model]["Model ID"].values[0]
        st.session_state["active_model_id"] = selected_model_id
        # st.session_state["Navigation"] = None
        # sidebar_option=None


col = st.columns((10,2), gap='small')

with col[0]:
    display_model_list(models_list)
    e1= st.empty()
    e2 = st.empty()
    e3 = st.empty()


with col[1]:
    st.write("second col - place options/widgets etc here to navigate or work on vlaidations page.")
    if st.checkbox('Show Models'):
        with e1:
            display_table_data(Model, db)

    if st.checkbox('Show Model Validations'):
        with e2:
            display_table_data(ModelValidation, db)

    if st.checkbox('Show Findings'):
        with e3:
            display_table_data(Finding, db)

    if st.checkbox('Show Documents'):
        with e1:
            display_table_data(Document, db)



with bottom():
    
    with stylable_container(
        key="green_button",
        css_styles="""
             {
                background-color: #114433;
                color: cyan;
                border-radius: 2px;
                padding:5px;
            }
            """,
    ):
        c1,c2 = st.columns([0.9,0.1])
        c2.button("I'm fixed")