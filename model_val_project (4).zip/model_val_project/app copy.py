import streamlit as st
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import (
    Base,
    Model,
    ModelValidation,
    Finding,
    Document,
    ModelInvocation,
    ActionPlan,
)
import database.crud
from datetime import datetime
import pandas as pd
import altair as alt
import plotly.express as px
from streamlit_extras.bottom_container import bottom


st.set_page_config(
    page_title="Model Validator",
    page_icon="🏂",
    layout="wide",
    initial_sidebar_state="expanded",
)

alt.themes.enable("dark")
st.markdown("""
    <style>
    /* padding for the Streamlit app container */
    .block-container {
        padding-top: 3rem !important;  /* Adjust top padding */
        padding-bottom: 0px !important;  /* Adjust bottom padding */
            padding-left: 10px !important;
            padding-right: 10px !important;
    }
    </style>
    """, unsafe_allow_html=True)

# Streamlit layout
# st.title("Model Management System")

from streamlit_option_menu import option_menu


def on_change(key):
    selection = st.session_state[key]
    # st.write(f"Selection changed to {selection}")


selected = option_menu(
    None,
    ["Overview", "Validation", "Risk/Tiers", "Findings", "Documentation", "Monitor", "Tests"],
    icons=["clipboard-data", "shield-check", "exclamation-triangle", "flag", "file-earmark", "activity", "bezier"],
    key="menu_main",
    orientation="horizontal",
    styles={
        "container": {"padding": "0!important", "background-color": "#4a90e2"},
        "icon": {"color": "orange", "font-size": "16px"},
        "nav-link": {
            "font-size": "14px",
            "text-align": "center",
            "margin": "0px",
            "--hover-color": "#eee",
        },
        "nav-link-selected": {"background-color": "#34568B"},
    },
)


if selected == "Overview":
    st.write("Dashboard Page (To be developed)")
elif selected == "Validation":
    st.write("Validation Page (To be developed)")
elif selected == "Risk/Tiers":
    st.write("Risk Page (To be developed)")
elif selected == "Findings":
    st.write("Findings Page (To be developed)")
elif selected == "Documentation":
    st.write("Docs Page (To be developed)")
elif selected == "Monitor":
    st.write("Monitor Page (To be developed)")
elif selected == "Tests":
    st.write("Tests Page (To be developed)")

if selected == "General":
    pg = st.navigation(
        
        {
            "General1": [st.Page("pages/page_1.py")],
            "General2": [st.Page("pages/page_2.py")],
        }
    )
    pg.run()
if selected == "Reviews":
    pg = st.navigation(
        {
            "Something1": [st.Page("pages/page_1.py")],
            "Whatever": [st.Page("pages/page_2.py")],
        }
    )
    pg.run()
