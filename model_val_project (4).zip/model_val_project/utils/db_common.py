import streamlit as st
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import Base, Model, ModelValidation, Finding, Document, ModelInvocation, ActionPlan
import database.crud
from datetime import datetime
import pandas as pd
import altair as alt
import plotly.express as px

# Database setup
DATABASE_URL = "sqlite:///./database.db"  # Adjust the URL as needed
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db = SessionLocal()


def recreate_database():
    """Function to recreate the database schema."""
    Base.metadata.drop_all(engine)  # Drop all tables
    Base.metadata.create_all(engine)  # Recreate all tables
    st.success("Database recreated successfully!")

def load_sample_data():
    """Function to load sample data into the database."""
    # Create a new session
    session = SessionLocal()
    
    # Recreate database schema
    # recreate_database()
    
    # Load sample data
    for model_data in Model.get_sample_data():
        model = Model(**model_data)
        session.add(model)
    session.commit()

    for validation_data in ModelValidation.get_sample_data():
        validation = ModelValidation(**validation_data)
        session.add(validation)
    session.commit()

    for finding_data in Finding.get_sample_data():
        finding = Finding(**finding_data)
        session.add(finding)
    session.commit()

    for document_data in Document.get_sample_data():
        document = Document(**document_data)
        session.add(document)
    session.commit()

    for data in ModelInvocation.get_sample_data():
        document = ModelInvocation(**data)
        session.add(document)
    session.commit()

    # ActionPlan
    for data in ActionPlan.get_sample_data():
        document = ActionPlan(**data)
        session.add(document)
    session.commit()

    st.success("Sample data loaded successfully!")

def display_model_data():
    st.subheader("Models")
    models = db.query(Model).all()
    for model in models:
        st.write(f"Model ID: {model.model_id}, Name: {model.model_name}, Type: {model.model_type}, Status: {model.model_status}")

def display_model_validation_data():
    st.subheader("Model Validations")
    validations = db.query(ModelValidation).all()
    for validation in validations:
        st.write(f"Validation ID: {validation.validation_id}, Model ID: {validation.model_id}, Date: {validation.validation_date}, Status: {validation.validation_status}")

def display_finding_data():
    st.subheader("Findings")
    findings = db.query(Finding).all()
    for finding in findings:
        st.write(f"Finding ID: {finding.finding_id}, Validation ID: {finding.validation_id}, Type: {finding.finding_type}, Status: {finding.finding_status}")

def display_document_data():
    st.subheader("Documents")
    documents = db.query(Document).all()
    for document in documents:
        st.write(f"Document ID: {document.document_id}, Name: {document.document_name}, Type: {document.document_type}, Path: {document.document_path}")




# Display data

def display_table_data(model_class, db_session):
    """Fetch and display data from the given model class."""
    # Fetch all data from the table
    data = db_session.query(model_class).all()
    
    # Convert to a list of dictionaries
    data_dict = [row.__dict__ for row in data]
    
    # Remove the SQLAlchemy metadata
    for row in data_dict:
        row.pop('_sa_instance_state', None)
    
    # Convert to DataFrame
    df = pd.DataFrame(data_dict)
    
    # Display the DataFrame
    if not df.empty:
        st.markdown("""
    <style>
        .streamlit-container {
            max-width: 1200px; /* Adjust this value as needed */
            margin: auto;
        }
    </style>
""", unsafe_allow_html=True)
        st.write(f"### {model_class.__tablename__.capitalize()} Data")
        st.dataframe(df, width=1200)
    else:
        st.write(f"No data found for {model_class.__tablename__.capitalize()}.")


