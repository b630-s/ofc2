import streamlit as st
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import (
    Base,
    Model,
    ModelValidation,
    Finding,
    Document,
    ModelInvocation,
    ActionPlan,
)
import database.crud
from database.crud import (
    get_model_for_validation,
    get_all_models,
    get_all_model_validations,
)
from utils.db_common import *

from datetime import datetime
import pandas as pd
import altair as alt
import plotly.express as px
from streamlit_extras.bottom_container import bottom

from modules.home import load_home, display_model_list,display_validation_list
from modules.model_page import models_page
from modules.settings_page import settings_page
from modules.overview import load_overview
from modules.validation_page import validations_page
from modules.risk_tiers import load_risk_tiers
from modules.findings import load_findings
from modules.documentation import load_documentation
from modules.monitor import load_monitor
from modules.tests import load_tests


st.set_page_config(
    page_title="Model Validator",
    page_icon="🏂",
    layout="wide",
    initial_sidebar_state="expanded",
)

alt.themes.enable("dark")
st.markdown(
    """
    <style>
    /* padding for the Streamlit app container */
    .block-container {
        padding-top: 3rem !important;  /* Adjust top padding */
        padding-bottom: 0px !important;  /* Adjust bottom padding */
            padding-left: 10px !important;
            padding-right: 10px !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Streamlit layout
# st.title("Model Management System")

from streamlit_option_menu import option_menu

st.subheader("Model Validation and Risk Assessment")

m=None
mn = None
v=None
with st.sidebar:
    e_names= st.empty()

def load_actives(elem):
    global m,mn,v
    with elem:
        with st.container():
            if "active_model_id" in st.session_state.keys():
                m = st.session_state["active_model_id"]
            # st.write(m)
            if "active_model_name" in st.session_state.keys():
                mn = st.session_state["active_model_name"]
            # st.write(mn)
            if "active_validation_id" in st.session_state.keys():
                v = st.session_state["active_validation_id"]
            # st.write(v)
            st.write("Active Model Name: ", mn, )
            st.write("Active Validation Name: ",v)

sidebar_option = st.sidebar.radio(
    "Navigation", ["Model Manager", "Validation Manager", "Add a Model", "Add a Validation", "Settings"], index=None
)
selected_menu = option_menu(
    None,
    [
        "Home",
        "Overview",
        "Model Details",
        "Validation",
        "Risk/Tiers",
        "Findings",
        "Documentation",
        "Monitor",
        "Tests",
    ],
    icons=[
        "house",
        "clipboard-data",
        "shield-check",
        "exclamation-triangle",
        "flag",
        "file-earmark",
        "activity",
        "bezier",
    ],
    key="menu_main",
    orientation="horizontal",
    default_index=0,
    styles={
        "container": {"padding": "0!important", "background-color": "#4a90e2"},
        "icon": {"color": "orange", "font-size": "16px"},
        "nav-link": {
            "font-size": "13px",
            "text-align": "center",
            "margin": "0px",
            "padding": "2px",
            "--hover-color": "#eee",
        },
        "nav-link-selected": {"background-color": "#34568B"},
    },
)


if sidebar_option == "Model Manager":
    # st.write("again")
    model_empty = st.empty()
    # container1 = st.container()
    with model_empty.container():
        st.write("## All Models")
        models_list = get_all_models(db)  # Fetch all models
        display_model_list(models_list)
        load_actives(e_names)
        # st.rerun()


elif sidebar_option == "Validation Manager":

    validations_list = get_all_model_validations(
        db
    )  # Assuming get_all_validations() returns a list of validation objects
    model_empty = st.empty()
    # container1 = st.container()
    with model_empty.container():
        st.write("## All Validations")
        display_validation_list(validations_list)
        load_actives(e_names)
        
elif sidebar_option == "Settings":

    validations_list = get_all_model_validations(
        db
    )  # Assuming get_all_validations() returns a list of validation objects
    model_empty = st.empty()
    # container1 = st.container()
    with model_empty.container():
        st.write("## Settings")
        settings_page()
        load_actives(e_names)



if "active_model_id" in st.session_state:
    if selected_menu == "Home":
    # if
        load_home(sidebar_option)  # Load home page content
    
    elif selected_menu == "Model Details":
        model_empty.empty()
        models_page(db)

    elif selected_menu == "Validation":
        model_empty.empty()
        validations_page(db)
        # load_validation(db)
    elif selected_menu == "Risk/Tiers":
        model_empty.empty()
        load_risk_tiers(st.session_state["active_model_id"])
    elif selected_menu == "Findings":
        load_findings(st.session_state["active_validation_id"])
    elif selected_menu == "Documentation":
        load_documentation(st.session_state["active_model_id"])
    elif selected_menu == "Monitor":
        load_monitor(st.session_state["active_validation_id"])
    elif selected_menu == "Tests":
        load_tests(st.session_state["active_validation_id"])
    


# if selected == "General":
# pg = st.navigation(

#     {
#         "General1": [st.Page("pages/Models.py"),st.Page("pages/Validations.py")],
#         # "General1": [],
#         "Setup": [st.Page("pages/page_2.py")],
#     }
# )
# pg.run()
# if selected == "Reviews":
#     pg = st.navigation(
#         {
#             "Something1": [st.Page("pages/page_1.py")],
#             "Whatever": [st.Page("pages/page_2.py")],
#         }
#     )
#     pg.run()
