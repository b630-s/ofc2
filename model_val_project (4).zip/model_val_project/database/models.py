from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Date,
    Enum,
    ForeignKey,
    CheckConstraint,
)
from sqlalchemy import Integer, Text, DateTime, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import date, datetime


# Model attribute options
MODEL_TYPES = ["Financial", "ML", "Statistical", "Custom"]
MATERIALITY_LEVELS = ["High", "Medium", "Low"]
COMPLEXITY_LEVELS = ["Simple", "Moderate", "Complex"]
RISK_RATINGS = ["Low", "Medium", "High"]
VALIDATION_FREQUENCIES = ["Annual", "Semi-Annual", "Quarterly", "Custom"]
MODEL_STATUSES = ["active", "inactive", "deprecated"]
FRAMEWORKS = ["scikit-learn", "TensorFlow", "PyTorch", "XGBoost", "custom"]
LANGUAGES = ["Python", "R", "Java", "C++", "custom"]
INVOCATION_METHODS = ["REST API", "gRPC", "local invocation", "custom"]

Base = declarative_base()


class Model(Base):
    __tablename__ = "models"

    model_id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String, nullable=False)
    model_type = Column(String)
    business_line = Column(String)
    business_name = Column(String)  # Added business_name
    model_tier = Column(String)  # Added model_tier
    questionnaire_tier = Column(String)  # Added questionnaire_tier
    algorithm = Column(String)
    model_developer = Column(String)
    creation_date = Column(Date)
    last_modified_date = Column(Date)
    owner_entity = Column(String)
    materiality = Column(String)
    complexity = Column(String)

    # Framework and language related fields
    model_framework = Column(
        String,
        CheckConstraint(
            "model_framework IN ('scikit-learn', 'TensorFlow', 'PyTorch', 'XGBoost', 'custom')"
        ),
        nullable=False,
    )
    custom_framework = Column(
        String, nullable=True
    )  # Field for user-defined frameworks (if 'custom' is chosen)
    model_language = Column(
        String,
        CheckConstraint("model_language IN ('Python', 'R', 'Java', 'C++', 'custom')"),
        nullable=False,
    )
    custom_language = Column(
        String, nullable=True
    )  # Field for user-defined languages (if 'custom' is chosen)

    # Model deployment and invocation fields
    deployment_endpoint = Column(
        String, nullable=True
    )  # API or local endpoint where the model is deployed
    input_schema = Column(
        String, nullable=True
    )  # JSON or other format specifying input structure
    output_schema = Column(
        String, nullable=True
    )  # JSON or other format specifying output structure
    input_example = Column(String, nullable=True)  # Example input for the model
    output_example = Column(String, nullable=True)  # Example output for the model
    invocation_method = Column(
        String,
        CheckConstraint(
            "invocation_method IN ('REST API', 'gRPC', 'local invocation', 'custom')"
        ),
        nullable=False,
    )
    custom_invocation_method = Column(
        String, nullable=True
    )  # Field for user-defined invocation method (if 'custom' is chosen)

    # Validation-related fields
    validation_frequency = Column(
        String
    )  # Period (weekly, monthly, n-days, yearly, etc.)
    validation_days = Column(
        Integer, nullable=True
    )  # Only populated if validation_frequency is 'n-days'
    last_validation_date = Column(Date)
    next_validation_date = Column(Date)

    # Status and rating fields
    model_status = Column(
        String, CheckConstraint("model_status IN ('active', 'inactive', 'deprecated')")
    )
    risk_rating = Column(String)
    validation_rating = Column(String)  # Added validation_rating

    # Relationships
    model_validations = relationship("ModelValidation", back_populates="model")
    documents = relationship("Document", back_populates="model")
    action_plans = relationship("ActionPlan", back_populates="model")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the models table."""
        return [
            {
                "model_name": "Customer Churn Prediction Model",
                "model_type": "Customer Analytics",
                "business_line": "Telecom",
                "business_name": "XYZ Telecom",
                "algorithm": "Logistic Regression",
                "model_developer": "Data Science Team B",
                "creation_date": datetime.strptime("2022-03-10", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-04-15", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Customer Retention Dept",
                "materiality": "Medium",
                "complexity": "Moderate",
                "validation_frequency": "Quarterly",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-07-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2023-10-01", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "Medium",
                "model_tier": "Tier 2",
                "questionnaire_tier": "Tier 2",
                "validation_rating": "85",
                "model_framework": "scikit-learn",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.xyztelecom.com/churn",
                "input_schema": '{"features": ["age", "tenure", "monthly_charges"]}',
                "output_schema": '{"churn_probability": "float"}',
                "input_example": '{"age": 45, "tenure": 24, "monthly_charges": 65}',
                "output_example": '{"churn_probability": 0.45}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Sales Forecasting Model",
                "model_type": "Forecasting",
                "business_line": "Retail",
                "business_name": "Mega Retail Inc.",
                "algorithm": "ARIMA",
                "model_developer": "Forecasting Team",
                "creation_date": datetime.strptime("2021-09-01", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-06-20", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Sales Analytics Dept",
                "materiality": "High",
                "complexity": "Complex",
                "validation_frequency": "Semi-Annual",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-07-15", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2024-01-15", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "High",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 2",
                "validation_rating": "88",
                "model_framework": "custom",
                "custom_framework": "Prophet",
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://megaretail.com/forecast",
                "input_schema": '{"features": ["historical_sales", "holiday_indicator", "seasonality"]}',
                "output_schema": '{"predicted_sales": "float"}',
                "input_example": '{"historical_sales": 20000, "holiday_indicator": 0, "seasonality": "spring"}',
                "output_example": '{"predicted_sales": 22000}',
                "invocation_method": "local invocation",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Credit Score Evaluation Model",
                "model_type": "Credit Scoring",
                "business_line": "Banking",
                "business_name": "Global Bank",
                "algorithm": "Gradient Boosting",
                "model_developer": "Credit Risk Analysis Team",
                "creation_date": datetime.strptime("2020-01-15", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-03-10", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Credit Analysis Dept",
                "materiality": "High",
                "complexity": "Complex",
                "validation_frequency": "Annual",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-03-15", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2024-03-15", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "High",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 1",
                "validation_rating": "92",
                "model_framework": "XGBoost",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.globalbank.com/creditscore",
                "input_schema": '{"features": ["loan_amount", "income", "credit_history"]}',
                "output_schema": '{"credit_score": "float"}',
                "input_example": '{"loan_amount": 5000, "income": 55000, "credit_history": "good"}',
                "output_example": '{"credit_score": 750}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Image Recognition Model",
                "model_type": "Computer Vision",
                "business_line": "Healthcare",
                "business_name": "MedVision Inc.",
                "algorithm": "Convolutional Neural Network",
                "model_developer": "AI Vision Team",
                "creation_date": datetime.strptime("2021-08-10", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-05-20", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Radiology Dept",
                "materiality": "High",
                "complexity": "High",
                "validation_frequency": "Semi-Annual",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-06-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2023-12-01", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "High",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 2",
                "validation_rating": "92",
                "model_framework": "TensorFlow",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.medvision.com/image-recognition",
                "input_schema": '{"features": ["image_data"]}',
                "output_schema": '{"diagnosis": "string"}',
                "input_example": '{"image_data": "base64encodedstring"}',
                "output_example": '{"diagnosis": "benign"}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Insurance Claim Fraud Detection",
                "model_type": "Fraud Detection",
                "business_line": "Insurance",
                "business_name": "SecureLife Insurance",
                "algorithm": "Random Forest",
                "model_developer": "Fraud Detection Unit",
                "creation_date": datetime.strptime("2020-05-18", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-03-14", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Risk Management Dept",
                "materiality": "High",
                "complexity": "Moderate",
                "validation_frequency": "Annual",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-03-15", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2024-03-15", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "High",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 3",
                "validation_rating": "88",
                "model_framework": "XGBoost",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://securelife.com/api/fraud-detect",
                "input_schema": '{"features": ["claim_amount", "incident_type", "claim_history"]}',
                "output_schema": '{"fraud_probability": "float"}',
                "input_example": '{"claim_amount": 15000, "incident_type": "accident", "claim_history": "none"}',
                "output_example": '{"fraud_probability": 0.67}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Medical Image Segmentation Model",
                "model_type": "Computer Vision",
                "business_line": "Healthcare",
                "business_name": "VisionMed Corp",
                "algorithm": "U-Net",
                "model_developer": "Medical Imaging Team",
                "creation_date": datetime.strptime("2022-01-25", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-07-10", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Imaging Analysis Dept",
                "materiality": "High",
                "complexity": "High",
                "validation_frequency": "Quarterly",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-07-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2023-10-01", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "Medium",
                "model_tier": "Tier 2",
                "questionnaire_tier": "Tier 2",
                "validation_rating": "89",
                "model_framework": "PyTorch",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.visionmed.com/image-segmentation",
                "input_schema": '{"features": ["image_data"]}',
                "output_schema": '{"segmentation_map": "array"}',
                "input_example": '{"image_data": "base64encodedstring"}',
                "output_example": '{"segmentation_map": [[0,1,0],[1,1,0]]}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Credit Risk Model",
                "model_type": "Financial",
                "business_line": "Retail Banking",
                "business_name": "ABC Bank",
                "algorithm": "Logistic Regression",
                "model_developer": "Team A",
                "creation_date": datetime.strptime("2023-01-15", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-08-10", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Risk Management Dept",
                "materiality": "High",
                "complexity": "Complex",
                "validation_frequency": "Annual",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-08-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2024-08-01", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "Medium",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 2",
                "validation_rating": "85",
                "model_framework": "scikit-learn",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.abc-bank.com/predict",
                "input_schema": '{"features": ["age", "income", "credit_score"]}',
                "output_schema": '{"prediction": "float"}',
                "input_example": '{"age": 35, "income": 50000, "credit_score": 700}',
                "output_example": '{"prediction": 0.85}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Churn Prediction Model",
                "model_type": "Customer Analytics",
                "business_line": "Telecom",
                "business_name": "XYZ Telecom",
                "algorithm": "Random Forest",
                "model_developer": "Data Science Team",
                "creation_date": datetime.strptime("2022-11-10", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-07-20", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Marketing Analytics",
                "materiality": "Medium",
                "complexity": "Moderate",
                "validation_frequency": "n-days",
                "validation_days": 180,
                "last_validation_date": datetime.strptime(
                    "2023-07-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2023-12-28", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "Low",
                "model_tier": "Tier 2",
                "questionnaire_tier": "Tier 3",
                "validation_rating": "78",
                "model_framework": "XGBoost",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.xyz-telecom.com/churn",
                "input_schema": '{"features": ["customer_id", "monthly_spend", "tenure"]}',
                "output_schema": '{"churn_likelihood": "float"}',
                "input_example": '{"customer_id": "12345", "monthly_spend": 75, "tenure": 24}',
                "output_example": '{"churn_likelihood": 0.45}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
            {
                "model_name": "Fraud Detection Model",
                "model_type": "Risk Management",
                "business_line": "Payments",
                "business_name": "Global Pay",
                "algorithm": "Deep Neural Network",
                "model_developer": "Fraud Analytics Team",
                "creation_date": datetime.strptime("2021-06-25", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime(
                    "2023-05-15", "%Y-%m-%d"
                ).date(),
                "owner_entity": "Fraud Prevention Dept",
                "materiality": "High",
                "complexity": "High",
                "validation_frequency": "Monthly",
                "validation_days": None,
                "last_validation_date": datetime.strptime(
                    "2023-08-01", "%Y-%m-%d"
                ).date(),
                "next_validation_date": datetime.strptime(
                    "2023-09-01", "%Y-%m-%d"
                ).date(),
                "model_status": "active",
                "risk_rating": "High",
                "model_tier": "Tier 1",
                "questionnaire_tier": "Tier 1",
                "validation_rating": "90",
                "model_framework": "TensorFlow",
                "custom_framework": None,
                "model_language": "Python",
                "custom_language": None,
                "deployment_endpoint": "http://api.globalpay.com/fraud-detect",
                "input_schema": '{"features": ["transaction_id", "amount", "country", "payment_method"]}',
                "output_schema": '{"fraud_probability": "float"}',
                "input_example": '{"transaction_id": "TX123456", "amount": 200.0, "country": "USA", "payment_method": "credit_card"}',
                "output_example": '{"fraud_probability": 0.98}',
                "invocation_method": "REST API",
                "custom_invocation_method": None,
            },
        ]


VALIDATION_STATUSES = ["in progress", "completed", "rejected"]


class ModelValidation(Base):
    __tablename__ = "model_validations"

    validation_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_name = Column(String, nullable=False)
    model_id = Column(Integer, ForeignKey("models.model_id"), nullable=False)
    validation_date = Column(Date, default=date.today)
    validator_name = Column(String, nullable=False)
    validation_status = Column(
        String,
        CheckConstraint(
            "validation_status IN ('in progress', 'completed', 'rejected')"
        ),
        nullable=False,
    )
    validation_score = Column(String, nullable=True)
    validation_comments = Column(String, nullable=True)

    # Relationships
    model = relationship("Model", back_populates="model_validations")
    findings = relationship("Finding", back_populates="model_validation")
    documents = relationship("Document", back_populates="validation")
    invocations = relationship("ModelInvocation", back_populates="model_validation")
    action_plans = relationship("ActionPlan", back_populates="validation")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the model_validations table."""
        return [
            {
                "model_id": 1,
                "validation_name": "Validation Iteration 1",
                "validation_date": datetime.strptime("2023-08-01", "%Y-%m-%d").date(),
                "validator_name": "John Doe",
                "validation_status": "completed",
                "validation_score": "85",
                "validation_comments": "Validation completed successfully.",
            },
            {
                "model_id": 1,
                "validation_name": "Validation Iteration 2",
                "validation_date": datetime.strptime("2023-10-01", "%Y-%m-%d").date(),
                "validator_name": "Emily Chen",
                "validation_status": "in progress",
                "validation_score": None,
                "validation_comments": "Currently validating model updates.",
            },
            {
                "model_id": 2,
                "validation_name": "Annual Review 2023",
                "validation_date": datetime.strptime("2023-07-15", "%Y-%m-%d").date(),
                "validator_name": "Jane Smith",
                "validation_status": "completed",
                "validation_score": "88",
                "validation_comments": "Model passed with minor issues.",
            },
            {
                "model_id": 2,
                "validation_name": "Quarterly Validation Q4 2023",
                "validation_date": datetime.strptime("2023-10-10", "%Y-%m-%d").date(),
                "validator_name": "Robert Gray",
                "validation_status": "in progress",
                "validation_score": None,
                "validation_comments": "Initial assessment shows satisfactory performance.",
            },
            {
                "model_id": 3,
                "validation_name": "Compliance Validation",
                "validation_date": datetime.strptime("2023-09-01", "%Y-%m-%d").date(),
                "validator_name": "Alice Green",
                "validation_status": "rejected",
                "validation_score": "65",
                "validation_comments": "Validation rejected due to compliance issues.",
            },
            {
                "model_id": 4,
                "validation_name": "Model Upgrade Validation",
                "validation_date": datetime.strptime("2023-05-15", "%Y-%m-%d").date(),
                "validator_name": "Michael Tan",
                "validation_status": "completed",
                "validation_score": "92",
                "validation_comments": "Validation successful for the upgraded model version.",
            },
            {
                "model_id": 5,
                "validation_name": "Quarterly Risk Assessment Q3 2023",
                "validation_date": datetime.strptime("2023-07-30", "%Y-%m-%d").date(),
                "validator_name": "Sophia Lee",
                "validation_status": "completed",
                "validation_score": "80",
                "validation_comments": "Risk levels within acceptable limits.",
            },
            {
                "model_id": 6,
                "validation_name": "Initial Validation",
                "validation_date": datetime.strptime("2023-06-20", "%Y-%m-%d").date(),
                "validator_name": "William Brown",
                "validation_status": "rejected",
                "validation_score": "70",
                "validation_comments": "Failed due to insufficient accuracy.",
            },
            {
                "model_id": 7,
                "validation_name": "Annual Validation 2023",
                "validation_date": datetime.strptime("2023-03-15", "%Y-%m-%d").date(),
                "validator_name": "Olivia Adams",
                "validation_status": "completed",
                "validation_score": "90",
                "validation_comments": "Model performed well across metrics.",
            },
            {
                "model_id": 8,
                "validation_name": "Security Compliance Check",
                "validation_date": datetime.strptime("2023-09-12", "%Y-%m-%d").date(),
                "validator_name": "James White",
                "validation_status": "in progress",
                "validation_score": None,
                "validation_comments": "Ongoing validation for security compliance.",
            },
            {
                "model_id": 1,
                "validation_name": "Validation iter 1",
                "validation_date": datetime.strptime("2023-08-01", "%Y-%m-%d").date(),
                "validator_name": "John Doe",
                "validation_status": "completed",
                "validation_score": "85",
                "validation_comments": "Validation completed successfully.",
            },
            {
                "model_id": 2,
                "validation_name": "Validation iter 2",
                "validation_date": datetime.strptime("2023-07-15", "%Y-%m-%d").date(),
                "validator_name": "Jane Smith",
                "validation_status": "in progress",
                "validation_score": "N/A",
                "validation_comments": "Still working on validation.",
            },
            {
                "model_id": 3,
                "validation_name": "Validation iter 3",
                "validation_date": datetime.strptime("2023-06-10", "%Y-%m-%d").date(),
                "validator_name": "Emily Brown",
                "validation_status": "rejected",
                "validation_score": "60",
                "validation_comments": "Validation failed due to model complexity.",
            },
        ]


class Finding(Base):
    __tablename__ = "findings"

    finding_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=False
    )
    finding_type = Column(
        String, CheckConstraint("finding_type IN ('numeric', 'text')"), nullable=False
    )
    finding_value = Column(String, nullable=True)
    finding_status = Column(
        String,
        CheckConstraint("finding_status IN ('open', 'closed', 'in progress')"),
        nullable=False,
    )
    finding_comments = Column(String, nullable=True)

    # Risk assessment attributes
    risk_category = Column(
        Enum(
            "model",
            "operational",
            "compliance",
            "financial",
            "technical",
            name="risk_categories",
        ),
        nullable=True,
    )
    risk_description = Column(String, nullable=True)
    risk_score = Column(Integer, nullable=True)
    mitigation_plan = Column(String, nullable=True)
    assessment_status = Column(
        String,
        CheckConstraint("assessment_status IN ('open', 'mitigated', 'closed')"),
        nullable=True,
    )

    # Relationships
    model_validation = relationship("ModelValidation", back_populates="findings")
    action_plans = relationship("ActionPlan", back_populates="finding")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the findings table."""
        return [
            {
                "finding_id": 1,
                "validation_id": 1,
                "finding_type": "numeric",
                "finding_value": "85%",
                "finding_status": "open",
                "finding_comments": "Initial finding comment.",
                "risk_category": "operational",
                "risk_description": "System performance below expected levels.",
                "risk_score": 7,
                "mitigation_plan": "Increase system resources and optimize code.",
                "assessment_status": "open",
            },
            {
                "finding_id": 2,
                "validation_id": 1,
                "finding_type": "text",
                "finding_value": "Minor issue identified with data integrity.",
                "finding_status": "closed",
                "finding_comments": "Issue resolved and data integrity checks are now in place.",
                "risk_category": "compliance",
                "risk_description": "Data integrity issues potentially affecting compliance.",
                "risk_score": 5,
                "mitigation_plan": "Implemented additional data validation checks.",
                "assessment_status": "mitigated",
            },
            {
                "finding_id": 3,
                "validation_id": 2,
                "finding_type": "text",
                "finding_value": "Outlier detected in recent dataset.",
                "finding_status": "in progress",
                "finding_comments": "Pending further analysis and investigation.",
                "risk_category": "financial",
                "risk_description": "Potential impact on financial forecasting accuracy.",
                "risk_score": 8,
                "mitigation_plan": "Analyze outlier impact and adjust forecasting models as needed.",
                "assessment_status": "open",
            },
            {
                "finding_id": 4,
                "validation_id": 2,
                "finding_type": "numeric",
                "finding_value": "90% accuracy drop in model predictions.",
                "finding_status": "open",
                "finding_comments": "High discrepancy observed requiring urgent attention.",
                "risk_category": "technical",
                "risk_description": "Significant drop in model accuracy affecting operational efficiency.",
                "risk_score": 9,
                "mitigation_plan": "Review model algorithm and retrain with updated data.",
                "assessment_status": "open",
            },
            {
                "finding_id": 5,
                "validation_id": 3,
                "finding_type": "numeric",
                "finding_value": "15% deviation from expected outcome.",
                "finding_status": "in progress",
                "finding_comments": "Ongoing investigation into the cause of deviation.",
                "risk_category": "model",
                "risk_description": "Deviation affecting model performance and decision-making.",
                "risk_score": 6,
                "mitigation_plan": "Conduct a thorough review of model parameters and retrain if necessary.",
                "assessment_status": "open",
            },
        ]


class Document(Base):
    __tablename__ = "documents"

    document_id = Column(Integer, primary_key=True, autoincrement=True)
    model_id = Column(Integer, ForeignKey("models.model_id"), nullable=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=True
    )
    document_name = Column(String, nullable=False)
    document_path = Column(String, nullable=False)
    document_type = Column(
        String,
        CheckConstraint("document_type IN ('model', 'validation')"),
        nullable=False,
    )
    upload_date = Column(Date, default=date.today)

    model = relationship("Model", back_populates="documents")
    validation = relationship("ModelValidation", back_populates="documents")
    action_plans = relationship("ActionPlan", back_populates="attachment")

    __table_args__ = (
        CheckConstraint(
            "(model_id IS NOT NULL AND validation_id IS NULL) OR (model_id IS NULL AND validation_id IS NOT NULL)",
            name="check_model_or_validation",
        ),
    )

    @classmethod
    def get_sample_data(cls):
        """Sample data for the documents table."""
        return [
            {
                "document_id": 1,
                "model_id": 1,
                "validation_id": None,
                "document_name": "Model Specification",
                "document_path": "./docs/model_specification.pdf",
                "document_type": "model",
                "upload_date": date(2024, 1, 15),
            },
            {
                "document_id": 2,
                "model_id": 1,
                "validation_id": None,
                "document_name": "Model Architecture Diagram",
                "document_path": "./docs/model_architecture.png",
                "document_type": "model",
                "upload_date": date(2024, 1, 20),
            },
            {
                "document_id": 3,
                "model_id": None,
                "validation_id": 1,
                "document_name": "Validation Report Q1 2024",
                "document_path": "./docs/validation_report_q1_2024.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 2, 5),
            },
            {
                "document_id": 4,
                "model_id": None,
                "validation_id": 1,
                "document_name": "Finding Details Report",
                "document_path": "./docs/finding_details_report.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 2, 10),
            },
            {
                "document_id": 5,
                "model_id": None,
                "validation_id": 2,
                "document_name": "Validation Summary",
                "document_path": "./docs/validation_summary.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 3, 1),
            },
        ]


class ModelInvocation(Base):
    __tablename__ = "model_invocations"

    invocation_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=False
    )

    model_framework = Column(
        Enum(
            "scikit-learn",
            "TensorFlow",
            "PyTorch",
            "XGBoost",
            "custom",
            name="model_framework_enum",
        ),
        nullable=False,
    )
    invocation_timestamp = Column(DateTime, default=datetime.utcnow)
    model_version = Column(String, nullable=True)
    execution_environment = Column(
        Enum(
            "local",
            "aws",
            "gcp",
            "azure",
            "docker",
            "custom",
            name="execution_env_enum",
        ),
        nullable=False,
    )

    input_data = Column(Text, nullable=False)  # Could be path or serialized JSON
    input_description = Column(String, nullable=True)
    output_data = Column(Text, nullable=True)  # Serialized JSON or path to output

    metrics = Column(Text, nullable=True)  # JSON or string for key-value metric pairs
    runtime_seconds = Column(Float, nullable=True)
    hardware_used = Column(String, nullable=True)
    status = Column(
        Enum("success", "failed", name="invocation_status_enum"), nullable=False
    )
    error_message = Column(String, nullable=True)

    hyperparameters = Column(
        Text, nullable=True
    )  # Optional: hyperparameters in JSON format
    deployment_endpoint = Column(String, nullable=True)
    invocation_mode = Column(
        Enum("batch", "real-time", name="invocation_mode_enum"), nullable=False
    )
    triggered_by_user = Column(Boolean, default=True)

    comments = Column(String, nullable=True)

    # Relationship with ModelValidation
    model_validation = relationship("ModelValidation", back_populates="invocations")

    @classmethod
    def get_sample_data(cls):
        return [
            {
                "validation_id": 1,
                "model_framework": "TensorFlow",
                "invocation_timestamp": datetime(2024, 9, 10, 14, 30),
                "model_version": "v2.1",
                "execution_environment": "aws",
                "input_data": '{"feature1": 0.5, "feature2": 1.2}',
                "input_description": "Sample input data for testing.",
                "output_data": '{"prediction": 0.75}',
                "metrics": '{"accuracy": 0.92, "precision": 0.89}',
                "runtime_seconds": 45.5,
                "hardware_used": "t2.medium",
                "status": "success",
                "error_message": None,
                "hyperparameters": '{"learning_rate": 0.01, "batch_size": 32}',
                "deployment_endpoint": "http://aws.example.com/model/v2",
                "invocation_mode": "real-time",
                "triggered_by_user": True,
                "comments": "Model invoked successfully for real-time prediction.",
            },
            {
                "validation_id": 2,
                "model_framework": "PyTorch",
                "invocation_timestamp": datetime(2024, 9, 11, 9, 15),
                "model_version": "v3.0",
                "execution_environment": "docker",
                "input_data": '{"feature1": 0.7, "feature2": 1.5}',
                "input_description": "Input data for batch processing.",
                "output_data": '{"prediction": 0.80}',
                "metrics": '{"accuracy": 0.88, "recall": 0.85}',
                "runtime_seconds": 60.0,
                "hardware_used": "gpu",
                "status": "failed",
                "error_message": "Model execution error: Out of memory.",
                "hyperparameters": '{"learning_rate": 0.001, "epochs": 20}',
                "deployment_endpoint": "http://docker.example.com/model/v3",
                "invocation_mode": "batch",
                "triggered_by_user": False,
                "comments": "Batch processing failed due to memory issues.",
            },
            {
                "validation_id": 3,
                "model_framework": "scikit-learn",
                "invocation_timestamp": datetime(2024, 9, 12, 11, 45),
                "model_version": "v1.4",
                "execution_environment": "local",
                "input_data": '{"feature1": 0.6, "feature2": 1.1}',
                "input_description": "Testing model on local environment.",
                "output_data": '{"prediction": 0.70}',
                "metrics": '{"accuracy": 0.90, "f1_score": 0.87}',
                "runtime_seconds": 30.2,
                "hardware_used": "cpu",
                "status": "success",
                "error_message": None,
                "hyperparameters": '{"n_estimators": 100, "max_depth": 10}',
                "deployment_endpoint": None,
                "invocation_mode": "batch",
                "triggered_by_user": True,
                "comments": "Local environment test completed successfully.",
            },
        ]


# from sqlalchemy import Column, Integer, String, Enum, Date, ForeignKey, Text, Boolean
# from sqlalchemy.orm import relationship
# from sqlalchemy.dialects.postgresql import ENUM
# from datetime import datetime


class ActionPlan(Base):
    __tablename__ = "action_plans"

    action_id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String, nullable=False)
    type = Column(
        Enum(
            "preventive",
            "corrective",
            "mitigative",
            "other",
            name="action_plan_type_enum",
        ),
        nullable=False,
    )
    priority = Column(
        Enum("low", "medium", "high", name="priority_enum"), nullable=False
    )
    description = Column(Text, nullable=True)
    finding_id = Column(
        Integer, ForeignKey("findings.finding_id"), nullable=True
    )  # Foreign key to Findings table
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=True
    )  # Foreign key to ModelValidations table
    model_id = Column(
        Integer, ForeignKey("models.model_id"), nullable=True
    )  # Foreign key to Models table
    attachment_id = Column(
        Integer, ForeignKey("documents.document_id"), nullable=True
    )  # Foreign key to Documents table
    due_date = Column(Date, nullable=False)
    reported_by = Column(String, nullable=False)
    affected_entities = Column(
        String, nullable=True
    )  # Could be a list of affected entities or individuals
    created_date = Column(Date, default=datetime.now)
    updated_date = Column(Date, onupdate=datetime.now)

    # Relationships
    finding = relationship("Finding", back_populates="action_plans")
    validation = relationship("ModelValidation", back_populates="action_plans")
    model = relationship("Model", back_populates="action_plans")
    attachment = relationship("Document", back_populates="action_plans")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the action_plans table."""
        return [
            {
                "title": "Update Model Training Data",
                "type": "corrective",
                "priority": "high",
                "description": "The training data for the model needs to be updated to improve accuracy.",
                "finding_id": 1,
                "validation_id": 1,
                "model_id": 1,
                "attachment_id": 1,
                "due_date": datetime.strptime("2024-05-01", "%Y-%m-%d").date(),
                "reported_by": "John Doe",
                "affected_entities": "Data Science Team",
                "created_date": datetime.now().date(),
                "updated_date": datetime.now().date(),
            },
            {
                "title": "Fix Data Integrity Issue",
                "type": "preventive",
                "priority": "medium",
                "description": "Address the data integrity issue identified in the recent audit.",
                "finding_id": 2,
                "validation_id": 2,
                "model_id": 2,
                "attachment_id": 2,
                "due_date": datetime.strptime("2024-06-15", "%Y-%m-%d").date(),
                "reported_by": "Jane Smith",
                "affected_entities": "Compliance Dept",
                "created_date": datetime.now().date(),
                "updated_date": datetime.now().date(),
            },
            {
                "title": "Review Model Algorithm",
                "type": "mitigative",
                "priority": "low",
                "description": "Review the model algorithm to ensure it is performing optimally.",
                "finding_id": None,
                "validation_id": 3,
                "model_id": 3,
                "attachment_id": None,
                "due_date": datetime.strptime("2024-07-30", "%Y-%m-%d").date(),
                "reported_by": "Emily Brown",
                "affected_entities": "Market Research Dept",
                "created_date": datetime.now().date(),
                "updated_date": datetime.now().date(),
            },
        ]
