import streamlit as st
from st_aggrid import AgGrid
import pandas as pd
from database.crud import (
    get_model_for_validation,
    get_all_models,
    get_all_model_validations,
)
from utils.db_common import *

def load_home(option):
    st.write("### home Overview")
    st.write(f"Displaying details for Model ID: {option}")


def display_model_list(models_list):

    models_df = pd.DataFrame([{
        "Model ID": model.model_id,
        "Model Name": model.model_name,
        "Type": model.model_type,
        "Business Line": model.business_line,
        "Algorithm": model.algorithm,
        "Developer": model.model_developer,
        "Materiality": model.materiality,
        "Complexity": model.complexity,
        "Risk Rating": model.risk_rating,
        "Status": model.model_status,
        "Last Validation Date": model.last_validation_date,
        "Next Validation Date": model.next_validation_date
    } for model in models_list])
    event = st.dataframe(data=models_df, use_container_width=True, hide_index=True, selection_mode='single-row', on_select='rerun')   
    if len(event.selection['rows']):
        selected_row = event.selection['rows'][0]
        idx= models_df.iloc[selected_row]["Model ID"]
        mn = models_df.iloc[selected_row]["Model Name"]
        # st.write(event)
        # st.write(mn, idx)
        # selected_model_id = selected_row 
        st.session_state["active_model_id"] = idx
        st.session_state["active_model_name"] = mn
        

def display_validation_list(validations_list):

    validations_df = pd.DataFrame([{
        "Validation ID": validation.validation_id,
        "Validation Name": validation.validation_name,
        "Associated Model ID": validation.model_id,
        "Validation Date": validation.validation_date,
        "Validator Name": validation.validator_name,
        "Validation Status": validation.validation_status,
        "Validation Score": validation.validation_score,
        "Comments": validation.validation_comments
    } for validation in validations_list])

    # Display DataFrame with a radio button for selection
    event = st.dataframe(data=validations_df, use_container_width=True, hide_index=True, selection_mode='single-row', on_select='rerun')   
    if len(event.selection['rows']):
        selected_row = event.selection['rows'][0]
        # selected_validation_id = validations_df.iloc[selected_row]["Validation ID"]

        # Update session state with the selected validation and associated model
        st.session_state["active_validation_id"] = selected_row
        model = get_model_for_validation(db, selected_row)
        # st.write(model)
        st.session_state["active_model_id"] = model.model_id

        
