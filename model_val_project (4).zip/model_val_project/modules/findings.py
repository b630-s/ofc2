import streamlit as st

def load_findings(model_id):
    st.write("### findings Overview")
    st.write(f"Displaying details for Model ID: {model_id}")