import streamlit as st

def load_tests(model_id):
    st.write("### tests Overview")
    st.write(f"Displaying details for Model ID: {model_id}")