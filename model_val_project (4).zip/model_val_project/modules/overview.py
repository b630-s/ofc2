import streamlit as st

def load_overview(model_id):
    st.write("### OVERVIEW")
    st.write(f"Displaying details for Model ID: {model_id}")
