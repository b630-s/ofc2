# Portability Notes

## Current Prototype Choices

These notes capture deliberate short-term implementation choices for the current prototype slice.

### Airflow Metadata Database

Airflow now uses an in-cluster PostgreSQL instance managed through the Airflow Helm chart.

Why:
- It is the simplest correct deployment model for KubernetesExecutor.
- It stays portable across managed cloud Kubernetes and on-prem Kubernetes.
- It provides persistent metadata as long as the PostgreSQL volume is retained.

Tradeoff:
- This is operationally simpler than an external database, but not the final production posture.

### Airflow Logs

Airflow logs are still pod-local for now.

Why:
- The immediate goal is to make the platform base deployable first.

Follow-up:
- Wire remote logging to object storage later, using MinIO-compatible configuration rather than cloud-specific logging services.

### MinIO

The current prototype continues to use MinIO as the object storage abstraction.

Why:
- It provides a portable S3-compatible interface for Spark, Flink, Polaris, and Iceberg integration.

Follow-up:
- Revisit the exact Helm packaging path before production hardening and confirm the preferred supported deployment model.

### Ingress And Monitoring

Ingress and monitoring are optional in the deployment script for now.

Why:
- They are useful shared services, but they are not required to prove the first deployable platform base.
- Ingress exposure details vary more by environment than the core data platform components.

### Helm Chart Version Pinning

The deployment script now pins Helm chart versions for reproducibility.

Why:
- Prototype validation should not drift when upstream charts publish new releases.
- Some values, especially around Strimzi and operator behavior, are version-sensitive.

Follow-up:
- Revalidate pinned versions as part of planned platform upgrades instead of absorbing chart changes implicitly.

### Polaris

Polaris now has a base installation path in the deployment script.

Why:
- The official Polaris chart expects pre-created resources, especially persistence and storage secrets.
- The chart also expects a separately managed database when using persistent storage.

Current prototype shape:
- in-cluster PostgreSQL for Polaris metadata persistence
- MinIO credentials provided through a Polaris storage secret
- official Polaris Helm chart installed from the Apache repository

Remaining follow-up:
- create the actual catalog through the Polaris API or CLI after install
- document the exact bootstrap flow for the MinIO-backed Iceberg catalog
- replace generated internal-auth defaults with managed secrets before any serious environment use
