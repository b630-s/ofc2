# Architecture

## Purpose

DCX is being prototyped as a portable, sovereign-ready lakehouse platform that can run across public cloud and on-prem Kubernetes environments without redesigning the data platform layer for each provider.

The immediate workspace focus is an AWS prototype on EKS, but the architecture must remain valid for AKS, GKE, OpenShift, and on-prem Kubernetes.

## Platform Model

The platform is organized into four layers:

1. Infrastructure layer
   Provides compute, networking, and persistent storage primitives for Kubernetes.
2. Kubernetes platform layer
   Provides namespaces, service accounts, operators, ingress, monitoring, and shared runtime services.
3. Data platform layer
   Provides Kafka, Spark, Flink, Airflow, Polaris, Iceberg, and object storage integration.
4. Workload layer
   Provides batch and streaming pipelines, orchestration DAGs, and reusable processing patterns.

## Target Components

The current target stack is:

- Apache Kafka for event ingestion
- Apache Spark for batch and streaming workloads
- Apache Flink for streaming workloads
- Apache Airflow OSS for orchestration
- Polaris for catalog services
- Apache Iceberg for table format
- MinIO or another portable S3-compatible object store for the prototype storage abstraction

## Portability Principles

The architecture must follow these rules:

- Use Kubernetes as the control surface for workloads.
- Use Kubernetes-native service accounts and upstream Kubernetes APIs.
- Treat object storage as a generic interface rather than coupling to a specific cloud data service.
- Keep runtime configuration portable across clouds.
- Avoid cloud-specific SDKs and identity assumptions inside workloads.
- Prefer CNCF and Apache components over cloud-managed proprietary services in the data plane.

## AWS Boundary

AWS is acceptable only at the infrastructure boundary of the prototype:

- EC2 for worker compute
- VPC for networking
- EBS or EFS for persistent node-attached or file-backed storage
- EKS for managed Kubernetes control plane operations

The platform above Kubernetes should not need to know whether it is running on AWS, Azure, GCP, OpenShift, or bare metal.

## Initial Deployment Shape

The current repository structure reflects the following deployment model:

- Terraform provisions AWS network and EKS infrastructure for the prototype environment.
- Kubernetes manifests and Helm values configure namespaces, service accounts, operators, and shared platform services.
- Workloads are deployed into dedicated namespaces for `kafka`, `spark`, `flink`, `airflow`, `polaris`, and `minio`.
- Sample data pipelines will demonstrate Kafka ingestion, Spark and Flink processing, and writes into Iceberg tables through Polaris and object storage.

## Design Outcome

If successful, this prototype should show that DCX can be packaged as a "run anywhere" platform:

- same architecture
- same core services
- same workload model
- only infrastructure adapters changing per environment
