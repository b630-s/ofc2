# Deployment Order

## Goal

The deployment flow should build the prototype from the bottom up so that shared services exist before workloads depend on them.

## Working Order

1. Provision infrastructure.
   Script: `scripts/01-deploy-infra.sh`
   For the AWS prototype, Terraform creates the VPC, subnets, EKS cluster, managed node group, and storage add-ons.

2. Connect kubectl to the cluster.
   Script: `scripts/02-connect-cluster.sh`
   This updates kubeconfig for the target EKS cluster so all following scripts operate on the intended cluster.

3. Install platform operators and shared services.
   Script: `scripts/03-deploy-platform.sh`
   This includes:
   - Strimzi for Kafka
   - Spark Operator
   - Flink Operator
   - Airflow
   - MinIO
   - Polaris
   - ingress and monitoring components as needed

4. Validate the platform base.
   Script: `scripts/04-validate-platform.sh`
   This validates only the current milestone: nodes, operators, MinIO, Airflow, and optionally Polaris.

5. Deploy sample workloads.
   Script: `scripts/05-deploy-workloads.sh`
   This includes:
   - Spark batch pipeline
   - Spark streaming pipeline
   - Flink streaming pipeline
   - Airflow DAGs

6. Clean up platform services.
   Script: `scripts/06-cleanup-platform.sh`
   This removes Kubernetes services and Helm releases only. It does not destroy AWS infrastructure.

7. Destroy infrastructure when you want to stop AWS charges.
   Script: `scripts/07-destroy-infra.sh`
   This runs Terraform destroy for the AWS prototype environment.

## Validation Expectations

At minimum, the current platform-only validation should prove:

- cluster infrastructure is healthy
- operators are running
- Airflow scheduler is running
- MinIO is reachable
- Polaris is healthy when installed

## Portability Reminder

The deployment order should remain conceptually the same across EKS, AKS, GKE, OpenShift, and on-prem Kubernetes. The infrastructure provisioning step may change, but the platform and workload flow should remain consistent.
