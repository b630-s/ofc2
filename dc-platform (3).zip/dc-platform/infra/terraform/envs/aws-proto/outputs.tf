# --- Network ---
output "vpc_id" {
  value = module.network.vpc_id
}

output "private_subnet_ids" {
  value = module.network.private_subnet_ids
}

output "public_subnet_ids" {
  value = module.network.public_subnet_ids
}

# --- EKS ---
output "eks_cluster_name" {
  value = module.cluster.cluster_name
}

output "eks_cluster_endpoint" {
  value = module.cluster.cluster_endpoint
}

output "cluster_oidc_issuer_url" {
  value = module.cluster.cluster_oidc_issuer_url
}

output "oidc_provider_arn" {
  value = module.cluster.oidc_provider_arn
}

