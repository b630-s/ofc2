Recommended operator flow:

1. Create or review infrastructure plan:
   `scripts/01-deploy-infra.sh`

2. Apply infrastructure when ready:
   `scripts/01-deploy-infra.sh --apply`

3. Connect kubectl to the cluster:
   `scripts/02-connect-cluster.sh`

4. Install platform services:
   `scripts/03-deploy-platform.sh`

5. Validate the platform base:
   `scripts/04-validate-platform.sh`

6. Remove platform services when finished:
   `scripts/06-cleanup-platform.sh`

7. Destroy AWS infrastructure to stop charges:
   `scripts/07-destroy-infra.sh`

These scripts are intentionally split so platform cleanup and AWS destroy are separate operator decisions.
