#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/terraform/envs/aws-proto}"
TF_PLAN_FILE="${TF_PLAN_FILE:-tfplan}"

ACTION="plan"
YES="false"

usage() {
  cat <<'EOF'
Usage:
  01-deploy-infra.sh [--plan] [--apply] [--destroy] [--yes]

Behavior:
  --plan     Run terraform init/fmt/validate/plan. This is the default.
  --apply    Run init/fmt/validate/plan, then apply the generated plan after confirmation.
  --destroy  Run terraform init and terraform plan -destroy. With --yes, also run terraform destroy.
  --yes      Skip the confirmation prompt for --apply or the second confirmation for --destroy.

Environment:
  TF_DIR         Terraform environment directory.
  TF_PLAN_FILE   Terraform plan output file name.
EOF
}

confirm() {
  local prompt="$1"
  local answer
  read -r -p "${prompt} [y/N]: " answer
  [[ "${answer}" =~ ^[Yy]$ ]]
}

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

terraform_cmd() {
  terraform -chdir="${TF_DIR}" "$@"
}

run_plan_flow() {
  terraform_cmd init
  terraform_cmd fmt -check -recursive
  terraform_cmd validate
  terraform_cmd plan -out="${TF_PLAN_FILE}"
}

run_destroy_flow() {
  local destroy_plan_file="${TF_PLAN_FILE}-destroy"

  terraform_cmd init
  terraform_cmd plan -destroy -out="${destroy_plan_file}"

  if [[ "${YES}" != "true" ]]; then
    echo "Destroy will remove AWS infrastructure and stop ongoing charges."
    if ! confirm "Proceed with terraform destroy?"; then
      echo "Destroy cancelled."
      exit 0
    fi
  fi

  terraform_cmd apply "${destroy_plan_file}"
}

main() {
  require_cmd terraform

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --plan)
        ACTION="plan"
        ;;
      --apply)
        ACTION="apply"
        ;;
      --destroy)
        ACTION="destroy"
        ;;
      --yes)
        YES="true"
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        echo "unknown argument: $1" >&2
        usage >&2
        exit 1
        ;;
    esac
    shift
  done

  case "${ACTION}" in
    plan)
      run_plan_flow
      echo "Terraform plan completed in ${TF_DIR}."
      ;;
    apply)
      run_plan_flow
      if [[ "${YES}" != "true" ]]; then
        if ! confirm "Apply the generated terraform plan now?"; then
          echo "Apply cancelled. The plan file remains at ${TF_DIR}/${TF_PLAN_FILE}."
          exit 0
        fi
      fi
      terraform_cmd apply "${TF_PLAN_FILE}"
      echo "Terraform apply completed."
      ;;
    destroy)
      run_destroy_flow
      echo "Terraform destroy completed."
      ;;
  esac
}

main "$@"
