#!/usr/bin/env bash

set -euo pipefail

failure=0

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

check_nodes() {
  echo "Checking Kubernetes node readiness..."
  if ! kubectl get nodes --no-headers | awk 'BEGIN { bad=0 } $2 != "Ready" { bad=1 } END { exit bad }'; then
    echo "Node readiness check failed." >&2
    failure=1
  fi
}

check_release_pods() {
  local namespace="$1"
  local selector="$2"
  local label="$3"

  echo "Checking ${label} in namespace ${namespace}..."
  if ! kubectl wait --namespace "${namespace}" --for=condition=Ready pod --selector "${selector}" --timeout=180s >/dev/null 2>&1; then
    echo "${label} pods are not ready." >&2
    failure=1
  fi
}

check_airflow() {
  echo "Checking Airflow scheduler..."
  if ! kubectl wait --namespace airflow --for=condition=Ready pod --selector "component=scheduler" --timeout=300s >/dev/null 2>&1; then
    echo "Airflow scheduler is not ready." >&2
    failure=1
  fi
}

check_optional_polaris() {
  if ! kubectl get deployment polaris -n polaris >/dev/null 2>&1; then
    echo "Polaris not installed. Skipping Polaris validation."
    return
  fi

  echo "Checking Polaris..."
  if ! kubectl rollout status deployment/polaris --namespace polaris --timeout=300s >/dev/null 2>&1; then
    echo "Polaris deployment is not ready." >&2
    failure=1
  fi
}

main() {
  require_cmd kubectl

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster." >&2
    exit 1
  fi

  check_nodes
  check_release_pods "platform-system" "app.kubernetes.io/instance=strimzi-kafka-operator" "Strimzi operator"
  check_release_pods "platform-system" "app.kubernetes.io/instance=spark-operator" "Spark operator"
  check_release_pods "platform-system" "app.kubernetes.io/instance=flink-kubernetes-operator" "Flink operator"
  check_release_pods "minio" "app.kubernetes.io/instance=minio" "MinIO"
  check_airflow
  check_optional_polaris

  if [[ "${failure}" -ne 0 ]]; then
    echo "Platform validation failed." >&2
    exit 1
  fi

  echo "Platform validation passed."
}

main "$@"
