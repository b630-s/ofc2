#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"
INGRESS_NAMESPACE="${INGRESS_NAMESPACE:-ingress-nginx}"
AIRFLOW_CHART_VERSION="${AIRFLOW_CHART_VERSION:-1.20.0}"
MINIO_CHART_VERSION="${MINIO_CHART_VERSION:-5.4.0}"
SPARK_OPERATOR_CHART_VERSION="${SPARK_OPERATOR_CHART_VERSION:-2.4.0}"
STRIMZI_CHART_VERSION="${STRIMZI_CHART_VERSION:-0.51.0}"
FLINK_OPERATOR_VERSION="${FLINK_OPERATOR_VERSION:-1.14.0}"
INGRESS_NGINX_CHART_VERSION="${INGRESS_NGINX_CHART_VERSION:-4.14.1}"
KUBE_PROMETHEUS_STACK_CHART_VERSION="${KUBE_PROMETHEUS_STACK_CHART_VERSION:-80.13.3}"
POLARIS_CHART_VERSION="${POLARIS_CHART_VERSION:-1.2.0-incubating}"

ENABLE_INGRESS="${ENABLE_INGRESS:-false}"
ENABLE_MONITORING="${ENABLE_MONITORING:-false}"
ENABLE_POLARIS="${ENABLE_POLARIS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

add_helm_repos() {
  helm repo add apache-airflow https://airflow.apache.org
  helm repo add minio https://charts.min.io/
  helm repo add spark-operator https://kubeflow.github.io/spark-operator
  helm repo add strimzi https://strimzi.io/charts/
  helm repo add flink-kubernetes-operator "https://downloads.apache.org/flink/flink-kubernetes-operator-${FLINK_OPERATOR_VERSION}/"
  helm repo add polaris https://downloads.apache.org/incubator/polaris/helm-chart

  if [[ "${ENABLE_INGRESS}" == "true" ]]; then
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
  fi

  if [[ "${ENABLE_MONITORING}" == "true" ]]; then
    helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
  fi

  helm repo update
}

install_foundations() {
  kubectl apply -f "${REPO_ROOT}/platform/namespaces.yaml"
  kubectl apply -f "${REPO_ROOT}/platform/service-accounts.yaml"
  kubectl apply -f "${REPO_ROOT}/platform/minio-secret.yaml"
}

install_strimzi() {
  helm upgrade --install strimzi-kafka-operator strimzi/strimzi-kafka-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${STRIMZI_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-strimzi-operator.yaml" \
    --wait \
    --timeout 10m
}

install_spark_operator() {
  helm upgrade --install spark-operator spark-operator/spark-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${SPARK_OPERATOR_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-spark-operator.yaml" \
    --wait \
    --timeout 10m
}

install_flink_operator() {
  helm upgrade --install flink-kubernetes-operator flink-kubernetes-operator/flink-kubernetes-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${FLINK_OPERATOR_VERSION}" \
    --values "${REPO_ROOT}/platform/values-flink-operator.yaml" \
    --wait \
    --timeout 10m
}

install_airflow() {
  helm upgrade --install airflow apache-airflow/airflow \
    --namespace airflow \
    --create-namespace \
    --version "${AIRFLOW_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-airflow.yaml" \
    --wait \
    --timeout 15m
}

install_minio() {
  helm upgrade --install minio minio/minio \
    --namespace minio \
    --create-namespace \
    --version "${MINIO_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-minio.yaml" \
    --wait \
    --timeout 15m
}

install_ingress() {
  if [[ "${ENABLE_INGRESS}" != "true" ]]; then
    echo "Skipping ingress-nginx. Set ENABLE_INGRESS=true to install it."
    return
  fi

  helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
    --namespace "${INGRESS_NAMESPACE}" \
    --create-namespace \
    --version "${INGRESS_NGINX_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-ingress-nginx.yaml" \
    --wait \
    --timeout 10m
}

install_monitoring() {
  if [[ "${ENABLE_MONITORING}" != "true" ]]; then
    echo "Skipping monitoring stack. Set ENABLE_MONITORING=true to install it."
    return
  fi

  helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
    --namespace "${MONITORING_NAMESPACE}" \
    --create-namespace \
    --version "${KUBE_PROMETHEUS_STACK_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-monitoring.yaml" \
    --wait \
    --timeout 15m
}

install_polaris() {
  if [[ "${ENABLE_POLARIS}" != "true" ]]; then
    echo "Skipping Polaris installation. Set ENABLE_POLARIS=true to install Polaris and its in-cluster PostgreSQL backend."
    return
  fi

  kubectl apply -f "${REPO_ROOT}/platform/polaris-persistence-secret.yaml"
  kubectl apply -f "${REPO_ROOT}/platform/polaris-storage-secret.yaml"
  kubectl apply -f "${REPO_ROOT}/platform/polaris-postgresql.yaml"

  kubectl rollout status statefulset/polaris-postgresql \
    --namespace polaris \
    --timeout=10m

  helm upgrade --install polaris polaris/polaris \
    --namespace polaris \
    --create-namespace \
    --devel \
    --version "${POLARIS_CHART_VERSION}" \
    --values "${REPO_ROOT}/platform/values-polaris.yaml" \
    --wait \
    --timeout 15m

  echo "Polaris service installed."
  echo "Catalog bootstrap is still a separate step after install."
}

main() {
  require_cmd kubectl
  require_cmd helm

  add_helm_repos
  install_foundations
  install_strimzi
  install_spark_operator
  install_flink_operator
  install_minio
  install_airflow
  install_ingress
  install_monitoring
  install_polaris

  echo "Platform services deployment completed."
  echo "Next steps: run 04-validate-platform.sh, then bootstrap Polaris if enabled."
}

main "$@"
