Recommended operator flow:

cd infra/aws-proto
terraform init
terraform fmt -check -recursive
terraform validate
terraform plan
terraform apply



1. Create or review infrastructure plan:
   `infra/aws-proto/deploy-infra.sh`

2. Apply infrastructure when ready:
   `infra/aws-proto/deploy-infra.sh --apply`

   Note:
   During `--apply`, the script bootstraps the EKS cluster first, updates IRSA trust policies from the cluster OIDC issuer, and then runs the full Terraform apply. This avoids the EBS CSI add-on timing issue on fresh environments.
   After a successful apply, the script also writes timestamped backups of the Terraform state into `infra/aws-proto/bkp/`.

3. Connect kubectl to the cluster:
   `scripts/02-connect-cluster.sh`

4. Install platform services:
   `scripts/03-deploy-platform.sh`

5. Validate the platform base:
   `scripts/04-validate-platform.sh`

   A successful validation confirms the current AWS prototype baseline:
   - EKS nodes are ready
   - Strimzi operator is healthy
   - Spark Operator controller and webhook are healthy
   - Prometheus and Grafana are healthy
   - Airflow core components are healthy
   - Polaris and Polaris PostgreSQL are healthy

6. Remove platform services when finished:
   `scripts/06-cleanup-platform.sh`

7. Destroy AWS infrastructure to stop charges:
   `infra/aws-proto/destroy-infra.sh`

These scripts are intentionally split so platform cleanup and AWS destroy are separate operator decisions.

Current AWS Terraform layout:

- `infra/aws-proto/network.tf`
- `infra/aws-proto/eks.tf`
- `infra/aws-proto/storage.tf`
- `infra/aws-proto/iam.tf`
- `infra/aws-proto/variables.tf`
- `infra/aws-proto/terraform.tfvars`

This keeps the AWS prototype infrastructure in one readable folder while still separating network, cluster, storage, and IAM concerns by file.

Important current prototype note:

- Airflow PostgreSQL persistence is explicitly set to `storageClass: gp2` in the platform values for this AWS environment so it does not depend on a default StorageClass.
