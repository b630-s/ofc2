import streamlit as st
from st_aggrid import AgGrid
import pandas as pd
from database.crud import (
    get_model_for_validation,
    get_all_models,
    get_all_model_validations,
)
from utils.db_common import *

from utils.misc_common import *

def load_home(option):
    st.write("### home Overview")
    st.write(f"Displaying details for Model ID: {option}")


def display_validations_for_model(db, model_id):
    
    # Fetch all validations for the given model ID
    validations_list = [v for v in get_all_model_validations(db) if v.model_id == model_id]

    # Check if there are validations for the model
    if not validations_list:
        st.info("No validations found for this model.")
        return
    styled_header("Now Load a Validation")

    # Create a DataFrame from the validations list
    validations_df = pd.DataFrame([{
        "Validation ID": validation.validation_id,
        "Validation Name": validation.validation_name,
        "Validation Date": validation.validation_date,
        "Validator Name": validation.validator_name,
        "Validation Status": validation.validation_status,
        "Validation Score": validation.validation_score,
        "Comments": validation.validation_comments
    } for validation in validations_list])

    # Display DataFrame with row selection
    selected_index = st.dataframe(
        data=validations_df,
        use_container_width=True,
        hide_index=True,
        selection_mode='single-row',
        on_select='rerun'
    )

    # Handle row selection for validations
    if selected_index and len(selected_index.selection['rows']):
        selected_row = selected_index.selection['rows'][0]
        idx = validations_df.iloc[selected_row]["Validation ID"]
        vn = validations_df.iloc[selected_row]["Validation Name"]

        # Set selected validation in session state
        st.session_state["active_validation_id"] = idx
        st.session_state["active_validation_name"] = vn

        # Also set the active model in session state
        # st.session_state["active_model_id"] = model_id
        # model = get_model(db, model_id)
        # if model:
        #     st.session_state["active_model_name"] = model.model_name
        # else:
        #     st.session_state["active_model_name"] = None



def display_model_list(models_list):

    models_df = pd.DataFrame([{
            "Model ID": model.model_id,
            "Model Name": model.model_name,
             "Asset Class": model.asset_class,
            "Product": model.product,
            "Type": model.model_type,
            "Business Line": model.business_line,
            "Business Name": model.business_name,
            "Algorithm": model.algorithm,
            "Developer": model.model_developer,
            "Creation Date": model.creation_date,
            "Last Modified": model.last_modified_date,
            "Owner Entity": model.owner_entity,
            "Materiality": model.materiality,
            "Complexity": model.complexity,
            "Risk Rating": model.risk_rating,
            "Status": model.model_status,
            "Model Tier": model.model_tier,
            "Questionnaire Tier": model.questionnaire_tier,
            "Framework": model.model_framework,
            "Language": model.model_language,
            "Deployment Endpoint": model.deployment_endpoint,
            "Validation Frequency": model.validation_frequency,
            "Last Validation": model.last_validation_date,
            "Next Validation": model.next_validation_date,
            "Validation Rating": model.validation_rating
        } for model in models_list])

    # Sidebar for search and filter options
    # st.sidebar.header("Filter Models")
    # risk_rating = st.sidebar.select_slider("Filter by Risk Rating", options=["Low", "Medium", "High"])
    asset_classes = models_df["Asset Class"].dropna().unique().tolist()
    products = models_df["Product"].dropna().unique().tolist()
    model_types = models_df["Type"].dropna().unique().tolist()
    selected_asset_class = st.sidebar.selectbox("Asset Class", options=["All"] + asset_classes)
    selected_product = st.sidebar.selectbox("Product", options=["All"] + products)
    selected_model_type = st.sidebar.multiselect("Model Type", options=model_types)
    
    risk_rating = st.sidebar.select_slider("Filter by Risk Rating", options=[None,"Low", "Medium", "High"] )


    search_text = st.sidebar.text_input("Search by Model Name")
    model_status = st.sidebar.selectbox("Filter by Status", options=["All", "active", "inactive", "deprecated"])
    # model_type = st.sidebar.multiselect("Filter by Model Type", options=models_df["Type"].unique())

    if selected_asset_class != "All":
        models_df = models_df[models_df["Asset Class"] == selected_asset_class]
    if selected_product != "All":
        models_df = models_df[models_df["Product"] == selected_product]
    if selected_model_type:
        models_df = models_df[models_df["Type"].isin(selected_model_type)]
    if search_text:
        models_df = models_df[models_df["Model Name"].str.contains(search_text, case=False)]
    if model_status != "All":
        models_df = models_df[models_df["Status"] == model_status]
    if risk_rating:
        models_df = models_df[models_df["Risk Rating"] == risk_rating]

    # if search_text:
    #     models_df = models_df[models_df["Model Name"].str.contains(search_text, case=False)]
    # if model_status != "All":
    #     models_df = models_df[models_df["Status"] == model_status]
    # if model_type:
    #     models_df = models_df[models_df["Type"].isin(model_type)]
    # if risk_rating:
    #     models_df = models_df[models_df["Risk Rating"] == risk_rating]

    event = st.dataframe(data=models_df, height=300, use_container_width=True, hide_index=True, selection_mode='single-row', on_select='rerun')   
    if len(event.selection['rows']):
        selected_row = event.selection['rows'][0]
        idx= models_df.iloc[selected_row]["Model ID"]
        mn = models_df.iloc[selected_row]["Model Name"]
        # st.write(event)
        # st.write(mn, idx)
        # selected_model_id = selected_row 
        st.session_state["active_model_id"] = idx
        st.session_state["active_model_name"] = mn
        #reset validation
        st.session_state["active_validation_id"] = None
        st.session_state["active_validation_name"] = None

        display_validations_for_model(db, idx)

def display_validation_list(validations_list):
    # Create a DataFrame from the provided validations list
    validations_df = pd.DataFrame([{
        "Validation ID": validation.validation_id,
        "Validation Name": validation.validation_name,
        "Associated Model ID": validation.model_id,
        "Validation Date": validation.validation_date,
        "Validator Name": validation.validator_name,
        "Validation Status": validation.validation_status,
        "Validation Score": validation.validation_score,
        "Comments": validation.validation_comments
    } for validation in validations_list])

    # Sidebar for search and filter options
    # st.sidebar.header("Filter Validations")
    search_text = st.sidebar.text_input("Search by Validation Name")
    validation_status = st.sidebar.selectbox(
        "Filter by Validation Status",
        options=["All"] + validations_df["Validation Status"].unique().tolist()
    )
    validator_name = st.sidebar.selectbox(
        "Filter by Validator Name",
        options=["All"] + validations_df["Validator Name"].unique().tolist()
    )

    # Apply filters based on sidebar selections
    if search_text:
        validations_df = validations_df[validations_df["Validation Name"].str.contains(search_text, case=False)]
    if validation_status != "All":
        validations_df = validations_df[validations_df["Validation Status"] == validation_status]
    if validator_name != "All":
        validations_df = validations_df[validations_df["Validator Name"] == validator_name]

    # Display filtered DataFrame with row selection
    selected_index = st.dataframe(
        data=validations_df,
        use_container_width=True,
        hide_index=True,
        height=300,
        selection_mode='single-row',
        on_select='rerun'
    )   

    # Handle row selection for validation and model IDs
    if selected_index and len(selected_index.selection['rows']):
        selected_row = selected_index.selection['rows'][0]
        idx = validations_df.iloc[selected_row]["Validation ID"]
        vn = validations_df.iloc[selected_row]["Validation Name"]

        # Set selected validation in session state
        st.session_state["active_validation_id"] = idx
        st.session_state["active_validation_name"] = vn
        
        # Load associated model based on selected validation
        model = get_model_for_validation(db, int(idx))
        if model:
            st.session_state["active_model_id"] = model.model_id
            st.session_state["active_model_name"] = model.model_name
        else:
            st.session_state["active_model_id"] = None
            st.session_state["active_model_name"] = None

