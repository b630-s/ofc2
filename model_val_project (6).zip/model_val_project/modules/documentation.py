import streamlit as st


import streamlit as st
import pandas as pd
from datetime import datetime
from database.crud import (
    create_document,
    get_document,
    get_all_documents,
    update_document,
    delete_document,
)
from database.models import Document
from utils.misc_common import *

DOCUMENT_TYPES = ["data", "model", "testing", "regulatory"]

def manage_documents(db):
    st.sidebar.header("Document Management")

    with st.sidebar:
        selected_type = st.radio("Filter by Document Type",  ["All"]+DOCUMENT_TYPES, index=0)
        action = st.radio(
            "Actions",
            options=["View Documents", "Add Document", "Edit Document", "Delete Document"],
        )

    if action == "View Documents":
        styled_header("View All Documents")
        documents = get_all_documents(db)

        if selected_type != "All":
            documents = [doc for doc in documents if doc.document_type == selected_type]

        if documents:
            documents_df = pd.DataFrame([
                {
                    "Document ID": doc.document_id,
                    "Name": doc.document_name,
                    "Type": doc.document_type,
                    "Path": doc.document_path,
                    "Upload Date": doc.upload_date,
                }
                for doc in documents
            ])
            st.dataframe(documents_df, use_container_width=True)
        else:
            st.info(f"No documents found for type '{selected_type}'.")

    elif action == "Add Document":
        styled_header("Add New Document")
        with st.form("add_document_form"):
            document_name = st.text_input("Document Name")
            document_path = st.text_input("Document Path")
            document_type = st.selectbox("Document Type", DOCUMENT_TYPES)
            model_id = st.number_input("Model ID (Optional)", min_value=0, step=1)
            validation_id = st.number_input("Validation ID (Optional)", min_value=0, step=1)
            submit_button = st.form_submit_button("Add Document")

            if submit_button:
                new_document = {
                    "document_name": document_name,
                    "document_path": document_path,
                    "document_type": document_type,
                    "model_id": model_id if model_id > 0 else None,
                    "validation_id": validation_id if validation_id > 0 else None,
                    "upload_date": datetime.now(),
                }
                create_document(db, new_document)
                st.success(f"Document '{document_name}' added successfully.")

    elif action == "Edit Document":
        styled_header("Edit a Document")
        # st.subheader("Edit Document")
        documents = get_all_documents(db)
        if documents:
            document_options = {f"{doc.document_name} (ID: {doc.document_id})": doc.document_id for doc in documents}
            selected_document = st.selectbox("Select Document", list(document_options.keys()))
            document_id = document_options[selected_document]

            document = get_document(db, document_id)
            if document:
                with st.form("edit_document_form"):
                    document_name = st.text_input("Document Name", value=document.document_name)
                    document_path = st.text_input("Document Path", value=document.document_path)
                    document_type = st.selectbox("Document Type", DOCUMENT_TYPES, index=DOCUMENT_TYPES.index(document.document_type))
                    model_id = st.number_input("Model ID (Optional)", value=document.model_id or 0, min_value=0, step=1)
                    validation_id = st.number_input("Validation ID (Optional)", value=document.validation_id or 0, min_value=0, step=1)
                    submit_button = st.form_submit_button("Update Document")

                    if submit_button:
                        update_data = {
                            "document_name": document_name,
                            "document_path": document_path,
                            "document_type": document_type,
                            "model_id": model_id if model_id > 0 else None,
                            "validation_id": validation_id if validation_id > 0 else None,
                        }
                        update_document(db, document_id, update_data)
                        st.success(f"Document '{document_name}' updated successfully.")
            else:
                st.error("Document not found.")

    elif action == "Delete Document":
        # st.subheader("Delete Document")
        styled_header("Delete a Document")
        documents = get_all_documents(db)
        if documents:
            document_options = {f"{doc.document_name} (ID: {doc.document_id})": doc.document_id for doc in documents}
            selected_document = st.selectbox("Select Document to Delete", list(document_options.keys()))
            document_id = document_options[selected_document]

            if st.button("Delete Document"):
                delete_document(db, document_id)
                st.success(f"Document '{selected_document}' deleted successfully.")
        else:
            st.info("No documents available to delete.")



def load_documentation(db):
    
    manage_documents(db)