import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime
from database.crud import create_benchmark_model
from database.crud import (
    get_benchmark_model,
    update_benchmark_model,
    get_all_benchmark_models,
)
from database.crud import (
    get_all_models,
    add_benchmark_mapping,
    remove_benchmark_mapping,
    get_benchmark_mappings_for_model,
)
from database.crud import (
    get_all_models,
    get_benchmark_mappings_for_model,
    add_benchmark_mapping,
    remove_benchmark_mapping,
    get_all_benchmark_models,
    get_all_datasets,
)
from database.crud import get_all_datasets, get_dataset, add_dataset, update_dataset, remove_dataset

from database.models import MODEL_TYPES, FRAMEWORKS, LANGUAGES
from streamlit_extras.stylable_container import stylable_container


###### Benchmark page
def add_benchmark_model(db):
    st.write("#### Add a New Benchmark Model")

    with st.form("benchmark_model_form"):

        st.markdown("##### Basic Information")
        benchmark_model_name = st.text_input("Model Name", max_chars=100)
        algorithm = st.text_input("Algorithm", max_chars=100)
        model_type = st.selectbox("Model Type", options=MODEL_TYPES)

        st.markdown("##### Framework and Language")
        framework = st.selectbox("Framework", options=FRAMEWORKS)
        custom_framework = (
            st.text_input("Custom Framework (if applicable)")
            if framework == "custom"
            else ""
        )
        language = st.selectbox("Language", options=LANGUAGES)
        custom_language = (
            st.text_input("Custom Language (if applicable)")
            if language == "custom"
            else ""
        )

        st.markdown("##### Hyperparameters (JSON format)")
        hyperparameters = st.text_area(
            "Hyperparameters", placeholder='{"learning_rate": 0.01, "batch_size": 32}'
        )

        st.markdown("##### Additional Information")
        performance_expectations = st.text_area("Performance Expectations (Optional)")
        benchmark_metadata = st.text_area("Benchmark Metadata (Optional)")

        submit_button = st.form_submit_button("Add Benchmark Model")

        if submit_button:
            # Create a dictionary of the new benchmark model data
            new_benchmark_model = {
                "benchmark_model_name": benchmark_model_name,
                "algorithm": algorithm,
                "model_type": model_type,
                "framework": framework,
                "custom_framework": custom_framework,
                "language": language,
                "custom_language": custom_language,
                "hyperparameters": hyperparameters,
                "performance_expectations": performance_expectations,
                "benchmark_metadata": benchmark_metadata,
                "created_date": datetime.now(),
            }

            # Save to database
            create_benchmark_model(db, new_benchmark_model)
            st.success(f"Benchmark model '{benchmark_model_name}' added successfully.")


def benchmark_model_information_section(db, benchmark_model):
    with st.form("benchmark_model_information_form"):
        st.markdown("#### Benchmark Model General Information")
        col1, col2 = st.columns(2)
        with col1:
            benchmark_model_name = st.text_input(
                "Benchmark Model Name",
                value=benchmark_model.benchmark_model_name,
                max_chars=100,
            )
            algorithm = st.text_input(
                "Algorithm", value=benchmark_model.algorithm, max_chars=100
            )
            model_type = st.selectbox(
                "Model Type",
                ["Financial", "ML", "Statistical", "Custom"],
                index=(
                    ["Financial", "ML", "Statistical", "Custom"].index(
                        benchmark_model.model_type
                    )
                    if benchmark_model.model_type
                    else 0
                ),
            )
            business_line = st.text_input(
                "Business Line", value=benchmark_model.business_line, max_chars=100
            )
            business_name = st.text_input(
                "Business Name", value=benchmark_model.business_name, max_chars=100
            )
        with col2:
            developer_team = st.text_input(
                "Developer Team", value=benchmark_model.developer_team, max_chars=100
            )
            owner_entity = st.text_input(
                "Owner Entity", value=benchmark_model.owner_entity, max_chars=100
            )
            creation_date = st.date_input(
                "Creation Date", value=benchmark_model.creation_date
            )
            last_modified_date = st.date_input(
                "Last Modified Date", value=benchmark_model.last_modified_date
            )
            benchmark_status = st.selectbox(
                "Benchmark Status",
                ["active", "inactive", "deprecated"],
                index=["active", "inactive", "deprecated"].index(
                    benchmark_model.benchmark_status
                ),
            )

        submit_button = st.form_submit_button("Update General Information")
        if submit_button:
            update_data = {
                "benchmark_model_name": benchmark_model_name,
                "algorithm": algorithm,
                "model_type": model_type,
                "business_line": business_line,
                "business_name": business_name,
                "developer_team": developer_team,
                "owner_entity": owner_entity,
                "creation_date": creation_date,
                "last_modified_date": last_modified_date,
                "benchmark_status": benchmark_status,
            }
            update_benchmark_model(db, benchmark_model.benchmark_model_id, update_data)
            st.success("General Information updated successfully.")


def framework_and_language_section(db, benchmark_model):
    with st.form("framework_language_form"):
        st.markdown("#### Framework and Language")
        col1, col2 = st.columns(2)
        with col1:
            framework = st.selectbox(
                "Framework",
                ["scikit-learn", "TensorFlow", "PyTorch", "XGBoost", "custom"],
                index=[
                    "scikit-learn",
                    "TensorFlow",
                    "PyTorch",
                    "XGBoost",
                    "custom",
                ].index(benchmark_model.framework),
            )
            custom_framework = (
                st.text_input(
                    "Custom Framework", value=benchmark_model.custom_framework
                )
                if benchmark_model.framework == "custom"
                else ""
            )
        with col2:
            language = st.selectbox(
                "Language",
                ["Python", "R", "Java", "C++", "custom"],
                index=["Python", "R", "Java", "C++", "custom"].index(
                    benchmark_model.language
                ),
            )
            custom_language = (
                st.text_input("Custom Language", value=benchmark_model.custom_language)
                if benchmark_model.language == "custom"
                else ""
            )

        submit_button = st.form_submit_button("Update Framework and Language")
        if submit_button:
            update_data = {
                "framework": framework,
                "custom_framework": custom_framework,
                "language": language,
                "custom_language": custom_language,
            }
            update_benchmark_model(db, benchmark_model.benchmark_model_id, update_data)
            st.success("Framework and Language updated successfully.")


def performance_metrics_section(db, benchmark_model):
    with st.form("performance_metrics_form"):
        st.markdown("#### Performance and Risk Metrics")
        col1, col2 = st.columns(2)
        with col1:
            materiality = st.selectbox(
                "Materiality",
                ["High", "Medium", "Low"],
                index=(
                    ["High", "Medium", "Low"].index(benchmark_model.materiality)
                    if benchmark_model.materiality
                    else 0
                ),
            )
            complexity = st.selectbox(
                "Complexity",
                ["Simple", "Moderate", "Complex"],
                index=(
                    ["Simple", "Moderate", "Complex"].index(benchmark_model.complexity)
                    if benchmark_model.complexity
                    else 0
                ),
            )
            risk_rating = st.selectbox(
                "Risk Rating",
                ["Low", "Medium", "High"],
                index=(
                    ["Low", "Medium", "High"].index(benchmark_model.risk_rating)
                    if benchmark_model.risk_rating
                    else 0
                ),
            )
        with col2:
            performance_metrics = st.text_area(
                "Performance Metrics (JSON)",
                value=str(benchmark_model.performance_metrics),
            )
            benchmark_score = st.text_input(
                "Benchmark Score", value=benchmark_model.benchmark_score
            )

        submit_button = st.form_submit_button("Update Performance Metrics")
        if submit_button:
            update_data = {
                "materiality": materiality,
                "complexity": complexity,
                "risk_rating": risk_rating,
                "performance_metrics": performance_metrics,
                "benchmark_score": benchmark_score,
            }
            update_benchmark_model(db, benchmark_model.benchmark_model_id, update_data)
            st.success("Performance Metrics updated successfully.")


def deployment_section(db, benchmark_model):
    with st.form("deployment_form"):
        st.markdown("#### Deployment and Invocation")
        deployment_endpoint = st.text_input(
            "Deployment Endpoint", value=benchmark_model.deployment_endpoint
        )
        invocation_method = st.selectbox(
            "Invocation Method",
            ["REST API", "gRPC", "local invocation", "custom"],
            index=(
                ["REST API", "gRPC", "local invocation", "custom"].index(
                    benchmark_model.invocation_method
                )
                if benchmark_model.invocation_method
                else 0
            ),
        )
        custom_invocation_method = (
            st.text_input(
                "Custom Invocation Method",
                value=benchmark_model.custom_invocation_method,
            )
            if benchmark_model.invocation_method == "custom"
            else ""
        )

        submit_button = st.form_submit_button("Update Deployment")
        if submit_button:
            update_data = {
                "deployment_endpoint": deployment_endpoint,
                "invocation_method": invocation_method,
                "custom_invocation_method": custom_invocation_method,
            }
            update_benchmark_model(db, benchmark_model.benchmark_model_id, update_data)
            st.success("Deployment and Invocation updated successfully.")


# Main function for viewing and editing benchmark model details
def view_edit_benchmark_model(db, benchmark_model_id):
    benchmark_model = get_benchmark_model(db, benchmark_model_id)

    if not benchmark_model:
        st.error("Benchmark Model not found.")
        return

    st.subheader("Benchmark Model Details")
    with st.sidebar:
        with stylable_container(
            key="benchmark_nav",
            css_styles="""{background-color: #2d3436; color: #dfe6e9; border-radius: 5px; padding: 10px;}""",
        ):
            optx = st.radio(
                "Select a view",
                [
                    ":clipboard: General Information",
                    ":gear: Framework and Language",
                    ":chart_with_upwards_trend: Performance Metrics",
                    ":rocket: Deployment and Invocation",
                ],
            )
    if optx == ":clipboard: General Information":
        benchmark_model_information_section(db, benchmark_model)
    elif optx == ":gear: Framework and Language":
        framework_and_language_section(db, benchmark_model)
    elif optx == ":chart_with_upwards_trend: Performance Metrics":
        performance_metrics_section(db, benchmark_model)
    elif optx == ":rocket: Deployment and Invocation":
        deployment_section(db, benchmark_model)


def display_benchmark_models(db):
    benchmark_models = get_all_benchmark_models(db)
    benchmark_df = pd.DataFrame(
        [
            {
                "Benchmark Model ID": bm.benchmark_model_id,
                "Name": bm.benchmark_model_name,
                "Algorithm": bm.algorithm,
                "Type": bm.model_type,
                "Framework": bm.framework,
                "Language": bm.language,
                "Created Date": bm.created_date,
            }
            for bm in benchmark_models
        ]
    )

    st.dataframe(benchmark_df, use_container_width=True)

def manage_benchmark_mapping(db):
    st.write("#### Benchmark Mapping Management")

    with st.sidebar:
        st.header("Manage Mappings")
        action = st.radio(
            "Select Action",
            options=["View Mappings", "Add Mapping", "Remove Mapping"],
            label_visibility="collapsed"
        )

    # Main content based on selected action
    if action == "View Mappings":
        st.write("#### Current Mappings")

        # Dropdown for selecting a primary model to view mappings
        primary_models = get_all_models(db)
        primary_model_options = {
            f"{model.model_name} (ID: {model.model_id})": model.model_id
            for model in primary_models
        }
        selected_primary_model_name = st.selectbox("Select Primary Model", list(primary_model_options.keys()))
        selected_primary_model_id = primary_model_options[selected_primary_model_name]

        # Fetch and display existing mappings for the selected primary model
        current_mappings = get_benchmark_mappings_for_model(db, selected_primary_model_id)
        if current_mappings:
            mappings_df = pd.DataFrame(
                [
                    {
                        "Primary Model ID": mapping.primary_model_id,
                        "Primary Model Name": mapping.primary_model.model_name if mapping.primary_model else None,
                        "Benchmark Model ID": mapping.benchmark_model_id,
                        "Benchmark Model Name": mapping.benchmark_model.benchmark_model_name if mapping.benchmark_model else None,
                        "Dataset ID": mapping.dataset_id,
                        "Dataset Name": mapping.dataset.dataset_name if mapping.dataset else None,
                        "Usage Type": mapping.dataset.usage_type if mapping.dataset else None,
                        "Data Type": mapping.dataset.data_type if mapping.dataset else None,
                        "Mapping Type": mapping.mapping_type,
                        "Created Date": mapping.created_date,
                        "Last Modified Date": mapping.last_modified_date,
                    }
                    for mapping in current_mappings
                ]
            )
            st.dataframe(mappings_df, use_container_width=True)
        else:
            st.write("No current mappings found for the selected model.")

    elif action == "Add Mapping":
        st.write("#### Add New Mapping")

        # Dropdown for selecting primary model
        primary_models = get_all_models(db)
        primary_model_options = {
            f"{model.model_name} (ID: {model.model_id})": model.model_id
            for model in primary_models
        }
        selected_primary_model_name = st.selectbox("Select Primary Model", list(primary_model_options.keys()))
        selected_primary_model_id = primary_model_options[selected_primary_model_name]

        # Dropdown for selecting a benchmark model
        benchmark_models = get_all_benchmark_models(db)
        benchmark_model_options = {
            f"{bm.benchmark_model_name} (ID: {bm.benchmark_model_id})": bm.benchmark_model_id
            for bm in benchmark_models
        }
        selected_benchmark_model_name = st.selectbox("Select Benchmark Model", list(benchmark_model_options.keys()))
        selected_benchmark_model_id = benchmark_model_options[selected_benchmark_model_name]

        # Dropdown for selecting a dataset
        datasets = get_all_datasets(db)
        dataset_options = {f"{ds.dataset_name} (ID: {ds.dataset_id})": ds.dataset_id for ds in datasets}
        selected_dataset_name = st.selectbox("Select Dataset", list(dataset_options.keys()))
        selected_dataset_id = dataset_options[selected_dataset_name]

        # Select the type of mapping (e.g., training, testing, comparison)
        mapping_type = st.selectbox("Mapping Type", ["training", "testing", "comparison"])

        # Button to add mapping
        if st.button("Add Mapping"):
            add_benchmark_mapping(
                db,
                selected_primary_model_id,
                selected_benchmark_model_id,
                selected_dataset_id,
                mapping_type,
            )
            st.success(f"Mapping added: {selected_primary_model_name} to {selected_benchmark_model_name} with dataset {selected_dataset_name} as {mapping_type}.")

    elif action == "Remove Mapping":
        st.write("#### Remove Mapping")

        # Dropdown for selecting a primary model to view mappings
        primary_models = get_all_models(db)
        primary_model_options = {
            f"{model.model_name} (ID: {model.model_id})": model.model_id
            for model in primary_models
        }
        selected_primary_model_name = st.selectbox("Select Primary Model", list(primary_model_options.keys()))
        selected_primary_model_id = primary_model_options[selected_primary_model_name]

        # Fetch existing mappings for the selected primary model
        current_mappings = get_benchmark_mappings_for_model(db, selected_primary_model_id)
        if current_mappings:
            # Dropdown to select a specific mapping to remove
            mapping_options = {
                f"{m.benchmark_model_id} - {m.dataset_id} ({m.mapping_type})": m for m in current_mappings
            }
            selected_mapping = st.selectbox("Select Mapping to Remove", list(mapping_options.keys()))

            # Button to remove mapping
            if st.button("Remove Selected Mapping"):
                mapping = mapping_options[selected_mapping]
                remove_benchmark_mapping(db, mapping.primary_model_id, mapping.benchmark_model_id, mapping.dataset_id)
                st.success(f"Mapping with Benchmark Model ID {mapping.benchmark_model_id} and Dataset ID {mapping.dataset_id} removed.")
        else:
            st.write("No mappings available to remove for the selected model.")

def manage_datasets(db):
    st.write("#### Dataset Management")

    # Sidebar options for managing datasets
    with st.sidebar:
        st.header("Manage Datasets")
        action = st.radio(
            "Select Action",
            options=["View Datasets", "Add Dataset", "Edit Dataset", "Remove Dataset"],
            label_visibility="collapsed"
        )

    # Main content based on selected action
    if action == "View Datasets":
        st.write("#### All Datasets")
        
        # Fetch and display all datasets
        datasets = get_all_datasets(db)
        if datasets:
            datasets_df = pd.DataFrame([
                {
                    "Dataset ID": ds.dataset_id,
                    "Name": ds.dataset_name,
                    "Source": ds.source,
                    "Description": ds.description,
                    "Storage Location": ds.storage_location,
                    "Usage Type": ds.usage_type,
                    "Data Type": ds.data_type,
                    "Format": ds.format,
                    "Created Date": ds.created_date,
                    "Last Modified Date": ds.last_modified_date,
                    "Comments": ds.comments,
                    "Tags": ds.tags,
                } for ds in datasets
            ])
            st.dataframe(datasets_df, use_container_width=True)
        else:
            st.write("No datasets found.")

    elif action == "Add Dataset":
        st.write("#### Add New Dataset")

        # Form for adding a new dataset
        with st.form("add_dataset_form"):
            dataset_name = st.text_input("Dataset Name")
            source = st.text_input("Source")
            description = st.text_area("Description")
            storage_location = st.text_input("Storage Location")
            usage_type = st.selectbox("Usage Type", ["training", "validation", "benchmarking", "testing", "feature engineering"])
            data_type = st.selectbox("Data Type", ["tabular", "image", "text", "time-series", "audio"])
            format = st.text_input("Format")
            comments = st.text_area("Comments")
            tags = st.text_input("Tags (comma-separated)")

            submit_button = st.form_submit_button("Add Dataset")

            if submit_button:
                new_dataset = {
                    "dataset_name": dataset_name,
                    "source": source,
                    "description": description,
                    "storage_location": storage_location,
                    "usage_type": usage_type,
                    "data_type": data_type,
                    "format": format,
                    "comments": comments,
                    "tags": tags,
                    "created_date": datetime.now(),
                    "last_modified_date": datetime.now()
                }
                add_dataset(db, new_dataset)
                st.success(f"Dataset '{dataset_name}' added successfully.")

    elif action == "Edit Dataset":
        st.write("#### Edit Dataset")

        # Dropdown to select a dataset to edit
        datasets = get_all_datasets(db)
        dataset_options = {f"{ds.dataset_name} (ID: {ds.dataset_id})": ds.dataset_id for ds in datasets}
        selected_dataset_name = st.selectbox("Select Dataset", list(dataset_options.keys()))
        selected_dataset_id = dataset_options[selected_dataset_name]

        # Fetch the selected dataset details
        dataset = get_dataset(db, selected_dataset_id)
        if dataset:
            with st.form("edit_dataset_form"):
                dataset_name = st.text_input("Dataset Name", value=dataset.dataset_name)
                source = st.text_input("Source", value=dataset.source)
                description = st.text_area("Description", value=dataset.description)
                storage_location = st.text_input("Storage Location", value=dataset.storage_location)
                usage_type = st.selectbox("Usage Type", ["training", "validation", "benchmarking", "testing", "feature engineering"], index=["training", "validation", "benchmarking", "testing", "feature engineering"].index(dataset.usage_type))
                data_type = st.selectbox("Data Type", ["tabular", "image", "text", "time-series", "audio"], index=["tabular", "image", "text", "time-series", "audio"].index(dataset.data_type))
                format = st.text_input("Format", value=dataset.format)
                comments = st.text_area("Comments", value=dataset.comments)
                tags = st.text_input("Tags", value=dataset.tags)

                submit_button = st.form_submit_button("Update Dataset")

                if submit_button:
                    update_data = {
                        "dataset_name": dataset_name,
                        "source": source,
                        "description": description,
                        "storage_location": storage_location,
                        "usage_type": usage_type,
                        "data_type": data_type,
                        "format": format,
                        "comments": comments,
                        "tags": tags,
                        "last_modified_date": datetime.now()
                    }
                    update_dataset(db, selected_dataset_id, update_data)
                    st.success(f"Dataset '{dataset_name}' updated successfully.")

    elif action == "Remove Dataset":
        st.write("#### Remove Dataset")

        # Dropdown to select a dataset to remove
        datasets = get_all_datasets(db)
        dataset_options = {f"{ds.dataset_name} (ID: {ds.dataset_id})": ds.dataset_id for ds in datasets}
        selected_dataset_name = st.selectbox("Select Dataset to Remove", list(dataset_options.keys()))
        selected_dataset_id = dataset_options[selected_dataset_name]

        if st.button("Remove Dataset"):
            remove_dataset(db, selected_dataset_id)
            st.success(f"Dataset '{selected_dataset_name}' removed successfully.")

def benchmark_model_sidebar(db, benchmark_model_id):
    st.sidebar.header("Benchmark Model")

    with stylable_container(
        key="benchmark_sidebar",
        css_styles="""
            {background-color: #2f3640; color: #ffffff; border-radius: 5px; padding: 10px; margin-bottom: 10px;}
        """,
    ):
        option = st.sidebar.radio(
            "Actions",
            [
                "Edit Model",
                "Model Mapping",
                # "Models Overview",
                "Add Model",
                "Manage Datasets",
                "Compare Models",
            ],
            format_func=lambda x: x if x != "" else "Choose an action",
        )

    if option == "Add Model":
        add_benchmark_model(db)
    elif option == "Edit Model":
        benchmark_model_id = st.sidebar.number_input(
            "Benchmark Model ID", min_value=1, step=1
        )
        if benchmark_model_id:
            view_edit_benchmark_model(db, benchmark_model_id)
    elif option == "Model Mapping":
        # manage_benchmark_mapping()
        manage_benchmark_mapping(db)

    elif option == "Manage Datasets":
        # manage_benchmark_datasets()
        manage_datasets(db)

    elif option == "Compare Models":
        # validation_and_benchmark_comparison()
        pass
    else:
        st.sidebar.write("Select an option to begin.")


def load_overview(db, model_id):
    # st.write("### Benchmark")
    benchmark_model_sidebar(db, 1)
    # display_benchmark_models(db)
    # view_edit_benchmark_model(db,3)
    # add_benchmark_model(db)
