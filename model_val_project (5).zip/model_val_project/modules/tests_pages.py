import streamlit as st
from nbconvert import HTMLExporter
import nbformat
import os
from bs4 import BeautifulSoup
import subprocess
import socket
import webbrowser


import pandas as pd
import plotly.express as px
from datetime import datetime
from database.crud import get_model, get_model_validations, get_historical_metrics


notebook_port = 8888
venv_path = "../.venv"

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0
    
def start_jupyter_notebook():
    if not is_port_in_use(notebook_port):
        jupyter_executable = os.path.join(venv_path, "Scripts", "jupyter.exe")
        subprocess.Popen([jupyter_executable, "notebook", "--no-browser", "--port", str(notebook_port)], shell=True)
        st.success(f"Jupyter Notebook launched on http://localhost:{notebook_port}")
        webbrowser.open(f"http://localhost:{notebook_port}")
    else:
        st.info(f"Jupyter Notebook is already running on http://localhost:{notebook_port}")

def display_notebook_as_html(notebook_path):
    notebook_name = os.path.basename(notebook_path).replace(".ipynb", "")
    st.markdown(f"## 🗒️ {notebook_name}")
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    html_exporter = HTMLExporter()
    html_exporter.exclude_input = False
    html_exporter.embed_images = True
    html_exporter.exclude_output = False
    html_exporter.exclude_code_cell = False
    html_exporter.exclude_anchor_links = False
    html_exporter.exclude_markdown = False
    html_exporter.exclude_raw = False
    html_data, _ = html_exporter.from_notebook_node(notebook_content)
    soup = BeautifulSoup(html_data, "html.parser")
    toc = []
    for header in soup.find_all(["h1", "h2", "h3"]):
        section_id = header.text.replace(" ", "-").lower()
        header["id"] = section_id
        toc.append((header.text, f"#{section_id}"))
    st.markdown("### Table of Contents")
    for title, link in toc:
        st.markdown(f"- [{title}]({link})", unsafe_allow_html=True)
    st.components.v1.html(
        f"<div style='border: 1px solid #ddd; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>{str(soup)}</div>",
        height=800,
        scrolling=True
    )

def display_notebook_as_sections(notebook_path):
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    html_exporter = HTMLExporter()
    html_exporter.exclude_input = False
    html_exporter.embed_images = True
    html_exporter.exclude_output = False
    html_exporter.exclude_code_cell = False
    html_exporter.exclude_anchor_links = False
    html_exporter.exclude_markdown = False
    html_exporter.exclude_raw = False
    html_data, _ = html_exporter.from_notebook_node(notebook_content)
    soup = BeautifulSoup(html_data, "html.parser")
    sections = [(header.text, header.find_next_sibling().decode() if header.find_next_sibling() else "") for header in soup.find_all(["h1", "h2", "h3"])]
    st.markdown("### Table of Contents")
    for i, (title, _) in enumerate(sections):
        if st.button(f"Go to {title}", key=f"toc_{i}"):
            st.session_state.selected_section = i
    if "selected_section" in st.session_state:
        st.markdown(f"### {sections[st.session_state.selected_section][0]}")
        st.components.v1.html(sections[st.session_state.selected_section][1], height=800, scrolling=True)

def execute_cells_with_keyword(notebook_path, keyword):
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    for cell in notebook_content.cells:
        if cell.cell_type == 'code' and cell.source.startswith(keyword):
            st.code(cell.source, language='python')
            exec(cell.source, globals())

def connect_to_jupyter_notebook():
    st.write("### Connect to Jupyter Notebook")
    
    # Select between local and remote Jupyter Notebook
    connection_type = st.radio("Connection Type", ["Local", "Remote"])

    if connection_type == "Local":
        local_port = st.number_input("Enter Jupyter Notebook Port", value=8888, step=1)
        jupyter_url = f"http://localhost:{local_port}"
        st.write(f"Connecting to local Jupyter instance at {jupyter_url}")
    else:
        remote_ip = st.text_input("Enter Remote Jupyter IP or Domain")
        remote_port = st.number_input("Enter Remote Jupyter Port", value=8888, step=1)
        jupyter_url = f"http://{remote_ip}:{remote_port}"
        st.write(f"Connecting to remote Jupyter instance at {jupyter_url}")

def display_model_performance_metrics(db, model_id):
    model = get_model(db, model_id)
    if not model:
        st.error("Model not found.")
        return

    st.write(f"## {model.model_name} - Performance Overview")

    # Display basic model details
    st.markdown("### General Information")
    col1, col2 = st.columns(2)
    col1.metric("Model Type", model.model_type)
    col1.metric("Business Line", model.business_line)
    col1.metric("Algorithm", model.algorithm)
    col2.metric("Risk Rating", model.risk_rating)
    col2.metric("Validation Rating", model.validation_rating)
    col2.metric("Status", model.model_status)

    # Historical Performance Trends
    st.markdown("### Historical Performance Trends")
    historical_data = get_historical_metrics(db, model_id)
    if historical_data:
        history_df = pd.DataFrame(historical_data)
        
        # Adjust chart with available columns
        fig = px.line(history_df, x="invocation_timestamp", y=["metrics"],
                      title="Historical Performance Metrics")
        st.plotly_chart(fig)
    else:
        st.info("No historical data available.")

    # Related Validations and Findings
    st.markdown("### Related Validations")
    validations = get_model_validations(db, model_id)
    if validations:
        validations_df = pd.DataFrame([{
            "Validation Date": v.validation_date,
            "Validator Name": v.validator_name,
            "Status": v.validation_status,
            "Validation Score": v.validation_score,
            "Comments": v.validation_comments
        } for v in validations])
        st.dataframe(validations_df)
    else:
        st.info("No validation data available.")

def load_tests(db):
    st.write("### Tests Overview")
    notebook_path = "1.ipynb"
    if "active_model_id" in st.session_state.keys():
        model_id = int(st.session_state["active_model_id"])
        # print(model_id)
    
    option = st.sidebar.radio("Select Action", ["Connect to Jupyter", "View Model Notebook", "Segmented View", "Execute Keyword Cells", "Display Performance Metrics"])

    if option == "Connect to Jupyter":
        connect_to_jupyter_notebook()
    elif option == "View Model Notebook":
        display_notebook_as_html(notebook_path)
    elif option == "Segmented View":
        display_notebook_as_sections(notebook_path)
    elif option == "Execute Keyword Cells":
        keyword = st.text_input("Enter keyword to execute cells", value="# Execute")
        if keyword:
            execute_cells_with_keyword(notebook_path, keyword)
    elif option == "Display Performance Metrics":
        display_model_performance_metrics(db, model_id)