import streamlit as st

def load_documentation(model_id):
    st.write("### doc Overview")
    st.write(f"Displaying details for Model ID: {model_id}")