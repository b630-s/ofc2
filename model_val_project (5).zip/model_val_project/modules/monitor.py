import streamlit as st

def load_monitor(model_id):
    st.write("### monitor Overview")
    st.write(f"Displaying details for Model ID: {model_id}")