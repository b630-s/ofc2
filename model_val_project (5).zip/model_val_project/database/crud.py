from sqlalchemy.orm import Session
from .models import Model, ModelValidation, Finding, Document
from typing import Dict
from .models import ModelInvocation
from .models import ActionPlan
from .models import BenchmarkModel
# from database.models import ModelBenchmarkMapping
from database.models import Dataset, ModelBenchmarkMapping
from typing import List, Dict

def get_all_datasets(db: Session) -> List[Dataset]:

    return db.query(Dataset).all()

def get_dataset(db: Session, dataset_id: int) -> Dataset:

    return db.query(Dataset).filter(Dataset.dataset_id == dataset_id).first()


def add_dataset(db: Session, dataset_data: Dict) -> Dataset:

    dataset = Dataset(**dataset_data)
    db.add(dataset)
    db.commit()
    db.refresh(dataset)
    return dataset


def update_dataset(db: Session, dataset_id: int, update_data: Dict) -> Dataset:

    dataset = get_dataset(db, dataset_id)
    if dataset:
        for key, value in update_data.items():
            setattr(dataset, key, value)
        db.commit()
        db.refresh(dataset)
    return dataset


def remove_dataset(db: Session, dataset_id: int) -> None:

    dataset = get_dataset(db, dataset_id)
    if dataset:
        db.delete(dataset)
        db.commit()

def get_benchmark_mappings_for_model(db: Session, primary_model_id: int):

    return db.query(ModelBenchmarkMapping).filter(ModelBenchmarkMapping.primary_model_id == primary_model_id).all()

def add_benchmark_mapping(db: Session, primary_model_id: int, benchmark_model_id: int, dataset_id: int, mapping_type: str):

    new_mapping = ModelBenchmarkMapping(
        primary_model_id=primary_model_id,
        benchmark_model_id=benchmark_model_id,
        dataset_id=dataset_id,
        mapping_type=mapping_type
    )
    db.add(new_mapping)
    db.commit()
    db.refresh(new_mapping)
    return new_mapping

def remove_benchmark_mapping(db: Session, primary_model_id: int, benchmark_model_id: int, dataset_id: int):

    mapping = db.query(ModelBenchmarkMapping).filter(
        ModelBenchmarkMapping.primary_model_id == primary_model_id,
        ModelBenchmarkMapping.benchmark_model_id == benchmark_model_id,
        ModelBenchmarkMapping.dataset_id == dataset_id
    ).first()
    if mapping:
        db.delete(mapping)
        db.commit()
        return True
    return False

def create_benchmark_model(db: Session, benchmark_model_data: dict):

    benchmark_model = BenchmarkModel(**benchmark_model_data)
    db.add(benchmark_model)
    db.commit()
    db.refresh(benchmark_model)
    return benchmark_model

def update_benchmark_model(db: Session, benchmark_model_id: int, update_data: dict):

    benchmark_model = db.query(BenchmarkModel).filter(BenchmarkModel.benchmark_model_id == benchmark_model_id).first()
    if benchmark_model:
        for key, value in update_data.items():
            setattr(benchmark_model, key, value)
        db.commit()
        db.refresh(benchmark_model)
    return benchmark_model
# CRUD operations for ActionPlan

def get_benchmark_model(db: Session, benchmark_model_id: int):
    return db.query(BenchmarkModel).filter(BenchmarkModel.benchmark_model_id == benchmark_model_id).first()

def get_all_benchmark_models(db: Session):
    return db.query(BenchmarkModel).all()

def create_action_plan(db: Session, action_plan_data: dict):
    """Create a new action plan."""
    action_plan = ActionPlan(**action_plan_data)
    db.add(action_plan)
    db.commit()
    db.refresh(action_plan)
    return action_plan

def get_action_plan(db: Session, action_id: int):
    """Get an action plan by ID."""
    return db.query(ActionPlan).filter(ActionPlan.action_id == action_id).first()

def get_all_action_plans(db: Session):
    """Get all action plans."""
    return db.query(ActionPlan).all()

def update_action_plan(db: Session, action_id: int, update_data: dict):
    """Update an existing action plan."""
    action_plan = db.query(ActionPlan).filter(ActionPlan.action_id == action_id).first()
    if action_plan:
        for key, value in update_data.items():
            setattr(action_plan, key, value)
        db.commit()
        db.refresh(action_plan)
    return action_plan

def delete_action_plan(db: Session, action_id: int):
    """Delete an action plan by ID."""
    action_plan = db.query(ActionPlan).filter(ActionPlan.action_id == action_id).first()
    if action_plan:
        db.delete(action_plan)
        db.commit()
    return action_plan


def create_model_invocation(db: Session, invocation_data: Dict):
    """Create a new model invocation record."""
    invocation = ModelInvocation(**invocation_data)
    db.add(invocation)
    db.commit()
    db.refresh(invocation)
    return invocation

def get_model_invocation(db: Session, invocation_id: int):
    """Retrieve a single model invocation record by its ID."""
    return db.query(ModelInvocation).filter(ModelInvocation.invocation_id == invocation_id).first()

def get_all_model_invitations(db: Session):
    """Retrieve all model invocation records."""
    return db.query(ModelInvocation).all()

def update_model_invocation(db: Session, invocation_id: int, update_data: Dict):
    """Update a model invocation record with new data."""
    invocation = db.query(ModelInvocation).filter(ModelInvocation.invocation_id == invocation_id).first()
    if invocation:
        for key, value in update_data.items():
            setattr(invocation, key, value)
        db.commit()
        db.refresh(invocation)
    return invocation

def delete_model_invocation(db: Session, invocation_id: int):
    """Delete a model invocation record by its ID."""
    invocation = db.query(ModelInvocation).filter(ModelInvocation.invocation_id == invocation_id).first()
    if invocation:
        db.delete(invocation)
        db.commit()
    return invocation


# CRUD operations for Model

def create_model(db: Session, model_data: dict):
    model = Model(**model_data)
    db.add(model)
    db.commit()
    db.refresh(model)
    return model
from sqlalchemy.sql import text
def get_model(db: Session, model_id: int):
    
    model =  db.query(Model).filter(Model.model_id == model_id).first()
    # print("getting for : ",model_id, model)
    # result = result = db.execute(text("SELECT * FROM models WHERE model_id = :model_id"), {"model_id": model_id}).fetchone()
    # print("Direct query result:", result)
    return model

def get_all_models(db: Session):
    return db.query(Model).all()


def update_model(db: Session, model_id: int, update_data: dict):
    model = db.query(Model).filter(Model.model_id == model_id).first()
    if model:
        for key, value in update_data.items():
            setattr(model, key, value)
        db.commit()
        db.refresh(model)
    return model

def delete_model(db: Session, model_id: int):
    model = db.query(Model).filter(Model.model_id == model_id).first()
    if model:
        db.delete(model)
        db.commit()
    return model

# CRUD operations for ModelValidation
def get_model_validations(db: Session, model_id: int):
    return db.query(ModelValidation).filter(ModelValidation.model_id == model_id).all()

def create_model_validation(db: Session, validation_data: dict):
    validation = ModelValidation(**validation_data)
    db.add(validation)
    db.commit()
    db.refresh(validation)
    return validation

def get_model_validation(db: Session, validation_id: int):
    return db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()

def get_all_model_validations(db: Session):
    return db.query(ModelValidation).all()

def update_model_validation(db: Session, validation_id: int, update_data: dict):
    validation = db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()
    if validation:
        for key, value in update_data.items():
            setattr(validation, key, value)
        db.commit()
        db.refresh(validation)
    return validation

def delete_model_validation(db: Session, validation_id: int):
    validation = db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()
    if validation:
        db.delete(validation)
        db.commit()
    return validation

# CRUD operations for Finding

def create_finding(db: Session, finding_data: dict):
    finding = Finding(**finding_data)
    db.add(finding)
    db.commit()
    db.refresh(finding)
    return finding

def get_finding(db: Session, finding_id: int):
    return db.query(Finding).filter(Finding.finding_id == finding_id).first()

def get_all_findings(db: Session):
    return db.query(Finding).all()

def update_finding(db: Session, finding_id: int, update_data: dict):
    finding = db.query(Finding).filter(Finding.finding_id == finding_id).first()
    if finding:
        for key, value in update_data.items():
            setattr(finding, key, value)
        db.commit()
        db.refresh(finding)
    return finding

def delete_finding(db: Session, finding_id: int):
    finding = db.query(Finding).filter(Finding.finding_id == finding_id).first()
    if finding:
        db.delete(finding)
        db.commit()
    return finding

# CRUD operations for Document

def create_document(db: Session, document_data: dict):
    document = Document(**document_data)
    db.add(document)
    db.commit()
    db.refresh(document)
    return document

def get_document(db: Session, document_id: int):
    return db.query(Document).filter(Document.document_id == document_id).first()

def get_all_documents(db: Session):
    return db.query(Document).all()

def update_document(db: Session, document_id: int, update_data: dict):
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if document:
        for key, value in update_data.items():
            setattr(document, key, value)
        db.commit()
        db.refresh(document)
    return document

def delete_document(db: Session, document_id: int):
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if document:
        db.delete(document)
        db.commit()
    return document


def get_model_for_validation(db: Session, validation_id: int):
    # Query the Model associated with the given validation_id
    validation = db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()
    if validation:
        return db.query(Model).filter(Model.model_id == validation.model_id).first()
    return None

def get_historical_metrics(db: Session, model_id: int):
    return (
        db.query(ModelInvocation.invocation_timestamp, ModelInvocation.metrics)
        .filter(ModelInvocation.validation_id == model_id)
        .order_by(ModelInvocation.invocation_timestamp.asc())
        .all()
    )

