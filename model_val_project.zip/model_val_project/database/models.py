from sqlalchemy import create_engine, Column, Integer, String, Date, Enum, ForeignKey, CheckConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import date, datetime

Base = declarative_base()

class Model(Base):
    __tablename__ = 'models'

    model_id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String, nullable=False)
    model_type = Column(String)
    business_line = Column(String)
    algorithm = Column(String)
    model_developer = Column(String)
    creation_date = Column(Date)
    last_modified_date = Column(Date)
    owner_entity = Column(String)
    materiality = Column(String)
    complexity = Column(String)
    validation_frequency = Column(String)
    last_validation_date = Column(Date)
    next_validation_date = Column(Date)
    model_status = Column(String, CheckConstraint("model_status IN ('active', 'inactive', 'deprecated')"))
    risk_rating = Column(String)

    # Relationships
    model_validations = relationship('ModelValidation', back_populates='model')
    documents = relationship('Document', back_populates='model')

    @classmethod
    def get_sample_data(cls):
        """Sample data for the models table."""
        return [
            {
                "model_name": "Credit Risk Model", 
                "model_type": "Financial", 
                "business_line": "Retail Banking",
                "algorithm": "Logistic Regression", 
                "model_developer": "Team A", 
                "creation_date": datetime.strptime("2023-01-15", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime("2023-08-10", "%Y-%m-%d").date(), 
                "owner_entity": "Risk Management Dept", 
                "materiality": "High",
                "complexity": "Complex", 
                "validation_frequency": "Annual", 
                "last_validation_date": datetime.strptime("2023-08-01", "%Y-%m-%d").date(),
                "next_validation_date": datetime.strptime("2024-08-01", "%Y-%m-%d").date(), 
                "model_status": "active", 
                "risk_rating": "Medium"
            },
            {
                "model_name": "Fraud Detection Model", 
                "model_type": "ML", 
                "business_line": "Credit Card Services",
                "algorithm": "Random Forest", 
                "model_developer": "Team B", 
                "creation_date": datetime.strptime("2022-10-20", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime("2023-07-05", "%Y-%m-%d").date(), 
                "owner_entity": "Compliance Dept", 
                "materiality": "Medium",
                "complexity": "Moderate", 
                "validation_frequency": "Semi-Annual", 
                "last_validation_date": datetime.strptime("2023-07-01", "%Y-%m-%d").date(),
                "next_validation_date": datetime.strptime("2024-01-01", "%Y-%m-%d").date(), 
                "model_status": "active", 
                "risk_rating": "High"
            },
            {
                "model_name": "Market Analysis Model", 
                "model_type": "Statistical", 
                "business_line": "Investment Banking",
                "algorithm": "Time Series Analysis", 
                "model_developer": "Team C", 
                "creation_date": datetime.strptime("2021-05-10", "%Y-%m-%d").date(),
                "last_modified_date": datetime.strptime("2023-06-15", "%Y-%m-%d").date(), 
                "owner_entity": "Market Research Dept", 
                "materiality": "Low",
                "complexity": "Simple", 
                "validation_frequency": "Annual", 
                "last_validation_date": datetime.strptime("2023-06-01", "%Y-%m-%d").date(),
                "next_validation_date": datetime.strptime("2024-06-01", "%Y-%m-%d").date(), 
                "model_status": "active", 
                "risk_rating": "Low"
            }
        ]
    


class ModelValidation(Base):
    __tablename__ = 'model_validations'

    validation_id = Column(Integer, primary_key=True, autoincrement=True)
    model_id = Column(Integer, ForeignKey('models.model_id'), nullable=False)
    validation_date = Column(Date, default=date.today)
    validator_name = Column(String, nullable=False)
    validation_status = Column(String, CheckConstraint("validation_status IN ('in progress', 'completed', 'rejected')"), nullable=False)
    validation_score = Column(String, nullable=True)
    validation_comments = Column(String, nullable=True)

    # Relationships
    model = relationship('Model', back_populates='model_validations')
    findings = relationship('Finding', back_populates='model_validation')
    documents = relationship("Document", back_populates="validation")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the model_validations table."""
        return [
            {
                "model_id": 1,
                "validation_date": datetime.strptime("2023-08-01", "%Y-%m-%d").date(),
                "validator_name": "John Doe",
                "validation_status": "completed",
                "validation_score": "85",
                "validation_comments": "Validation completed successfully."
            },
            {
                "model_id": 2,
                "validation_date": datetime.strptime("2023-07-15", "%Y-%m-%d").date(),
                "validator_name": "Jane Smith",
                "validation_status": "in progress",
                "validation_score": "N/A",
                "validation_comments": "Still working on validation."
            },
            {
                "model_id": 3,
                "validation_date": datetime.strptime("2023-06-10", "%Y-%m-%d").date(),
                "validator_name": "Emily Brown",
                "validation_status": "rejected",
                "validation_score": "60",
                "validation_comments": "Validation failed due to model complexity."
            }
        ]

class Finding(Base):
    __tablename__ = 'findings'

    finding_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(Integer, ForeignKey('model_validations.validation_id'), nullable=False)
    finding_type = Column(String, CheckConstraint("finding_type IN ('numeric', 'text')"), nullable=False)
    finding_value = Column(String, nullable=True)
    finding_status = Column(String, CheckConstraint("finding_status IN ('open', 'closed', 'in progress')"), nullable=False)
    finding_comments = Column(String, nullable=True)

    # Risk assessment attributes
    risk_category = Column(Enum('model', 'operational', 'compliance', 'financial', 'technical', name='risk_categories'), nullable=True)
    risk_description = Column(String, nullable=True)
    risk_score = Column(Integer, nullable=True)
    mitigation_plan = Column(String, nullable=True)
    assessment_status = Column(String, CheckConstraint("assessment_status IN ('open', 'mitigated', 'closed')"), nullable=True)

    # Relationships
    model_validation = relationship('ModelValidation', back_populates='findings')

    @classmethod
    def get_sample_data(cls):
        """Sample data for the findings table."""
        return  [
            {
                "finding_id": 1,
                "validation_id": 1,
                "finding_type": "numeric",
                "finding_value": "85%",
                "finding_status": "open",
                "finding_comments": "Initial finding comment.",
                "risk_category": "operational",
                "risk_description": "System performance below expected levels.",
                "risk_score": 7,
                "mitigation_plan": "Increase system resources and optimize code.",
                "assessment_status": "open"
            },
            {
                "finding_id": 2,
                "validation_id": 1,
                "finding_type": "text",
                "finding_value": "Minor issue identified with data integrity.",
                "finding_status": "closed",
                "finding_comments": "Issue resolved and data integrity checks are now in place.",
                "risk_category": "compliance",
                "risk_description": "Data integrity issues potentially affecting compliance.",
                "risk_score": 5,
                "mitigation_plan": "Implemented additional data validation checks.",
                "assessment_status": "mitigated"
            },
            {
                "finding_id": 3,
                "validation_id": 2,
                "finding_type": "text",
                "finding_value": "Outlier detected in recent dataset.",
                "finding_status": "in progress",
                "finding_comments": "Pending further analysis and investigation.",
                "risk_category": "financial",
                "risk_description": "Potential impact on financial forecasting accuracy.",
                "risk_score": 8,
                "mitigation_plan": "Analyze outlier impact and adjust forecasting models as needed.",
                "assessment_status": "open"
            },
            {
                "finding_id": 4,
                "validation_id": 2,
                "finding_type": "numeric",
                "finding_value": "90% accuracy drop in model predictions.",
                "finding_status": "open",
                "finding_comments": "High discrepancy observed requiring urgent attention.",
                "risk_category": "technical",
                "risk_description": "Significant drop in model accuracy affecting operational efficiency.",
                "risk_score": 9,
                "mitigation_plan": "Review model algorithm and retrain with updated data.",
                "assessment_status": "open"
            },
            {
                "finding_id": 5,
                "validation_id": 3,
                "finding_type": "numeric",
                "finding_value": "15% deviation from expected outcome.",
                "finding_status": "in progress",
                "finding_comments": "Ongoing investigation into the cause of deviation.",
                "risk_category": "model",
                "risk_description": "Deviation affecting model performance and decision-making.",
                "risk_score": 6,
                "mitigation_plan": "Conduct a thorough review of model parameters and retrain if necessary.",
                "assessment_status": "open"
            }
        ]

class Document(Base):
    __tablename__ = 'documents'

    document_id = Column(Integer, primary_key=True, autoincrement=True)
    model_id = Column(Integer, ForeignKey('models.model_id'), nullable=True)
    validation_id = Column(Integer, ForeignKey('model_validations.validation_id'), nullable=True)
    document_name = Column(String, nullable=False)
    document_path = Column(String, nullable=False)
    document_type = Column(String, CheckConstraint("document_type IN ('model', 'validation')"), nullable=False)
    upload_date = Column(Date, default=date.today)

    model = relationship("Model", back_populates="documents")
    validation = relationship("ModelValidation", back_populates="documents")

    __table_args__ = (
        CheckConstraint(
            '(model_id IS NOT NULL AND validation_id IS NULL) OR (model_id IS NULL AND validation_id IS NOT NULL)',
            name='check_model_or_validation'
        ),
    )

    @classmethod
    def get_sample_data(cls):
        """Sample data for the documents table."""
        return  [
            {
                "document_id": 1,
                "model_id": 1,
                "validation_id": None,
                "document_name": "Model Specification",
                "document_path": "./docs/model_specification.pdf",
                "document_type": "model",
                "upload_date": date(2024, 1, 15)
            },
            {
                "document_id": 2,
                "model_id": 1,
                "validation_id": None,
                "document_name": "Model Architecture Diagram",
                "document_path": "./docs/model_architecture.png",
                "document_type": "model",
                "upload_date": date(2024, 1, 20)
            },
            {
                "document_id": 3,
                "model_id": None,
                "validation_id": 1,
                "document_name": "Validation Report Q1 2024",
                "document_path": "./docs/validation_report_q1_2024.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 2, 5)
            },
            {
                "document_id": 4,
                "model_id": None,
                "validation_id": 1,
                "document_name": "Finding Details Report",
                "document_path": "./docs/finding_details_report.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 2, 10)
            },
            {
                "document_id": 5,
                "model_id": None,
                "validation_id": 2,
                "document_name": "Validation Summary",
                "document_path": "./docs/validation_summary.pdf",
                "document_type": "validation",
                "upload_date": date(2024, 3, 1)
            }
        ]

# Create an engine and session
# engine = create_engine('sqlite:///./database.db')
# Session = sessionmaker(bind=engine)
# session = Session()

# # Create tables
# Base.metadata.create_all(engine)
