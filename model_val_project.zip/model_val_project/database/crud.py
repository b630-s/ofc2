from sqlalchemy.orm import Session
from .models import Model, ModelValidation, Finding, Document

# CRUD operations for Model

def create_model(db: Session, model_data: dict):
    model = Model(**model_data)
    db.add(model)
    db.commit()
    db.refresh(model)
    return model

def get_model(db: Session, model_id: int):
    return db.query(Model).filter(Model.model_id == model_id).first()

def get_all_models(db: Session):
    return db.query(Model).all()


def update_model(db: Session, model_id: int, update_data: dict):
    model = db.query(Model).filter(Model.model_id == model_id).first()
    if model:
        for key, value in update_data.items():
            setattr(model, key, value)
        db.commit()
        db.refresh(model)
    return model

def delete_model(db: Session, model_id: int):
    model = db.query(Model).filter(Model.model_id == model_id).first()
    if model:
        db.delete(model)
        db.commit()
    return model

# CRUD operations for ModelValidation

def create_model_validation(db: Session, validation_data: dict):
    validation = ModelValidation(**validation_data)
    db.add(validation)
    db.commit()
    db.refresh(validation)
    return validation

def get_model_validation(db: Session, validation_id: int):
    return db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()

def get_all_model_validations(db: Session):
    return db.query(ModelValidation).all()

def update_model_validation(db: Session, validation_id: int, update_data: dict):
    validation = db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()
    if validation:
        for key, value in update_data.items():
            setattr(validation, key, value)
        db.commit()
        db.refresh(validation)
    return validation

def delete_model_validation(db: Session, validation_id: int):
    validation = db.query(ModelValidation).filter(ModelValidation.validation_id == validation_id).first()
    if validation:
        db.delete(validation)
        db.commit()
    return validation

# CRUD operations for Finding

def create_finding(db: Session, finding_data: dict):
    finding = Finding(**finding_data)
    db.add(finding)
    db.commit()
    db.refresh(finding)
    return finding

def get_finding(db: Session, finding_id: int):
    return db.query(Finding).filter(Finding.finding_id == finding_id).first()

def get_all_findings(db: Session):
    return db.query(Finding).all()

def update_finding(db: Session, finding_id: int, update_data: dict):
    finding = db.query(Finding).filter(Finding.finding_id == finding_id).first()
    if finding:
        for key, value in update_data.items():
            setattr(finding, key, value)
        db.commit()
        db.refresh(finding)
    return finding

def delete_finding(db: Session, finding_id: int):
    finding = db.query(Finding).filter(Finding.finding_id == finding_id).first()
    if finding:
        db.delete(finding)
        db.commit()
    return finding

# CRUD operations for Document

def create_document(db: Session, document_data: dict):
    document = Document(**document_data)
    db.add(document)
    db.commit()
    db.refresh(document)
    return document

def get_document(db: Session, document_id: int):
    return db.query(Document).filter(Document.document_id == document_id).first()

def get_all_documents(db: Session):
    return db.query(Document).all()

def update_document(db: Session, document_id: int, update_data: dict):
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if document:
        for key, value in update_data.items():
            setattr(document, key, value)
        db.commit()
        db.refresh(document)
    return document

def delete_document(db: Session, document_id: int):
    document = db.query(Document).filter(Document.document_id == document_id).first()
    if document:
        db.delete(document)
        db.commit()
    return document
