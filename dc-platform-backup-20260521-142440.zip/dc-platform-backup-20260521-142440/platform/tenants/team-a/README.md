Team A tenant bundle for a second Spark-style workload namespace.

This bundle owns:
- the `team-a` namespace
- the `spark-team-a-sa` service account
- namespace-scoped RBAC for Spark runtime objects in `team-a`

Identity handoff:
- the current Team A tenant uses the Terraform workload identity key `team_a`
- `platform/scripts/20-deploy-platform.sh` will annotate `team-a/spark-team-a-sa` automatically if this tenant is deployed and Terraform output `workload_identities` is available
- this bundle's `deploy.sh` can also annotate the service account directly when Terraform output is available

Current operator scope:
- the shared Spark Operator allowlist includes both `spark` and `team-a`
- additional tenants should be added deliberately to `platform/addons/spark-operator/values.yaml`

Deploy manually when you are ready to onboard the tenant:

```bash
./platform/tenants/team-a/deploy.sh
```
