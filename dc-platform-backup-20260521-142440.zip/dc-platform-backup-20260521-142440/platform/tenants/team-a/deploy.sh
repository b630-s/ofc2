#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
TEAM_A_NAMESPACE="${TEAM_A_NAMESPACE:-team-a}"
TEAM_A_SERVICE_ACCOUNT="${TEAM_A_SERVICE_ACCOUNT:-spark-team-a-sa}"
WORKLOAD_IDENTITY_ANNOTATION_KEY="${WORKLOAD_IDENTITY_ANNOTATION_KEY:-eks.amazonaws.com/role-arn}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[tenant-team-a] %s\n' "$*"
}

main() {
  require_cmd kubectl

  log "Applying Team A tenant namespace, service account, and RBAC"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"
  kubectl apply -f "${SCRIPT_DIR}/rbac.yaml"
  kubectl annotate serviceaccount "${TEAM_A_SERVICE_ACCOUNT}" \
    --namespace "${TEAM_A_NAMESPACE}" \
    "${WORKLOAD_IDENTITY_ANNOTATION_KEY}-" >/dev/null 2>&1 || true
}

main "$@"
