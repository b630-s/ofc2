Reference tenant bundle for the shared example Spark namespace.

This bundle owns:
- the `spark` namespace used by the reference workloads
- the `spark-sa` service account
- namespace-scoped RBAC for SparkApplication runtime objects
- the `iceberg-client-config` ConfigMap used by Polaris-backed Spark Iceberg jobs

This bundle does not install the Spark Operator itself. That stays in:
- `platform/addons/spark-operator/`

It also consumes the shared Polaris-side Iceberg client template from:
- `platform/addons/polaris/iceberg-client-config.yaml`

Identity handoff:
- `spark-sa` is the Kubernetes runtime identity for Spark orchestration and Polaris access
- Spark runtime storage access should come from Polaris-vended credentials for Iceberg or from a Kubernetes-managed object-store secret for direct writes and Spark event logs
- this bundle does not annotate `spark-sa` with an IRSA role
- if a cluster previously used an EKS IRSA annotation on `spark-sa`, this deploy script removes it

Typical usage:

```bash
./platform/tenants/reference/deploy.sh
```

This directory is the template for future team or app tenants such as:
- `platform/tenants/team-a/`
- `platform/tenants/spark-orders/`
