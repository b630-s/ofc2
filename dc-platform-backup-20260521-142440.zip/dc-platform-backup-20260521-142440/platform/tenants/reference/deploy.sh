#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
SPARK_NAMESPACE="${SPARK_NAMESPACE:-spark}"
SPARK_SERVICE_ACCOUNT="${SPARK_SERVICE_ACCOUNT:-spark-sa}"
POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
POLARIS_SERVICE="${POLARIS_SERVICE:-polaris}"
POLARIS_CATALOG_URI="${POLARIS_CATALOG_URI:-http://${POLARIS_SERVICE}.${POLARIS_NAMESPACE}.svc.cluster.local:8181/api/catalog}"
POLARIS_ADDON_DIR="${REPO_ROOT}/platform/addons/polaris"
POLARIS_S3_PATH_STYLE_ACCESS="${POLARIS_S3_PATH_STYLE_ACCESS:-${OBJECT_STORE_PATH_STYLE_ACCESS:-false}}"
WORKLOAD_IDENTITY_ANNOTATION_KEY="${WORKLOAD_IDENTITY_ANNOTATION_KEY:-eks.amazonaws.com/role-arn}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[tenant-reference] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd envsubst

  log "Applying reference tenant namespace, service account, and RBAC"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"
  kubectl apply -f "${SCRIPT_DIR}/rbac.yaml"
  kubectl annotate serviceaccount "${SPARK_SERVICE_ACCOUNT}" \
    --namespace "${SPARK_NAMESPACE}" \
    "${WORKLOAD_IDENTITY_ANNOTATION_KEY}-" >/dev/null 2>&1 || true

  log "Applying shared Iceberg client config into ${SPARK_NAMESPACE}"
  TARGET_NAMESPACE="${SPARK_NAMESPACE}" \
  POLARIS_CATALOG_URI="${POLARIS_CATALOG_URI}" \
  POLARIS_S3_PATH_STYLE_ACCESS="${POLARIS_S3_PATH_STYLE_ACCESS}" \
    envsubst < "${POLARIS_ADDON_DIR}/iceberg-client-config.yaml" | kubectl apply -f -
}

main "$@"
