#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl

  kubectl delete -f "${SCRIPT_DIR}/rbac.yaml" --ignore-not-found
  kubectl delete -f "${SCRIPT_DIR}/service-account.yaml" --ignore-not-found
  kubectl delete -f "${SCRIPT_DIR}/namespace.yaml" --ignore-not-found
}

main "$@"
