#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
KAFKA_ADDON_DIR="${REPO_ROOT}/platform/addons/kafka"
# shellcheck source=lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"

KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"
KAFKA_CLUSTER_NAME="${KAFKA_CLUSTER_NAME:-reference-kafka}"
KAFKA_BOOTSTRAP_SERVICE="${KAFKA_BOOTSTRAP_SERVICE:-reference-kafka-kafka-bootstrap}"
KAFKA_BOOTSTRAP_PORT="${KAFKA_BOOTSTRAP_PORT:-9092}"
KAFKA_TOPIC="${KAFKA_TOPIC:-orders_raw}"
KAFKA_DLQ_TOPIC="${KAFKA_DLQ_TOPIC:-orders_dlq}"

write_platform_config_kafka_section() {
  platform_config_write_section "kafka" "platform/scripts/30-deploy-kafka.sh" <<EOF
$(platform_config_write_env_var KAFKA_NAMESPACE "${KAFKA_NAMESPACE}")
$(platform_config_write_env_var KAFKA_CLUSTER_NAME "${KAFKA_CLUSTER_NAME}")
$(platform_config_write_env_var KAFKA_BOOTSTRAP_SERVICE "${KAFKA_BOOTSTRAP_SERVICE}")
$(platform_config_write_env_var KAFKA_BOOTSTRAP_PORT "${KAFKA_BOOTSTRAP_PORT}")
$(platform_config_write_env_var KAFKA_BOOTSTRAP_SERVER "${KAFKA_BOOTSTRAP_SERVICE}.${KAFKA_NAMESPACE}.svc.cluster.local:${KAFKA_BOOTSTRAP_PORT}")
$(platform_config_write_env_var KAFKA_TOPIC "${KAFKA_TOPIC}")
$(platform_config_write_env_var KAFKA_DLQ_TOPIC "${KAFKA_DLQ_TOPIC}")
EOF
}

main() {
  "${KAFKA_ADDON_DIR}/deploy.sh" "$@"
  write_platform_config_kafka_section
}

main "$@"
