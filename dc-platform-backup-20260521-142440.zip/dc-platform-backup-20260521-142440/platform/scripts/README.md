# Platform Scripts

#SUMMARY COMMANDS: Start

This folder contains the canonical platform lifecycle scripts.
deploy infra
deploy platform
test workloads
clean up platform/workloads
destroy infra


cd ~/work/dc-platform
./platform/scripts/aws/10-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
helm version
export POLARIS_DB_PASSWORD='polaris'
./platform/scripts/20-deploy-platform.sh
./platform/scripts/30-deploy-kafka.sh
./platform/scripts/60-validate-platform.sh
./platform/scripts/40-bootstrap-polaris-admin.sh
./platform/scripts/50-bootstrap-polaris-reference.sh
./platform/scripts/70-validate-polaris-config.sh
kubectl get ns
kubectl get sa -A | egrep 'spark-sa|airflow-sa|polaris-sa'
kubectl get pods -A

Move to now refernce workloads, scripts dir.

#SUMMARY COMMANDS: End


# DETAILED COMMANDS BELOW
## Execution Order

From the repo root:

```bash
./infra/aws/deploy-infra.sh --apply
./platform/scripts/aws/10-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
helm version
export POLARIS_DB_PASSWORD='polaris'
./platform/scripts/20-deploy-platform.sh
./platform/scripts/30-deploy-kafka.sh
./platform/scripts/60-validate-platform.sh
./platform/scripts/40-bootstrap-polaris-admin.sh
./platform/scripts/50-bootstrap-polaris-reference.sh
./platform/scripts/70-validate-polaris-config.sh
```

Cleanup later:

```bash
./platform/scripts/90-cleanup-platform.sh
./infra/aws/destroy-infra.sh
```

## What Each Script Does

- `aws/10-connect-cluster.sh`
  Updates kubeconfig so `kubectl` and Helm point to the EKS cluster named in `infra/aws/terraform.tfvars`.

- `20-deploy-platform.sh`
  Installs namespaces, service accounts, Strimzi, Spark Operator, Airflow, Polaris, Prometheus/Grafana, and JupyterHub by default. Ingress remains optional.

- `30-deploy-kafka.sh`
  Deploys the shared Kafka cluster, node pools, and reference topics after the platform layer is installed.

- `60-validate-platform.sh`
  Validates nodes and installed platform services.

- `port-forward.sh`
  Starts one local `kubectl port-forward` per enabled UI service and shuts them all down together on `Ctrl-C`.

- `spark-port-forward.sh`
  Forwards the Spark UI for one running Spark application or driver pod to localhost.

- `70-validate-polaris-config.sh`
  Validates the Polaris configuration layer after bootstrap, including the reference catalog, namespaces, principal, roles, and key grant wiring.

- `40-bootstrap-polaris-admin.sh`
  Bootstraps the Polaris realm and explicit root/admin credentials after Polaris is installed.

- `50-bootstrap-polaris-reference.sh`
  Bootstraps the shared reference Polaris catalog, namespaces, and Spark principal wiring after Polaris admin bootstrap is complete. This script now uses the Polaris REST APIs through `kubectl`, `curl`, and `jq`.

- `90-cleanup-platform.sh`
  Removes platform services from Kubernetes without deleting AWS infrastructure.

## Before Running 20

1. Infra apply has completed successfully:
   `./infra/aws/deploy-infra.sh --apply`

2. Your shell is connected to the EKS cluster:
   `./platform/scripts/aws/10-connect-cluster.sh`

3. Quick cluster sanity check passes:

```bash
kubectl get nodes
kubectl get pods -n kube-system
```

4. Helm is installed:

```bash
helm version
```

If Helm is missing in CloudShell:

```bash
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

5. Polaris database password is exported:

```bash
export POLARIS_DB_PASSWORD='polaris'
```

Then run:

```bash
./platform/scripts/20-deploy-platform.sh
```

## Notes

- `20-deploy-platform.sh` now prefers the structured Terraform output `workload_identities` for IAM handoff and will annotate any matching service accounts it finds in the cluster.
- If Terraform state is not available locally, `20-deploy-platform.sh` still accepts the legacy platform-side environment variable `POLARIS_S3_ROLE_ARN`.
- Spark runtime storage access no longer uses `SPARK_S3_ROLE_ARN`; use the workload object-store secret flow for direct Spark writes instead.
- On AWS, `deploy-infra.sh --apply` writes `PLATFORM_STORAGE_CLASS` into the shared platform handoff and creates the configured StorageClass resource. Export `PLATFORM_STORAGE_CLASS` manually only if you need a one-off override.
- Kafka node pool persistence defaults to `PLATFORM_STORAGE_CLASS`; override it independently with `KAFKA_STORAGE_CLASS` only if needed.
- `90-cleanup-platform.sh` acts on the currently connected Kubernetes cluster, so verify kube context before deleting.


Misc:
apply just Strimzi again:

cd ~/work/dc-platform
helm upgrade --install strimzi-kafka-operator strimzi/strimzi-kafka-operator \
  --namespace platform-system \
  --create-namespace \
  --version 0.51.0 \
  --values platform/addons/strimzi/values.yaml \
  --wait \
  --timeout 10m
