#!/usr/bin/env bash

polaris_provider_validate() {
  if [[ -z "${POLARIS_GCS_SERVICE_ACCOUNT:-}" ]]; then
    echo "Set POLARIS_GCS_SERVICE_ACCOUNT to the GCS service account email Polaris should use." >&2
    exit 1
  fi

  log "Using POLARIS_GCS_SERVICE_ACCOUNT=${POLARIS_GCS_SERVICE_ACCOUNT}"
}

polaris_provider_storage_config() {
  jq -cn \
    --arg serviceAccountEmail "${POLARIS_GCS_SERVICE_ACCOUNT}" \
    --arg allowed "${REFERENCE_ALLOWED_LOCATION}" \
    '{
      storageType: "GCS",
      serviceAccountEmail: $serviceAccountEmail,
      allowedLocations: [$allowed]
    }'
}
