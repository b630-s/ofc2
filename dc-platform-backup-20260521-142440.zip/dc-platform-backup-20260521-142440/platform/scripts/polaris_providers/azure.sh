#!/usr/bin/env bash

polaris_provider_validate() {
  if [[ -z "${POLARIS_AZURE_TENANT_ID:-}" ]]; then
    echo "Set POLARIS_AZURE_TENANT_ID to the Azure tenant ID Polaris should use." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_AZURE_MULTI_TENANT_APP_NAME:-}" ]]; then
    echo "Set POLARIS_AZURE_MULTI_TENANT_APP_NAME to the Azure multi-tenant app name Polaris should use." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS:-}" ]]; then
    echo "Set POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS to a comma-separated list of Azure subscription IDs Polaris should use." >&2
    exit 1
  fi

  log "Using POLARIS_AZURE_TENANT_ID=${POLARIS_AZURE_TENANT_ID}"
  log "Using POLARIS_AZURE_MULTI_TENANT_APP_NAME=${POLARIS_AZURE_MULTI_TENANT_APP_NAME}"
}

polaris_provider_storage_config() {
  jq -cn \
    --arg tenantId "${POLARIS_AZURE_TENANT_ID}" \
    --arg multiTenantAppName "${POLARIS_AZURE_MULTI_TENANT_APP_NAME}" \
    --arg consentedSubscriptionIds "${POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS}" \
    --arg allowed "${REFERENCE_ALLOWED_LOCATION}" \
    '{
      storageType: "AZURE",
      tenantId: $tenantId,
      multiTenantAppName: $multiTenantAppName,
      consentedSubscriptionIds: (
        $consentedSubscriptionIds
        | split(",")
        | map(gsub("^\\s+|\\s+$"; ""))
        | map(select(length > 0))
      ),
      allowedLocations: [$allowed]
    }'
}
