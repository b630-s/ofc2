#!/usr/bin/env bash

polaris_provider_validate() {
  local resolved_binding

  if [[ -z "${POLARIS_ROLE_ARN:-}" && -n "${POLARIS_S3_ROLE_ARN:-}" ]]; then
    POLARIS_ROLE_ARN="${POLARIS_S3_ROLE_ARN}"
    log "Resolved POLARIS_ROLE_ARN from POLARIS_S3_ROLE_ARN"
  fi

  if [[ -z "${POLARIS_ROLE_ARN:-}" ]]; then
    if resolved_binding="$(resolve_workload_identity_binding polaris 2>/dev/null)"; then
      POLARIS_ROLE_ARN="${resolved_binding}"
      log "Resolved POLARIS_ROLE_ARN from Terraform output workload_identities.polaris.identity_binding/role_arn"
    fi
  fi

  if [[ -z "${POLARIS_ROLE_ARN:-}" ]]; then
    echo "Set POLARIS_ROLE_ARN to the cloud storage identity for Polaris (on AWS, an IAM role ARN)." >&2
    exit 1
  fi

  log "Using POLARIS_ROLE_ARN=${POLARIS_ROLE_ARN}"
}

polaris_provider_storage_config() {
  jq -cn \
    --arg roleArn "${POLARIS_ROLE_ARN}" \
    --arg region "${POLARIS_STORAGE_REGION}" \
    --arg allowed "${REFERENCE_ALLOWED_LOCATION}" \
    '{
      storageType: "S3",
      roleArn: $roleArn,
      region: $region,
      allowedLocations: [$allowed]
    }'
}
