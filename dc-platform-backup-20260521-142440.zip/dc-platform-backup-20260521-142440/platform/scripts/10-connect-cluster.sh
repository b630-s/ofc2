#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
AWS_SCRIPT_DIR="${SCRIPT_DIR}/aws"

main() {
  exec "${AWS_SCRIPT_DIR}/10-connect-cluster.sh" "$@"
}

main "$@"
