#!/usr/bin/env bash
#
# Note for existing environments:
# Older setups may already have a Polaris catalog named "reference". This script
# now defaults REFERENCE_CATALOG to "polaris". Re-running it with the new
# default will create or validate a separate "polaris" catalog and will not
# migrate data from the older "reference" catalog automatically. Use
# REFERENCE_CATALOG=reference if you need to keep working with the older catalog
# layout, or re-bootstrap and migrate deliberately.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
# shellcheck source=lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/aws}"

POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
POLARIS_SERVICE="${POLARIS_SERVICE:-polaris}"
POLARIS_LOCAL_PORT="${POLARIS_LOCAL_PORT:-18181}"
POLARIS_BASE_URL="${POLARIS_BASE_URL:-http://127.0.0.1:${POLARIS_LOCAL_PORT}}"
POLARIS_ADMIN_CLIENT_ID="${POLARIS_ADMIN_CLIENT_ID:-}"
POLARIS_ADMIN_CLIENT_SECRET="${POLARIS_ADMIN_CLIENT_SECRET:-}"
POLARIS_ROLE_ARN="${POLARIS_ROLE_ARN:-}"
POLARIS_STORAGE_TYPE="${POLARIS_STORAGE_TYPE:-S3}"
POLARIS_STORAGE_REGION="${POLARIS_STORAGE_REGION:-${POLARIS_AWS_REGION:-us-east-1}}"
POLARIS_S3_ROLE_ARN="${POLARIS_S3_ROLE_ARN:-}"
POLARIS_GCS_SERVICE_ACCOUNT="${POLARIS_GCS_SERVICE_ACCOUNT:-}"
POLARIS_AZURE_TENANT_ID="${POLARIS_AZURE_TENANT_ID:-}"
POLARIS_AZURE_MULTI_TENANT_APP_NAME="${POLARIS_AZURE_MULTI_TENANT_APP_NAME:-}"
POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS="${POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS:-}"
REFERENCE_BUCKET="${REFERENCE_BUCKET:-}"
REFERENCE_CATALOG="${REFERENCE_CATALOG:-polaris}"
REFERENCE_BASE_LOCATION="${REFERENCE_BASE_LOCATION:-}"
REFERENCE_ALLOWED_LOCATION="${REFERENCE_ALLOWED_LOCATION:-}"
REFERENCE_PRINCIPAL="${REFERENCE_PRINCIPAL:-reference_spark_user}"
REFERENCE_PRINCIPAL_ROLE="${REFERENCE_PRINCIPAL_ROLE:-reference_spark_role}"
REFERENCE_CATALOG_ROLE="${REFERENCE_CATALOG_ROLE:-reference_catalog_role}"

POLARIS_PROVIDER_FILE="${SCRIPT_DIR}/polaris_providers/${POLARIS_STORAGE_TYPE,,}.sh"
if [[ ! -f "${POLARIS_PROVIDER_FILE}" ]]; then
  echo "No Polaris provider adapter for POLARIS_STORAGE_TYPE=${POLARIS_STORAGE_TYPE}. Expected: ${POLARIS_PROVIDER_FILE}" >&2
  exit 1
fi
# shellcheck source=/dev/null
source "${POLARIS_PROVIDER_FILE}"

PF_PID=""
PF_LOG=""
TOKEN=""

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[platform-polaris] %s\n' "$*"
}

write_platform_config_polaris_reference_section() {
  local spark_event_log_dir

  spark_event_log_dir="${REFERENCE_BASE_LOCATION%/}/spark-event-logs"
  if [[ "${spark_event_log_dir}" == s3://* ]]; then
    spark_event_log_dir="s3a://${spark_event_log_dir#s3://}"
  fi

  platform_config_write_section "polaris-reference" "platform/scripts/50-bootstrap-polaris-reference.sh" <<EOF
$(platform_config_write_env_var REFERENCE_CATALOG "${REFERENCE_CATALOG}")
$(platform_config_write_env_var REFERENCE_BRONZE_NAMESPACE "bronze")
$(platform_config_write_env_var REFERENCE_SILVER_NAMESPACE "silver")
$(platform_config_write_env_var REFERENCE_PRINCIPAL "${REFERENCE_PRINCIPAL}")
$(platform_config_write_env_var REFERENCE_PRINCIPAL_ROLE "${REFERENCE_PRINCIPAL_ROLE}")
$(platform_config_write_env_var REFERENCE_CATALOG_ROLE "${REFERENCE_CATALOG_ROLE}")
$(platform_config_write_env_var REFERENCE_BASE_LOCATION "${REFERENCE_BASE_LOCATION}")
$(platform_config_write_env_var SPARK_EVENT_LOG_DIR "${spark_event_log_dir}")
EOF
}

resolve_tf_output() {
  local output_name="$1"

  if ! command -v terraform >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -raw "${output_name}" 2>/dev/null
}

resolve_workload_identity_binding() {
  local identity_name="$1"

  if ! command -v terraform >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -json workload_identities 2>/dev/null \
    | jq -r --arg identity_name "${identity_name}" '.[$identity_name].identity_binding // .[$identity_name].role_arn // empty'
}

cleanup() {
  if [[ -n "${PF_PID}" ]]; then
    kill "${PF_PID}" >/dev/null 2>&1 || true
    wait "${PF_PID}" 2>/dev/null || true
  fi

  if [[ -n "${PF_LOG}" ]]; then
    rm -f "${PF_LOG}"
  fi
}

trap cleanup EXIT

preflight() {
  local resolved_bucket

  require_cmd kubectl
  require_cmd curl
  require_cmd jq

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_ADMIN_CLIENT_ID}" || -z "${POLARIS_ADMIN_CLIENT_SECRET}" ]]; then
    echo "Set POLARIS_ADMIN_CLIENT_ID and POLARIS_ADMIN_CLIENT_SECRET before running this script." >&2
    exit 1
  fi

  if [[ "${POLARIS_STORAGE_TYPE}" == "S3" && -z "${REFERENCE_BUCKET}" ]]; then
    if resolved_bucket="$(resolve_tf_output lakehouse_bucket_name)"; then
      REFERENCE_BUCKET="${resolved_bucket}"
      log "Resolved REFERENCE_BUCKET from Terraform output lakehouse_bucket_name"
    fi
  fi

  if [[ -z "${REFERENCE_ALLOWED_LOCATION}" && -n "${REFERENCE_BASE_LOCATION}" ]]; then
    REFERENCE_ALLOWED_LOCATION="${REFERENCE_BASE_LOCATION}"
    log "Defaulted REFERENCE_ALLOWED_LOCATION from REFERENCE_BASE_LOCATION"
  fi

  if [[ -z "${REFERENCE_BASE_LOCATION}" || -z "${REFERENCE_ALLOWED_LOCATION}" ]]; then
    cat >&2 <<EOF
Set REFERENCE_BASE_LOCATION explicitly and optionally REFERENCE_ALLOWED_LOCATION.
Examples:
  s3://bucket/path
  gs://bucket/path
  abfss://container@account.dfs.core.windows.net/path
EOF
    exit 1
  fi

  if [[ -n "${REFERENCE_BUCKET}" ]]; then
    log "Using REFERENCE_BUCKET=${REFERENCE_BUCKET}"
  fi
  log "Using REFERENCE_BASE_LOCATION=${REFERENCE_BASE_LOCATION}"
  log "Using REFERENCE_ALLOWED_LOCATION=${REFERENCE_ALLOWED_LOCATION}"

  polaris_provider_validate
}

ensure_port_forward() {
  if curl -sf \
    -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
    -d 'grant_type=client_credentials' \
    -d 'scope=PRINCIPAL_ROLE:ALL' \
    "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" >/dev/null 2>&1; then
    log "Using existing reachable Polaris endpoint at ${POLARIS_BASE_URL}"
    return
  fi

  PF_LOG="$(mktemp)"
  log "Starting local port-forward to service/${POLARIS_SERVICE} in namespace ${POLARIS_NAMESPACE}"
  kubectl port-forward -n "${POLARIS_NAMESPACE}" "service/${POLARIS_SERVICE}" "${POLARIS_LOCAL_PORT}:8181" >"${PF_LOG}" 2>&1 &
  PF_PID="$!"

  for _ in $(seq 1 20); do
    if curl -sf \
      -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
      -d 'grant_type=client_credentials' \
      -d 'scope=PRINCIPAL_ROLE:ALL' \
      "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" >/dev/null 2>&1; then
      log "Polaris endpoint is reachable at ${POLARIS_BASE_URL}"
      return
    fi
    sleep 1
  done

  echo "Failed to reach Polaris at ${POLARIS_BASE_URL} after starting port-forward." >&2
  if [[ -f "${PF_LOG}" ]]; then
    cat "${PF_LOG}" >&2
  fi
  exit 1
}

fetch_token() {
  log "Requesting Polaris OAuth token"
  TOKEN="$(curl -sf \
    -u "${POLARIS_ADMIN_CLIENT_ID}:${POLARIS_ADMIN_CLIENT_SECRET}" \
    -d 'grant_type=client_credentials' \
    -d 'scope=PRINCIPAL_ROLE:ALL' \
    "${POLARIS_BASE_URL}/api/catalog/v1/oauth/tokens" | jq -r '.access_token')"

  if [[ -z "${TOKEN}" || "${TOKEN}" == "null" ]]; then
    echo "Failed to obtain Polaris access token." >&2
    exit 1
  fi
}

api_status_and_body() {
  local method="$1"
  local path="$2"
  local data="${3:-}"
  local body_file status

  body_file="$(mktemp)"
  if [[ -n "${data}" ]]; then
    status="$(curl -sS -o "${body_file}" -w '%{http_code}' \
      -X "${method}" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H 'Content-Type: application/json' \
      "${POLARIS_BASE_URL}${path}" \
      -d "${data}")"
  else
    status="$(curl -sS -o "${body_file}" -w '%{http_code}' \
      -X "${method}" \
      -H "Authorization: Bearer ${TOKEN}" \
      "${POLARIS_BASE_URL}${path}")"
  fi

  printf '%s\n%s\n' "${status}" "${body_file}"
}

api_expect() {
  local method="$1"
  local path="$2"
  local acceptable_csv="$3"
  local data="${4:-}"
  local result status body_file

  result="$(api_status_and_body "${method}" "${path}" "${data}")"
  status="$(printf '%s' "${result}" | sed -n '1p')"
  body_file="$(printf '%s' "${result}" | sed -n '2p')"

  if [[ ",${acceptable_csv}," != *",${status},"* ]]; then
    echo "Polaris API call failed: ${method} ${path} returned HTTP ${status}" >&2
    cat "${body_file}" >&2 || true
    rm -f "${body_file}"
    exit 1
  fi

  printf '%s\n' "${body_file}"
}

api_expect_grant_idempotent() {
  local method="$1"
  local path="$2"
  local data="${3:-}"
  local result status body_file

  result="$(api_status_and_body "${method}" "${path}" "${data}")"
  status="$(printf '%s' "${result}" | sed -n '1p')"
  body_file="$(printf '%s' "${result}" | sed -n '2p')"

  if [[ "${status}" == "500" ]] && grep -q 'grant_records_pkey' "${body_file}"; then
    rm -f "${body_file}"
    return 0
  fi

  if [[ ",200,201,204,409," != *",${status},"* ]]; then
    echo "Polaris API call failed: ${method} ${path} returned HTTP ${status}" >&2
    cat "${body_file}" >&2 || true
    rm -f "${body_file}"
    exit 1
  fi

  rm -f "${body_file}"
}

catalog_exists() {
  local body_file exists=0
  body_file="$(api_expect GET "/api/management/v1/catalogs" "200")"
  if jq -e --arg name "${REFERENCE_CATALOG}" '.catalogs[]? | select(.name == $name)' "${body_file}" >/dev/null 2>&1; then
    exists=1
  fi
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

principal_exists() {
  local body_file exists=0
  body_file="$(api_expect GET "/api/management/v1/principals" "200")"
  if jq -e --arg name "${REFERENCE_PRINCIPAL}" '.principals[]? | select(.name == $name)' "${body_file}" >/dev/null 2>&1; then
    exists=1
  fi
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

principal_role_exists() {
  local body_file exists=0
  body_file="$(api_expect GET "/api/management/v1/principal-roles" "200")"
  if jq -e --arg name "${REFERENCE_PRINCIPAL_ROLE}" '.roles[]? | select(.name == $name)' "${body_file}" >/dev/null 2>&1; then
    exists=1
  fi
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

catalog_role_exists() {
  local body_file exists=0
  body_file="$(api_expect GET "/api/management/v1/catalogs/${REFERENCE_CATALOG}/catalog-roles" "200,404")"
  if jq -e '.error' "${body_file}" >/dev/null 2>&1; then
    rm -f "${body_file}"
    return 1
  fi
  if jq -e --arg name "${REFERENCE_CATALOG_ROLE}" '.roles[]? | select(.name == $name)' "${body_file}" >/dev/null 2>&1; then
    exists=1
  fi
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

principal_has_role() {
  local body_file exists=0
  body_file="$(api_expect GET "/api/management/v1/principals/${REFERENCE_PRINCIPAL}/principal-roles" "200,404")"
  if jq -e '.error' "${body_file}" >/dev/null 2>&1; then
    rm -f "${body_file}"
    return 1
  fi
  if jq -e --arg name "${REFERENCE_PRINCIPAL_ROLE}" '.roles[]? | select(.name == $name)' "${body_file}" >/dev/null 2>&1; then
    exists=1
  fi
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

namespace_exists() {
  local namespace="$1"
  local body_file exists=0
  body_file="$(api_expect GET "/api/catalog/v1/${REFERENCE_CATALOG}/namespaces/${namespace}" "200,404")"
  if jq -e '.error' "${body_file}" >/dev/null 2>&1; then
    rm -f "${body_file}"
    return 1
  fi
  exists=1
  rm -f "${body_file}"
  [[ "${exists}" -eq 1 ]]
}

create_catalog() {
  local payload storage_config

  storage_config="$(polaris_provider_storage_config)"
  payload="$(jq -cn \
    --arg name "${REFERENCE_CATALOG}" \
    --arg base "${REFERENCE_BASE_LOCATION}" \
    --argjson storageConfigInfo "${storage_config}" \
    '{
      name: $name,
      type: "INTERNAL",
      properties: {
        "default-base-location": $base
      },
      storageConfigInfo: $storageConfigInfo
    }')"

  api_expect POST "/api/management/v1/catalogs" "201,409" "${payload}" >/dev/null
}

create_principal() {
  local payload body_file
  payload="$(jq -cn --arg name "${REFERENCE_PRINCIPAL}" '{name: $name, type: "SERVICE"}')"
  body_file="$(api_expect POST "/api/management/v1/principals" "201,409" "${payload}")"
  if jq -e '.credentials.clientId and .credentials.clientSecret' "${body_file}" >/dev/null 2>&1; then
    user_client_id="$(jq -r '.credentials.clientId' "${body_file}")"
    user_client_secret="$(jq -r '.credentials.clientSecret' "${body_file}")"
  fi
  rm -f "${body_file}"
}

create_principal_role() {
  local payload
  payload="$(jq -cn --arg name "${REFERENCE_PRINCIPAL_ROLE}" '{principalRole: {name: $name}}')"
  api_expect POST "/api/management/v1/principal-roles" "201,409" "${payload}" >/dev/null
}

create_catalog_role() {
  local payload
  payload="$(jq -cn --arg name "${REFERENCE_CATALOG_ROLE}" '{catalogRole: {name: $name}}')"
  api_expect POST "/api/management/v1/catalogs/${REFERENCE_CATALOG}/catalog-roles" "201,409" "${payload}" >/dev/null
}

grant_catalog_privilege() {
  local payload
  payload='{"grant":{"type":"catalog","privilege":"CATALOG_MANAGE_CONTENT"}}'
  api_expect_grant_idempotent PUT "/api/management/v1/catalogs/${REFERENCE_CATALOG}/catalog-roles/${REFERENCE_CATALOG_ROLE}/grants" "${payload}"
}

grant_catalog_role_to_principal_role() {
  local payload
  payload="$(jq -cn --arg name "${REFERENCE_CATALOG_ROLE}" '{catalogRole: {name: $name}}')"
  api_expect_grant_idempotent PUT "/api/management/v1/principal-roles/${REFERENCE_PRINCIPAL_ROLE}/catalog-roles/${REFERENCE_CATALOG}" "${payload}"
}

grant_principal_role_to_principal() {
  local payload
  payload="$(jq -cn --arg name "${REFERENCE_PRINCIPAL_ROLE}" '{principalRole: {name: $name}}')"
  api_expect_grant_idempotent PUT "/api/management/v1/principals/${REFERENCE_PRINCIPAL}/principal-roles" "${payload}"
}

create_namespace() {
  local namespace="$1"
  local payload location
  location="${REFERENCE_BASE_LOCATION%/}/${namespace}"
  payload="$(jq -cn --arg ns "${namespace}" --arg location "${location}" '{namespace: [$ns], properties: {location: $location}}')"
  api_expect POST "/api/catalog/v1/${REFERENCE_CATALOG}/namespaces" "200,201,409" "${payload}" >/dev/null
}

main() {
  preflight
  ensure_port_forward
  fetch_token

  user_client_id=""
  user_client_secret=""

  if catalog_exists; then
    log "Catalog ${REFERENCE_CATALOG} already exists; leaving it in place"
  else
    log "Creating Polaris catalog ${REFERENCE_CATALOG}"
    create_catalog
  fi

  if principal_exists; then
    log "Principal ${REFERENCE_PRINCIPAL} already exists; reusing it"
  else
    log "Creating reference principal ${REFERENCE_PRINCIPAL}"
    create_principal
  fi

  if principal_role_exists; then
    log "Principal role ${REFERENCE_PRINCIPAL_ROLE} already exists"
  else
    log "Creating principal role ${REFERENCE_PRINCIPAL_ROLE}"
    create_principal_role
  fi

  if catalog_role_exists; then
    log "Catalog role ${REFERENCE_CATALOG_ROLE} already exists in ${REFERENCE_CATALOG}"
  else
    log "Creating catalog role ${REFERENCE_CATALOG_ROLE}"
    create_catalog_role
  fi

  if principal_has_role; then
    log "Principal ${REFERENCE_PRINCIPAL} already has role ${REFERENCE_PRINCIPAL_ROLE}"
  else
    log "Granting principal role ${REFERENCE_PRINCIPAL_ROLE} to ${REFERENCE_PRINCIPAL}"
    grant_principal_role_to_principal
  fi

  log "Granting catalog role ${REFERENCE_CATALOG_ROLE} to principal role ${REFERENCE_PRINCIPAL_ROLE}"
  grant_catalog_role_to_principal_role

  log "Granting CATALOG_MANAGE_CONTENT on ${REFERENCE_CATALOG}"
  grant_catalog_privilege

  for namespace in bronze silver; do
    if namespace_exists "${namespace}"; then
      log "Namespace ${namespace} already exists"
    else
      log "Creating namespace ${namespace}"
      create_namespace "${namespace}"
    fi
  done

  if [[ -n "${user_client_id}" && -n "${user_client_secret}" ]]; then
    echo
    echo "Reference principal credentials created."
    echo "Export these before rendering the SparkApplication templates:"
    echo "export POLARIS_USER_CLIENT_ID=${user_client_id}"
    echo "export POLARIS_USER_CLIENT_SECRET=${user_client_secret}"
  else
    echo
    echo "No new principal credentials were captured."
    echo "If the principal already existed, reuse the existing reference principal credentials."
  fi

  echo
  echo "Polaris bootstrap slice completed."
  echo "Catalog: ${REFERENCE_CATALOG}"
  echo "Base location: ${REFERENCE_BASE_LOCATION}"
  echo "Namespaces: bronze, silver"
  write_platform_config_polaris_reference_section
}

main "$@"
