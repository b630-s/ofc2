#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
# shellcheck source=lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"

ENABLE_AIRFLOW="${ENABLE_AIRFLOW:-true}"
ENABLE_MONITORING="${ENABLE_MONITORING:-true}"
ENABLE_POLARIS="${ENABLE_POLARIS:-true}"
ENABLE_JUPYTERHUB="${ENABLE_JUPYTERHUB:-false}"

MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"
AIRFLOW_NAMESPACE="${AIRFLOW_NAMESPACE:-airflow}"
POLARIS_NAMESPACE="${POLARIS_NAMESPACE:-polaris}"
JUPYTER_NAMESPACE="${JUPYTER_NAMESPACE:-jupyter}"

GRAFANA_UI_SERVICE="${GRAFANA_UI_SERVICE:-kube-prometheus-stack-grafana}"
PROMETHEUS_UI_SERVICE="${PROMETHEUS_UI_SERVICE:-kube-prometheus-stack-prometheus}"
AIRFLOW_UI_SERVICE="${AIRFLOW_UI_SERVICE:-airflow-api-server}"
POLARIS_SERVICE="${POLARIS_SERVICE:-polaris}"
JUPYTER_SERVICE="${JUPYTER_SERVICE:-proxy-public}"
JUPYTERHUB_SHARED_PASSWORD="${JUPYTERHUB_SHARED_PASSWORD:-}"

GRAFANA_LOCAL_PORT="${GRAFANA_LOCAL_PORT:-3000}"
PROMETHEUS_LOCAL_PORT="${PROMETHEUS_LOCAL_PORT:-9090}"
AIRFLOW_LOCAL_PORT="${AIRFLOW_LOCAL_PORT:-8080}"
POLARIS_LOCAL_PORT="${POLARIS_LOCAL_PORT:-18181}"
JUPYTER_LOCAL_PORT="${JUPYTER_LOCAL_PORT:-8888}"

PORT_FORWARD_PIDS=()
PORT_FORWARD_LOGS=()

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[port-forward] %s\n' "$*"
}

cleanup() {
  local pid

  if ((${#PORT_FORWARD_PIDS[@]} > 0)); then
    for pid in "${PORT_FORWARD_PIDS[@]}"; do
      if kill -0 "${pid}" >/dev/null 2>&1; then
        kill "${pid}" >/dev/null 2>&1 || true
        wait "${pid}" >/dev/null 2>&1 || true
      fi
    done
  fi

  if ((${#PORT_FORWARD_LOGS[@]} > 0)); then
    rm -f "${PORT_FORWARD_LOGS[@]}"
  fi
}

ensure_service_exists() {
  local namespace="$1"
  local service_name="$2"
  local label="$3"

  if ! kubectl get service "${service_name}" -n "${namespace}" >/dev/null 2>&1; then
    echo "${label} service ${namespace}/${service_name} was not found." >&2
    exit 1
  fi
}

start_port_forward() {
  local namespace="$1"
  local service_name="$2"
  local local_port="$3"
  local remote_port="$4"
  local label="$5"
  local url="$6"
  local log_file pid

  ensure_service_exists "${namespace}" "${service_name}" "${label}"

  log_file="$(mktemp)"
  PORT_FORWARD_LOGS+=("${log_file}")

  kubectl port-forward -n "${namespace}" "svc/${service_name}" "${local_port}:${remote_port}" >"${log_file}" 2>&1 &
  pid=$!
  PORT_FORWARD_PIDS+=("${pid}")

  sleep 1
  if ! kill -0 "${pid}" >/dev/null 2>&1; then
    echo "Failed to start port-forward for ${label}." >&2
    cat "${log_file}" >&2 || true
    exit 1
  fi

  log "${label}: ${url}"
}

main() {
  require_cmd kubectl
  trap cleanup EXIT INT TERM

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  if [[ "${ENABLE_MONITORING}" == "true" ]]; then
    start_port_forward "${MONITORING_NAMESPACE}" "${GRAFANA_UI_SERVICE}" "${GRAFANA_LOCAL_PORT}" "80" "Grafana" "http://127.0.0.1:${GRAFANA_LOCAL_PORT}"
    start_port_forward "${MONITORING_NAMESPACE}" "${PROMETHEUS_UI_SERVICE}" "${PROMETHEUS_LOCAL_PORT}" "9090" "Prometheus" "http://127.0.0.1:${PROMETHEUS_LOCAL_PORT}"
  fi

  if [[ "${ENABLE_AIRFLOW}" == "true" ]]; then
    start_port_forward "${AIRFLOW_NAMESPACE}" "${AIRFLOW_UI_SERVICE}" "${AIRFLOW_LOCAL_PORT}" "8080" "Airflow" "http://127.0.0.1:${AIRFLOW_LOCAL_PORT}"
  fi

  if [[ "${ENABLE_POLARIS}" == "true" ]]; then
    start_port_forward "${POLARIS_NAMESPACE}" "${POLARIS_SERVICE}" "${POLARIS_LOCAL_PORT}" "8181" "Polaris" "http://127.0.0.1:${POLARIS_LOCAL_PORT}"
  fi

  if [[ "${ENABLE_JUPYTERHUB}" == "true" ]]; then
    start_port_forward "${JUPYTER_NAMESPACE}" "${JUPYTER_SERVICE}" "${JUPYTER_LOCAL_PORT}" "80" "JupyterHub" "http://127.0.0.1:${JUPYTER_LOCAL_PORT}"
    if [[ -n "${JUPYTERHUB_SHARED_PASSWORD}" ]]; then
      log "JupyterHub password: ${JUPYTERHUB_SHARED_PASSWORD}"
    else
      log "JupyterHub password is not set in the current shell or ${PLATFORM_SECRETS_ENV}."
    fi
  fi

  cat <<EOF

Port-forwards are running in the foreground.
Press Ctrl-C to stop them all.
EOF

  wait
}

main "$@"
