#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"

cat <<EOF
platform/scripts/aws/99-collect-platform-info-retired.sh is retired.

The shared non-secret handoff file is now generated incrementally at:
  ${REPO_ROOT}/platform/config/platform-config.env

Structured workload identities now live at:
  ${REPO_ROOT}/platform/config/workload-identities.json

Current producers:
  - infra/aws/deploy-infra.sh                 -> infra section + workload-identities.json
  - platform/scripts/20-deploy-platform.sh -> platform section
  - platform/scripts/30-deploy-kafka.sh    -> kafka section
  - platform/scripts/50-bootstrap-polaris-reference.sh -> polaris-reference section

Secrets are intentionally separate:
  - platform/config/platform-secrets.env
  - reference-workloads/orders-reference/config/platform-secrets.env
EOF
