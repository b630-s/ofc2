#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
SPARK_OPERATOR_CHART_VERSION="${SPARK_OPERATOR_CHART_VERSION:-2.4.0}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-spark-operator] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  local spark_operator_values_file
  spark_operator_values_file="$(mktemp)"
  cp "${SCRIPT_DIR}/values.yaml" "${spark_operator_values_file}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${spark_operator_values_file}"
  fi

  log "Installing Spark Operator into ${PLATFORM_NAMESPACE}"
  helm upgrade --install spark-operator spark-operator/spark-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${SPARK_OPERATOR_CHART_VERSION}" \
    --values "${spark_operator_values_file}" \
    --wait \
    --timeout 10m

  rm -f "${spark_operator_values_file}"
}

main "$@"
