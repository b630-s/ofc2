#!/usr/bin/env bash

set -euo pipefail

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl
  require_cmd helm

  helm uninstall spark-operator --namespace "${PLATFORM_NAMESPACE}" --wait --timeout 10m >/dev/null 2>&1 || true
}

main "$@"
