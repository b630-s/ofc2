#!/usr/bin/env bash

set -euo pipefail

KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

patch_topic_finalizers() {
  local topics

  topics="$(kubectl get kafkatopic -n "${KAFKA_NAMESPACE}" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || true)"
  if [[ -z "${topics}" ]]; then
    return
  fi

  for topic in ${topics}; do
    kubectl patch kafkatopic "${topic}" -n "${KAFKA_NAMESPACE}" --type=merge -p '{"metadata":{"finalizers":[]}}' >/dev/null 2>&1 || true
  done
}

main() {
  require_cmd kubectl

  if ! kubectl get namespace "${KAFKA_NAMESPACE}" >/dev/null 2>&1; then
    exit 0
  fi

  kubectl delete pod kafka-test-client --namespace "${KAFKA_NAMESPACE}" --ignore-not-found
  kubectl delete kafkatopic --all -n "${KAFKA_NAMESPACE}" --ignore-not-found --wait=false || true
  kubectl delete kafka --all -n "${KAFKA_NAMESPACE}" --ignore-not-found --wait=false || true
  kubectl delete kafkanodepool --all -n "${KAFKA_NAMESPACE}" --ignore-not-found --wait=false || true

  patch_topic_finalizers
}

main "$@"
