#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

check_optional_pod_ready() {
  local pod_name="$1"

  if ! kubectl get pod "${pod_name}" -n "${KAFKA_NAMESPACE}" >/dev/null 2>&1; then
    return
  fi

  kubectl wait "pod/${pod_name}" \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"
}

main() {
  require_cmd kubectl

  kubectl wait kafka/reference-kafka \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"

  kubectl get kafkanodepool controller --namespace "${KAFKA_NAMESPACE}" >/dev/null
  kubectl get kafkanodepool broker --namespace "${KAFKA_NAMESPACE}" >/dev/null

  kubectl wait pod -n "${KAFKA_NAMESPACE}" \
    -l 'strimzi.io/cluster=reference-kafka,strimzi.io/pool-name=controller' \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"
  kubectl wait pod -n "${KAFKA_NAMESPACE}" \
    -l 'strimzi.io/cluster=reference-kafka,strimzi.io/pool-name=broker' \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"

  kubectl wait kafkatopic/orders-raw \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"
  kubectl wait kafkatopic/orders-dlq \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${VALIDATION_TIMEOUT}"

  check_optional_pod_ready kafka-test-client
}

main "$@"
