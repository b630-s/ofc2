#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
STRIMZI_CHART_VERSION="${STRIMZI_CHART_VERSION:-0.51.0}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-strimzi] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  local strimzi_values_file
  strimzi_values_file="$(mktemp)"
  cp "${SCRIPT_DIR}/values.yaml" "${strimzi_values_file}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${strimzi_values_file}"
  fi

  log "Applying Kafka workload namespace"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"

  log "Installing Strimzi operator into ${PLATFORM_NAMESPACE}"
  helm upgrade --install strimzi-kafka-operator strimzi/strimzi-kafka-operator \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${STRIMZI_CHART_VERSION}" \
    --values "${strimzi_values_file}" \
    --wait \
    --timeout 10m

  rm -f "${strimzi_values_file}"
}

main "$@"
