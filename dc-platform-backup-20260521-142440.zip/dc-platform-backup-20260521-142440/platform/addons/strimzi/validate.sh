#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl

  kubectl rollout status deployment/strimzi-cluster-operator -n "${PLATFORM_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
}

main "$@"
