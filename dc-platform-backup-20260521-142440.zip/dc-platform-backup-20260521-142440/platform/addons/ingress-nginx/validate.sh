#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
INGRESS_NAMESPACE="${INGRESS_NAMESPACE:-ingress-nginx}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl

  kubectl rollout status deployment/ingress-nginx-controller -n "${INGRESS_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
}

main "$@"
