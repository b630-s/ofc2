#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INGRESS_NAMESPACE="${INGRESS_NAMESPACE:-ingress-nginx}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl
  require_cmd helm

  helm uninstall ingress-nginx --namespace "${INGRESS_NAMESPACE}" --wait --timeout 10m >/dev/null 2>&1 || true
  kubectl delete -f "${SCRIPT_DIR}/namespace.yaml" --ignore-not-found
}

main "$@"
