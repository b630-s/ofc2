#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
METRICS_SERVER_CHART_VERSION="${METRICS_SERVER_CHART_VERSION:-3.13.0}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

# Requires the Helm repository to be configured for standalone use:
# helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-metrics-server] %s\n' "$*"
}

main() {
  require_cmd kubectl
  require_cmd helm

  local metrics_server_values_file
  metrics_server_values_file="$(mktemp)"
  cp "${SCRIPT_DIR}/values.yaml" "${metrics_server_values_file}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${metrics_server_values_file}"
  fi

  log "Installing metrics-server into ${PLATFORM_NAMESPACE}"
  helm upgrade --install metrics-server metrics-server/metrics-server \
    --namespace "${PLATFORM_NAMESPACE}" \
    --create-namespace \
    --version "${METRICS_SERVER_CHART_VERSION}" \
    --values "${metrics_server_values_file}" \
    --wait \
    --timeout 10m

  rm -f "${metrics_server_values_file}"
}

main "$@"
