#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl

  kubectl rollout status deployment/metrics-server -n "${PLATFORM_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
  kubectl wait apiservice/v1beta1.metrics.k8s.io --for=condition=Available --timeout="${VALIDATION_TIMEOUT}"
}

main "$@"
