#!/usr/bin/env bash

set -euo pipefail

JUPYTER_NAMESPACE="${JUPYTER_NAMESPACE:-jupyter}"

main() {
  helm uninstall jupyterhub --namespace "${JUPYTER_NAMESPACE}" --wait --timeout 10m >/dev/null 2>&1 || true
  kubectl delete -f "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/service-account.yaml" --ignore-not-found
  kubectl delete -f "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/namespace.yaml" --ignore-not-found
}

main "$@"
