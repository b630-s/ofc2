#!/usr/bin/env bash

set -euo pipefail

JUPYTER_NAMESPACE="${JUPYTER_NAMESPACE:-jupyter}"
VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"

main() {
  kubectl rollout status deployment/hub -n "${JUPYTER_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
  kubectl rollout status deployment/proxy -n "${JUPYTER_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
  kubectl get service proxy-public -n "${JUPYTER_NAMESPACE}" >/dev/null
}

main "$@"
