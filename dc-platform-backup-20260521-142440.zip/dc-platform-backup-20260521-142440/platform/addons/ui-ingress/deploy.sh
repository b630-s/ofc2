#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

ENABLE_JUPYTERHUB="${ENABLE_JUPYTERHUB:-false}"
ENABLE_AIRFLOW="${ENABLE_AIRFLOW:-true}"
ENABLE_MONITORING="${ENABLE_MONITORING:-true}"
ENABLE_POLARIS="${ENABLE_POLARIS:-true}"
UI_INGRESS_CLASS_NAME="${UI_INGRESS_CLASS_NAME:-nginx}"
UI_INGRESS_BASE_DOMAIN="${UI_INGRESS_BASE_DOMAIN:-platform.local}"
GRAFANA_INGRESS_HOST="${GRAFANA_INGRESS_HOST:-grafana.${UI_INGRESS_BASE_DOMAIN}}"
PROMETHEUS_INGRESS_HOST="${PROMETHEUS_INGRESS_HOST:-prometheus.${UI_INGRESS_BASE_DOMAIN}}"
AIRFLOW_INGRESS_HOST="${AIRFLOW_INGRESS_HOST:-airflow.${UI_INGRESS_BASE_DOMAIN}}"
POLARIS_INGRESS_HOST="${POLARIS_INGRESS_HOST:-polaris.${UI_INGRESS_BASE_DOMAIN}}"
JUPYTER_INGRESS_HOST="${JUPYTER_INGRESS_HOST:-jupyter.${UI_INGRESS_BASE_DOMAIN}}"
GRAFANA_UI_SERVICE="${GRAFANA_UI_SERVICE:-kube-prometheus-stack-grafana}"
PROMETHEUS_UI_SERVICE="${PROMETHEUS_UI_SERVICE:-kube-prometheus-stack-prometheus}"
AIRFLOW_UI_SERVICE="${AIRFLOW_UI_SERVICE:-airflow-api-server}"
TMP_FILES=()

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-ui-ingress] %s\n' "$*"
}

render_manifest() {
  local manifest_template="$1"
  local allowed_vars="$2"
  local rendered_file

  rendered_file="$(mktemp)"
  TMP_FILES+=("${rendered_file}")
  envsubst "${allowed_vars}" < "${manifest_template}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd envsubst
  trap 'rm -f "${TMP_FILES[@]}"' EXIT

  local rendered_manifest

  if [[ "${ENABLE_MONITORING}" == "true" ]]; then
    rendered_manifest="$(render_manifest \
      "${SCRIPT_DIR}/monitoring-ingresses.yaml" \
      '${UI_INGRESS_CLASS_NAME} ${GRAFANA_INGRESS_HOST} ${PROMETHEUS_INGRESS_HOST} ${GRAFANA_UI_SERVICE} ${PROMETHEUS_UI_SERVICE}')"
    log "Applying monitoring ingress resources"
    kubectl apply -f "${rendered_manifest}"
  fi

  if [[ "${ENABLE_AIRFLOW}" == "true" ]]; then
    rendered_manifest="$(render_manifest \
      "${SCRIPT_DIR}/airflow-ingress.yaml" \
      '${UI_INGRESS_CLASS_NAME} ${AIRFLOW_INGRESS_HOST} ${AIRFLOW_UI_SERVICE}')"
    log "Applying Airflow ingress resource"
    kubectl apply -f "${rendered_manifest}"
  fi

  if [[ "${ENABLE_POLARIS}" == "true" ]]; then
    rendered_manifest="$(render_manifest \
      "${SCRIPT_DIR}/polaris-ingress.yaml" \
      '${UI_INGRESS_CLASS_NAME} ${POLARIS_INGRESS_HOST}')"
    log "Applying Polaris ingress resource"
    kubectl apply -f "${rendered_manifest}"
  fi

  if [[ "${ENABLE_JUPYTERHUB}" == "true" ]]; then
    rendered_manifest="$(render_manifest \
      "${SCRIPT_DIR}/jupyter-ingress.yaml" \
      '${UI_INGRESS_CLASS_NAME} ${JUPYTER_INGRESS_HOST}')"
    log "Applying JupyterHub ingress resource"
    kubectl apply -f "${rendered_manifest}"
  fi
}

main "$@"
