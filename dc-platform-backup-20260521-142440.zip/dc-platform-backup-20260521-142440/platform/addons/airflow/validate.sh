#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

rollout() {
  local kind="$1"
  local name="$2"
  kubectl rollout status "${kind}/${name}" -n airflow --timeout="${VALIDATION_TIMEOUT}"
}

main() {
  require_cmd kubectl

  rollout statefulset airflow-postgresql
  kubectl wait --namespace airflow --for=condition=complete job/airflow-run-airflow-migrations --timeout="${VALIDATION_TIMEOUT}" >/dev/null 2>&1 || true
  rollout deployment airflow-api-server
  rollout deployment airflow-scheduler
  rollout deployment airflow-dag-processor
  rollout deployment airflow-statsd

  if kubectl get statefulset airflow-triggerer -n airflow >/dev/null 2>&1; then
    rollout statefulset airflow-triggerer
  elif kubectl get deployment airflow-triggerer -n airflow >/dev/null 2>&1; then
    rollout deployment airflow-triggerer
  fi
}

main "$@"
