#!/usr/bin/env bash

set -euo pipefail

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl
  require_cmd helm

  helm uninstall airflow --namespace airflow --wait --timeout 15m >/dev/null 2>&1 || true
  kubectl delete -f "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/service-account.yaml" --ignore-not-found
  kubectl delete -f "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/namespace.yaml" --ignore-not-found
}

main "$@"
