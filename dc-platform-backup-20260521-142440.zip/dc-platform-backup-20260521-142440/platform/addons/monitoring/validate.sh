#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"
MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

rollout() {
  local kind="$1"
  local name="$2"
  kubectl rollout status "${kind}/${name}" -n "${MONITORING_NAMESPACE}" --timeout="${VALIDATION_TIMEOUT}"
}

main() {
  require_cmd kubectl

  rollout deployment kube-prometheus-stack-operator
  rollout deployment kube-prometheus-stack-grafana
  rollout deployment kube-prometheus-stack-kube-state-metrics
  rollout statefulset prometheus-kube-prometheus-stack-prometheus
}

main "$@"
