#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"
KUBE_PROMETHEUS_STACK_CHART_VERSION="${KUBE_PROMETHEUS_STACK_CHART_VERSION:-80.13.3}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-monitoring] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd helm

  if [[ -z "${PLATFORM_STORAGE_CLASS}" ]]; then
    echo "Set PLATFORM_STORAGE_CLASS for your cluster (e.g. gp2/gp3 on EKS, standard on kind, local-path on k3s)." >&2
    exit 1
  fi

  local monitoring_values_file
  monitoring_values_file="$(render_storage_class_template "${SCRIPT_DIR}/values.yaml")"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${monitoring_values_file}"
  fi

  log "Applying monitoring namespace"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"

  log "Installing monitoring stack into ${MONITORING_NAMESPACE}"
  helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
    --namespace "${MONITORING_NAMESPACE}" \
    --create-namespace \
    --reset-values \
    --version "${KUBE_PROMETHEUS_STACK_CHART_VERSION}" \
    --values "${monitoring_values_file}" \
    --wait \
    --timeout 15m

  rm -f "${monitoring_values_file}"
}

main "$@"
