#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl
  require_cmd helm

  helm uninstall kube-prometheus-stack --namespace "${MONITORING_NAMESPACE}" --wait --timeout 15m >/dev/null 2>&1 || true
  kubectl delete -f "${SCRIPT_DIR}/namespace.yaml" --ignore-not-found
}

main "$@"
