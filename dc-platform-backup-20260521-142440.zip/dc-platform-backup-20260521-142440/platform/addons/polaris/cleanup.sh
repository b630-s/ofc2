#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

main() {
  require_cmd kubectl
  require_cmd helm

  helm uninstall polaris --namespace polaris --wait --timeout 15m >/dev/null 2>&1 || true
  kubectl delete -f "${SCRIPT_DIR}/postgresql.yaml" --ignore-not-found
  kubectl delete secret polaris-persistence -n polaris --ignore-not-found
  kubectl delete -f "${SCRIPT_DIR}/service-account.yaml" --ignore-not-found
  kubectl delete -f "${SCRIPT_DIR}/namespace.yaml" --ignore-not-found
}

main "$@"
