#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

POLARIS_CHART_VERSION="${POLARIS_CHART_VERSION:-1.3.0-incubating}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-polaris] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

main() {
  require_cmd kubectl
  require_cmd helm

  if [[ -z "${PLATFORM_STORAGE_CLASS}" ]]; then
    echo "Set PLATFORM_STORAGE_CLASS for your cluster (e.g. gp2/gp3 on EKS, standard on kind, local-path on k3s)." >&2
    exit 1
  fi

  if [[ -z "${POLARIS_DB_PASSWORD:-}" ]]; then
    echo "POLARIS_DB_PASSWORD is required to deploy Polaris." >&2
    exit 1
  fi

  local polaris_postgresql_manifest
  polaris_postgresql_manifest="$(render_storage_class_template "${SCRIPT_DIR}/postgresql.yaml")"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${polaris_postgresql_manifest}"
  fi

  log "Applying Polaris namespace and service account"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"

  log "Creating Polaris persistence secret"
  kubectl create secret generic polaris-persistence \
    --namespace polaris \
    --from-literal=jdbcUrl="jdbc:postgresql://polaris-postgresql.polaris.svc.cluster.local:5432/polaris" \
    --from-literal=username="polaris" \
    --from-literal=password="${POLARIS_DB_PASSWORD}" \
    --from-literal=POSTGRES_DB="polaris" \
    --from-literal=POSTGRES_USER="polaris" \
    --from-literal=POSTGRES_PASSWORD="${POLARIS_DB_PASSWORD}" \
    --dry-run=client \
    --output yaml \
    | kubectl apply -f -

  log "Deploying Polaris PostgreSQL backing store"
  kubectl apply -f "${polaris_postgresql_manifest}"

  kubectl rollout status statefulset/polaris-postgresql \
    --namespace polaris \
    --timeout=10m

  local polaris_values_file
  polaris_values_file="$(mktemp)"
  cp "${SCRIPT_DIR}/values.yaml" "${polaris_values_file}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${polaris_values_file}"
  fi

  log "Installing Polaris into polaris namespace using polaris-sa for cloud storage identity binding"
  helm upgrade --install polaris polaris/polaris \
    --namespace polaris \
    --create-namespace \
    --devel \
    --reset-values \
    --version "${POLARIS_CHART_VERSION}" \
    --values "${polaris_values_file}" \
    --wait \
    --timeout 15m

  echo "Polaris service installed."
  echo "Catalog bootstrap is still a separate step after install."

  rm -f "${polaris_postgresql_manifest}"
  rm -f "${polaris_values_file}"
}

main "$@"
