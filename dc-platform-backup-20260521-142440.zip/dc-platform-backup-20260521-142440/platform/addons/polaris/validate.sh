#!/usr/bin/env bash

set -euo pipefail

VALIDATION_TIMEOUT="${VALIDATION_TIMEOUT:-300s}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

rollout() {
  local kind="$1"
  local name="$2"
  kubectl rollout status "${kind}/${name}" -n polaris --timeout="${VALIDATION_TIMEOUT}"
}

main() {
  require_cmd kubectl

  rollout statefulset polaris-postgresql
  rollout deployment polaris
}

main "$@"
