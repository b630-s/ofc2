#!/usr/bin/env bash

load_reference_env_file() {
  local env_file="$1"
  local mode="${2:-default}"
  local line key
  local nounset_was_on=0

  [[ -f "${env_file}" ]] || return 0

  case $- in
    *u*) nounset_was_on=1 ;;
  esac

  while IFS= read -r line || [[ -n "${line}" ]]; do
    [[ -n "${line}" ]] || continue
    [[ "${line}" == \#* ]] && continue
    [[ "${line}" == *=* ]] || continue

    key="${line%%=*}"
    [[ "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue

    if [[ "${mode}" == "override" ]]; then
      if [[ -n "${REFERENCE_CONFIG_ORIGINAL_ENV[${key}]+x}" ]]; then
        continue
      fi
      set +u
      eval "export ${line}"
      if [[ "${nounset_was_on}" -eq 1 ]]; then
        set -u
      fi
      continue
    fi

    if [[ -n "${REFERENCE_CONFIG_ORIGINAL_ENV[${key}]+x}" || -n "${!key+x}" ]]; then
      continue
    fi

    set +u
    eval "export ${line}"
    if [[ "${nounset_was_on}" -eq 1 ]]; then
      set -u
    fi
  done < "${env_file}"
}

load_reference_workload_config() {
  local repo_root="$1"
  local workload_root="${2:-}"

  declare -gA REFERENCE_CONFIG_ORIGINAL_ENV=()

  while IFS='=' read -r key _; do
    [[ "${key}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
    REFERENCE_CONFIG_ORIGINAL_ENV["${key}"]=1
  done < <(env)

  if [[ -n "${workload_root}" ]]; then
    # shellcheck source=../../../../platform/scripts/lib/platform-config.sh
    source "${repo_root}/platform/scripts/lib/platform-config.sh"
    platform_config_load_runtime_env "${repo_root}"
    load_reference_env_file "${workload_root}/config/platform-config.env" "override"
    load_reference_env_file "${workload_root}/config/workload-secrets.env" "override"
    load_reference_env_file "${workload_root}/config/workload-defaults.env" "default"
    load_reference_env_file "${workload_root}/config/workload.local.env" "override"
    reference_finalize_runtime_defaults
  fi
}

reference_resolve_spark_base_path() {
  local base_path="${REFERENCE_SPARK_BASE_PATH:-}"

  if [[ -z "${base_path}" && -n "${REFERENCE_BASE_LOCATION:-}" ]]; then
    base_path="${REFERENCE_BASE_LOCATION%/}"
  fi

  if [[ -z "${base_path}" && -n "${LAKEHOUSE_BUCKET:-}" ]]; then
    base_path="s3://${LAKEHOUSE_BUCKET}/reference"
  fi

  if [[ "${base_path}" == s3://* ]]; then
    base_path="s3a://${base_path#s3://}"
  fi

  printf '%s\n' "${base_path}"
}

reference_finalize_runtime_defaults() {
  local resolved_base_path=""

  resolved_base_path="$(reference_resolve_spark_base_path)"
  if [[ -n "${resolved_base_path}" ]]; then
    export REFERENCE_SPARK_BASE_PATH="${resolved_base_path}"
    export SPARK_EVENT_LOG_DIR="${SPARK_EVENT_LOG_DIR:-${resolved_base_path}/spark-event-logs}"
  fi
}

reference_strip_node_scheduling_blocks() {
  local yaml_file="$1"
  local tmp_file

  tmp_file="$(mktemp)"
  awk '
    function indentation(line,   pos) {
      pos = match(line, /[^ ]/)
      return pos ? pos - 1 : length(line)
    }

    {
      line = $0

      if (skip_block) {
        if (line ~ /^[[:space:]]*$/) {
          next
        }

        current_indent = indentation(line)
        if (current_indent > block_indent) {
          next
        }

        skip_block = 0
      }

      if (line ~ /^[[:space:]]*(nodeSelector|affinity):([[:space:]]*(\{\})?)?[[:space:]]*$/) {
        skip_block = 1
        block_indent = indentation(line)
        next
      }

      print line
    }
  ' "${yaml_file}" > "${tmp_file}"

  mv "${tmp_file}" "${yaml_file}"
}
