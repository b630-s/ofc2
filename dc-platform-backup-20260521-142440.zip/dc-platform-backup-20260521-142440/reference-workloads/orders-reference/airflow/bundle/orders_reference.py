from datetime import datetime, timedelta
import os
from pathlib import Path
import shlex

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import (
    SparkKubernetesOperator,
)
import yaml


BUNDLE_DIR = Path(__file__).resolve().parent
WORKLOAD_ROOT = BUNDLE_DIR.parents[1]
REPO_ROOT = BUNDLE_DIR.parents[3]
MANIFESTS_DIR = WORKLOAD_ROOT / "spark" / "manifests"
WORKLOAD_CONFIG_DIR = WORKLOAD_ROOT / "config"
PLATFORM_CONFIG_DIR = REPO_ROOT / "platform" / "config"
AIRFLOW_IMAGE_TEMPLATE = "{{ var.value.reference_spark_image }}"


def load_env_defaults() -> None:
    env_files = (
        (PLATFORM_CONFIG_DIR / "platform-config.env", False),
        (PLATFORM_CONFIG_DIR / "example.platform-config.env", False),
        (PLATFORM_CONFIG_DIR / "platform-secrets.env", False),
        (PLATFORM_CONFIG_DIR / "example.platform-secrets.env", False),
        (WORKLOAD_CONFIG_DIR / "platform-config.env", True),
        (WORKLOAD_CONFIG_DIR / "workload-secrets.env", True),
        (WORKLOAD_CONFIG_DIR / "workload-defaults.env", False),
        (WORKLOAD_CONFIG_DIR / "workload.local.env", True),
    )

    for env_file, override_existing in env_files:
        if not env_file.exists():
            continue

        for raw_line in env_file.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            parsed = shlex.split(f"export {line}")
            if len(parsed) != 2 or "=" not in parsed[1]:
                continue
            key, value = parsed[1].split("=", 1)
            if override_existing:
                os.environ[key] = value
            else:
                os.environ.setdefault(key, value)


def resolve_reference_spark_base_path() -> str:
    base_path = os.environ.get("REFERENCE_SPARK_BASE_PATH", "")
    if not base_path:
        base_path = os.environ.get("REFERENCE_BASE_LOCATION", "").rstrip("/")
    if not base_path:
        lakehouse_bucket = os.environ.get("LAKEHOUSE_BUCKET", "")
        if lakehouse_bucket:
            base_path = f"s3://{lakehouse_bucket}/reference"
    if base_path.startswith("s3://"):
        base_path = f"s3a://{base_path[len('s3://'):]}"
    return base_path


def normalize_runtime_defaults() -> None:
    base_path = resolve_reference_spark_base_path()
    if base_path:
        os.environ.setdefault("REFERENCE_SPARK_BASE_PATH", base_path)
        os.environ.setdefault("SPARK_EVENT_LOG_DIR", f"{base_path}/spark-event-logs")


def load_spark_application(filename: str) -> dict:
    manifest_path = MANIFESTS_DIR / filename
    manifest_text = os.path.expandvars(manifest_path.read_text(encoding="utf-8"))
    spec = yaml.safe_load(manifest_text)

    spec["spec"]["image"] = AIRFLOW_IMAGE_TEMPLATE
    spec["metadata"]["name"] = f"{spec['metadata']['name']}-{{{{ ts_nodash }}}}"

    return spec


load_env_defaults()
normalize_runtime_defaults()


with DAG(
    dag_id=os.environ.get("ORDERS_AIRFLOW_DAG_ID", "orders_reference_staged"),
    start_date=datetime(2026, 4, 1),
    catchup=False,
    dagrun_timeout=timedelta(minutes=30),
    schedule=None,
    tags=["reference", "spark", "orders"],
) as dag:
    spark_namespace = os.environ.get("SPARK_NAMESPACE", "spark")

    run_kafka_to_bronze = SparkKubernetesOperator(
        task_id="orders_kafka_to_bronze",
        namespace=spark_namespace,
        template_spec=load_spark_application("spark-app-kafka-to-bronze.yaml"),
        get_logs=True,
    )

    run_bronze_to_silver = SparkKubernetesOperator(
        task_id="orders_bronze_to_silver",
        namespace=spark_namespace,
        template_spec=load_spark_application("spark-app-bronze-to-silver.yaml"),
        get_logs=True,
    )

    run_kafka_to_bronze >> run_bronze_to_silver
