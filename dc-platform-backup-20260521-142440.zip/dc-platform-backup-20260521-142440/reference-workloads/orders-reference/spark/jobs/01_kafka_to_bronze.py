import argparse
import os

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_timestamp


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kafka-bootstrap", required=True)
    parser.add_argument("--topic", default="orders_raw")
    parser.add_argument("--table", default="polaris.bronze.orders_raw")
    return parser.parse_args()


def build_spark_session(table_name: str) -> SparkSession:
    client_id = os.environ.get("POLARIS_USER_CLIENT_ID", "")
    client_secret = os.environ.get("POLARIS_USER_CLIENT_SECRET", "")
    catalog_name = table_name.split(".", 1)[0]

    builder = SparkSession.builder.appName("reference-orders-kafka-to-bronze")
    if client_id and client_secret:
        builder = builder.config(
            f"spark.sql.catalog.{catalog_name}.credential",
            f"{client_id}:{client_secret}",
        )

    return builder.getOrCreate()


def main() -> None:
    args = parse_args()
    spark = build_spark_session(args.table)

    df = (
        spark.read.format("kafka")
        .option("kafka.bootstrap.servers", args.kafka_bootstrap)
        .option("subscribe", args.topic)
        .option("startingOffsets", "earliest")
        .option("endingOffsets", "latest")
        .load()
    )

    bronze_df = df.select(
        col("key").cast("string").alias("message_key"),
        col("value").cast("string").alias("message_value"),
        col("topic"),
        col("partition"),
        col("offset"),
        col("timestamp").alias("kafka_timestamp"),
        current_timestamp().alias("ingestion_timestamp"),
    )

    namespace = args.table.rsplit(".", 1)[0]
    spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {namespace}")

    if spark.catalog.tableExists(args.table):
        bronze_df.writeTo(args.table).append()
    else:
        bronze_df.writeTo(args.table).using("iceberg").create()

    spark.stop()


if __name__ == "__main__":
    main()
