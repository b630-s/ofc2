import argparse
import os

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_timestamp, from_json, to_date, to_timestamp
from pyspark.sql.types import DoubleType, StringType, StructField, StructType


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bronze-table", required=True)
    parser.add_argument("--silver-table", required=True)
    return parser.parse_args()


def build_spark_session(table_name: str) -> SparkSession:
    client_id = os.environ.get("POLARIS_USER_CLIENT_ID", "")
    client_secret = os.environ.get("POLARIS_USER_CLIENT_SECRET", "")
    catalog_name = table_name.split(".", 1)[0]

    builder = SparkSession.builder.appName("reference-orders-bronze-to-silver")
    if client_id and client_secret:
        builder = builder.config(
            f"spark.sql.catalog.{catalog_name}.credential",
            f"{client_id}:{client_secret}",
        )

    return builder.getOrCreate()


def main() -> None:
    args = parse_args()
    spark = build_spark_session(args.silver_table)

    schema = StructType(
        [
            StructField("event_id", StringType(), True),
            StructField("tenant_id", StringType(), True),
            StructField("event_type", StringType(), True),
            StructField("order_id", StringType(), True),
            StructField("amount", DoubleType(), True),
            StructField("currency", StringType(), True),
            StructField("event_time", StringType(), True),
        ]
    )

    bronze_df = spark.table(args.bronze_table)

    silver_df = (
        bronze_df.withColumn("json_data", from_json(col("message_value"), schema))
        .select(
            col("json_data.event_id").alias("event_id"),
            col("json_data.tenant_id").alias("tenant_id"),
            col("json_data.event_type").alias("event_type"),
            col("json_data.order_id").alias("order_id"),
            col("json_data.amount").alias("amount"),
            col("json_data.currency").alias("currency"),
            to_timestamp(col("json_data.event_time")).alias("event_ts"),
            to_date(to_timestamp(col("json_data.event_time"))).alias("event_date"),
            col("kafka_timestamp"),
            col("ingestion_timestamp"),
            current_timestamp().alias("silver_timestamp"),
        )
        .filter(col("event_id").isNotNull())
        .filter(col("tenant_id").isNotNull())
        .filter(col("order_id").isNotNull())
        .dropDuplicates(["event_id"])
    )

    namespace = args.silver_table.rsplit(".", 1)[0]
    spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {namespace}")
    silver_df.writeTo(args.silver_table).using("iceberg").createOrReplace()

    spark.stop()


if __name__ == "__main__":
    main()
