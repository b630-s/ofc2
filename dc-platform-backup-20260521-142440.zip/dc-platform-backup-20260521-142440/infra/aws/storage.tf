data "aws_s3_bucket" "lakehouse" {
  bucket = var.lakehouse_bucket_name
}
