1. Create or review infrastructure plan:
   `infra/aws/deploy-infra.sh`

2. Apply infrastructure when ready:
   in infra/aws
   `infra/aws/deploy-infra.sh --apply`

   Note:
   During `--apply`, the script now:
   - runs `terraform fmt -recursive` automatically during apply
   - bootstraps the VPC, subnets, routing, and NAT first
   - bootstraps the EKS control plane next
   - updates IRSA trust policies from the cluster OIDC issuer
   - then runs the full Terraform apply

   This avoids the earlier timing issues where:
   - the EBS CSI add-on needed IRSA trust too late
   - worker nodes launched before private-subnet routing and NAT were ready

   After a successful apply, the script also writes timestamped backups of the Terraform state into `infra/aws/bkp/`.

   If apply is still running and you want to confirm progress from another shell, use these diagnostics:

   Check EKS cluster status:
   `aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto --query 'cluster.status' --output text`

   Show full cluster summary:
   `aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto`

   List managed node groups:
   `aws eks list-nodegroups --region us-east-1 --cluster-name dc-platform-bss-eks-proto`

   Then inspect a specific node group with its actual returned name:
   `aws eks describe-nodegroup --region us-east-1 --cluster-name dc-platform-bss-eks-proto --nodegroup-name <actual-nodegroup-name>`

   Check the EBS CSI add-on:
   `aws eks describe-addon --region us-east-1 --cluster-name dc-platform-bss-eks-proto --addon-name aws-ebs-csi-driver --query 'addon.status' --output text`

   After `platform/scripts/aws/10-connect-cluster.sh`, you can also inspect the Kubernetes side:
   `kubectl get nodes`
   `kubectl get pods -n kube-system`

   `platform/scripts/aws/10-connect-cluster.sh` is not required for Terraform apply itself.
   Use it:
   - after infra apply succeeds, before platform install
   - or during troubleshooting from another shell if you need to inspect nodes or `kube-system` pods while apply is still running

Next steps - refer to `platform/scripts/README.md`.

Current AWS Terraform layout:

- `infra/aws/network.tf`
- `infra/aws/cluster.tf`
- `infra/aws/storage.tf`
- `infra/aws/workload-identities.tf`
- `infra/aws/variables.tf`
- `infra/aws/terraform.tfvars`

This keeps the AWS prototype infrastructure in one readable folder while still separating network, cluster, storage, and IAM concerns by file.

Current separation of concerns:

- shared infra identities:
  - EKS cluster role
  - EKS node role
  - EBS CSI role
- workload identities:
  - entries in `infra/aws/terraform.tfvars` under `workload_identities`
  - looked up in `infra/aws/workload-identities.tf`
  - exposed through Terraform output `workload_identities`
- tenant onboarding:
  - Kubernetes tenant objects live under `platform/tenants/<tenant>/`
  - infra and platform are still separate on purpose, so adding a team currently touches both places

New tenant onboarding today:

1. Add a new entry under `workload_identities` in `infra/aws/terraform.tfvars`
   Include:
   - `namespace`
   - `service_account`
   - `role_name`
2. Run:
   `./infra/aws/deploy-infra.sh --apply`
   This ensures the IAM role exists and updates IRSA trust for the new namespace/service account pair.
3. Add or copy a tenant bundle under:
   `platform/tenants/<tenant>/`
4. If the tenant runs Spark jobs, add that namespace to:
   `platform/addons/spark-operator/values.yaml`
5. Deploy the tenant bundle.

Near-term note:

- `terraform.tfvars` is the current workload identity inventory, which is fine for now.
- As teams grow, we may want a more explicit env-specific config pattern than a single large `terraform.tfvars`.
- We may also want a lightweight tenant inventory that can eventually feed both:
  - infra workload identities
  - platform tenant bundles

Important current AWS note:

- Platform persistence defaults to `gp3`. The AWS infra apply creates the configured platform StorageClass so the platform layer does not depend on a preexisting cluster default StorageClass.
- Override it before platform deploy if your cluster should use a different class, for example:
  set `platform_storage_class` in `infra/aws/terraform.tfvars`
