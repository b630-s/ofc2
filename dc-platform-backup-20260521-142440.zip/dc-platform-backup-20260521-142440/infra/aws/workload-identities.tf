locals {
  # Workload identities are for platform and application services that run as
  # Kubernetes service accounts and access AWS through IRSA.
  #
  # Keep cluster add-on identities such as the EBS CSI driver separate. They
  # are not workload identities and should not be added to this map.
  workload_identities = var.workload_identities
}

data "aws_iam_role" "workload_identity" {
  for_each = local.workload_identities

  name = each.value.role_name
}
