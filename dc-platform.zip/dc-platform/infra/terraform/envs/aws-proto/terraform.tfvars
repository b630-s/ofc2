project_name        = "dc-platform"
environment         = "proto"
aws_region          = "us-east-1"

vpc_cidr            = "10.0.0.0/16"
availability_zones  = ["us-east-1a", "us-east-1b"]

private_subnet_cidrs = [
  "10.0.1.0/24",
  "10.0.2.0/24"
]

public_subnet_cidrs = [
  "10.0.101.0/24",
  "10.0.102.0/24"
]

eks_cluster_name    = "dc-platform-eks-proto"
eks_cluster_version = "1.34"

node_instance_types = ["m6i.xlarge"]
node_desired_size   = 3
node_min_size       = 3
node_max_size       = 5
node_disk_size      = 100