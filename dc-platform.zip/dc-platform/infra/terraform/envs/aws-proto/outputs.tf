# --- Network ---
output "vpc_id" {
  value = module.network.vpc_id
}

output "private_subnet_ids" {
  value = module.network.private_subnet_ids
}

output "public_subnet_ids" {
  value = module.network.public_subnet_ids
}

# --- EKS ---
output "eks_cluster_name" {
  value = module.cluster.cluster_name
}

output "eks_cluster_endpoint" {
  value = module.cluster.cluster_endpoint
}

output "cluster_oidc_issuer_url" {
  value = module.cluster.cluster_oidc_issuer_url
}

output "oidc_provider_arn" {
  value = module.cluster.oidc_provider_arn
}

# --- Storage ---
output "data_bucket_name" {
  value = module.storage.bucket_name
}

output "data_bucket_arn" {
  value = module.storage.bucket_arn
}

output "warehouse_path" {
  value = module.storage.warehouse_path
}

output "spark_checkpoint_path" {
  value = module.storage.spark_checkpoint_path
}

output "flink_checkpoint_path" {
  value = module.storage.flink_checkpoint_path
}

output "airflow_logs_path" {
  value = module.storage.airflow_logs_path
}

output "spark_event_logs_path" {
  value = module.storage.spark_event_logs_path
}

# --- Registry ---
output "ecr_repository_urls" {
  value = module.registry.repository_urls
}

# --- Identity (IRSA) ---
output "spark_irsa_role_arn" {
  value = module.identity.spark_irsa_role_arn
}

output "airflow_irsa_role_arn" {
  value = module.identity.airflow_irsa_role_arn
}

output "polaris_irsa_role_arn" {
  value = module.identity.polaris_irsa_role_arn
}

output "flink_irsa_role_arn" {
  value = module.identity.flink_irsa_role_arn
}