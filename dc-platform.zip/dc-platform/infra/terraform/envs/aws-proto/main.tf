module "network" {
  source = "../../modules/network"

  project_name         = var.project_name
  environment          = var.environment
  vpc_cidr             = var.vpc_cidr
  availability_zones   = var.availability_zones
  private_subnet_cidrs = var.private_subnet_cidrs
  public_subnet_cidrs  = var.public_subnet_cidrs
}

module "cluster" {
  source = "../../modules/cluster"

  project_name        = var.project_name
  environment         = var.environment
  aws_region          = var.aws_region
  eks_cluster_name    = var.eks_cluster_name
  eks_cluster_version = var.eks_cluster_version

  vpc_id             = module.network.vpc_id
  private_subnet_ids = module.network.private_subnet_ids

  node_instance_types = var.node_instance_types
  node_desired_size   = var.node_desired_size
  node_min_size       = var.node_min_size
  node_max_size       = var.node_max_size
  node_disk_size      = var.node_disk_size
}

module "storage" {
  source = "../../modules/storage"

  project_name = var.project_name
  environment  = var.environment
  aws_region   = var.aws_region
}

module "registry" {
  source = "../../modules/registry"

  project_name = var.project_name
  environment  = var.environment
}

module "identity" {
  source = "../../modules/identity"

  project_name      = var.project_name
  environment       = var.environment
  oidc_provider_arn = module.cluster.oidc_provider_arn
  s3_bucket_arn     = module.storage.bucket_arn
}