output "bucket_name" {
  value = aws_s3_bucket.data.bucket
}

output "bucket_arn" {
  value = aws_s3_bucket.data.arn
}

output "warehouse_path" {
  value = "s3://${aws_s3_bucket.data.bucket}/warehouse/"
}

output "spark_checkpoint_path" {
  value = "s3://${aws_s3_bucket.data.bucket}/spark-checkpoints/"
}

output "flink_checkpoint_path" {
  value = "s3://${aws_s3_bucket.data.bucket}/flink-checkpoints/"
}

output "airflow_logs_path" {
  value = "s3://${aws_s3_bucket.data.bucket}/airflow-logs/"
}

output "spark_event_logs_path" {
  value = "s3://${aws_s3_bucket.data.bucket}/spark-event-logs/"
}