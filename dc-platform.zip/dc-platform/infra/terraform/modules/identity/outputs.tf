output "spark_irsa_role_arn" {
  value = module.spark_irsa_role.iam_role_arn
}

output "airflow_irsa_role_arn" {
  value = module.airflow_irsa_role.iam_role_arn
}

output "polaris_irsa_role_arn" {
  value = module.polaris_irsa_role.iam_role_arn
}

output "flink_irsa_role_arn" {
  value = module.flink_irsa_role.iam_role_arn
}