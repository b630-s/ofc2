From infra/terraform/envs/aws-proto:
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out tfplan
# terraform apply tfplan

Then verify:

aws eks update-kubeconfig --region us-east-1 --name dc-platform-eks-proto
kubectl get nodes
kubectl get pods -A

You should see the managed nodes come up, and after a short while the core system pods and add-ons should stabilize.

How to STOP charges
From:

infra/terraform/envs/aws-proto/
terraform plan -destroy
terraform state list
terraform destroy


Safety check before leaving
run:
aws eks list-clusters
aws ec2 describe-instances