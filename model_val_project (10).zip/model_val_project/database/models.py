from sqlalchemy import (
    create_engine,
    Table,
    Column,
    Integer,
    String,
    Date,
    Enum,
    JSON,
    ForeignKey,
    CheckConstraint,
)
# from sqlalchemy import create_engine, Column, Integer, String, Date, JSON, ForeignKey, CheckConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Integer, Text, DateTime, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import date, datetime
from .sample_data import *


# Model attribute options
MODEL_TYPES = ["Financial", "ML", "Statistical", "Custom"]
MATERIALITY_LEVELS = ["High", "Medium", "Low"]
COMPLEXITY_LEVELS = ["Simple", "Moderate", "Complex"]
RISK_RATINGS = ["Low", "Medium", "High"]
VALIDATION_FREQUENCIES = ["Annual", "Semi-Annual", "Quarterly", "Custom"]
MODEL_STATUSES = ["active", "inactive", "deprecated"]
FRAMEWORKS = ["scikit-learn", "TensorFlow", "PyTorch", "XGBoost", "custom"]
LANGUAGES = ["Python", "R", "Java", "C++", "custom"]
INVOCATION_METHODS = ["REST API", "gRPC", "local invocation", "custom"]

Base = declarative_base()

benchmark_datasets = Table(
    "benchmark_datasets",
    Base.metadata,
    Column("benchmark_model_id", Integer, ForeignKey("benchmark_models.benchmark_model_id"), primary_key=True),
    Column("dataset_id", Integer, ForeignKey("datasets.dataset_id"), primary_key=True)
)

class BenchmarkModel(Base):
    __tablename__ = "benchmark_models"

    benchmark_model_id = Column(Integer, primary_key=True, autoincrement=True)
    benchmark_model_name = Column(String, nullable=False)
    algorithm = Column(String, nullable=False)
    model_type = Column(String, CheckConstraint("model_type IN ('Financial', 'ML', 'Statistical', 'Custom')"))
    business_line = Column(String, nullable=True)
    business_name = Column(String, nullable=True)
    developer_team = Column(String, nullable=True)  # Team or individual responsible for development
    owner_entity = Column(String, nullable=True)  # Department or entity owning the model
    framework = Column(String, CheckConstraint("framework IN ('scikit-learn', 'TensorFlow', 'PyTorch', 'XGBoost', 'custom')"), nullable=False)
    custom_framework = Column(String, nullable=True)  # Custom framework if 'custom' is chosen
    language = Column(String, CheckConstraint("language IN ('Python', 'R', 'Java', 'C++', 'custom')"), nullable=False)
    custom_language = Column(String, nullable=True)  # Custom language if 'custom' is chosen
    materiality = Column(String, CheckConstraint("materiality IN ('High', 'Medium', 'Low')"), nullable=True)  # Similar to Model table
    complexity = Column(String, CheckConstraint("complexity IN ('Simple', 'Moderate', 'Complex')"), nullable=True)
    hyperparameters = Column(JSON, nullable=True)  # JSON field for hyperparameter configurations
    creation_date = Column(Date, default=datetime.now)
    last_modified_date = Column(Date, default=datetime.now, onupdate=datetime.now)
    validation_frequency = Column(String, CheckConstraint("validation_frequency IN ('Annual', 'Semi-Annual', 'Quarterly', 'Custom')"), nullable=True)
    validation_days = Column(Integer, nullable=True)  # Frequency interval in days if 'Custom' is chosen

    # Benchmarking metrics and status
    benchmark_status = Column(String, CheckConstraint("benchmark_status IN ('active', 'inactive', 'deprecated')"), nullable=False, default="active")
    performance_metrics = Column(JSON, nullable=True)  # JSON for metrics like accuracy, recall, etc.
    benchmark_score = Column(String, nullable=True)  # Scoring for the benchmark model
    risk_rating = Column(String, CheckConstraint("risk_rating IN ('Low', 'Medium', 'High')"), nullable=True)
    
    # Deployment-related fields for benchmarking
    deployment_endpoint = Column(String, nullable=True)  # API or endpoint for deployment
    invocation_method = Column(String, CheckConstraint("invocation_method IN ('REST API', 'gRPC', 'local invocation', 'custom')"), nullable=True)
    custom_invocation_method = Column(String, nullable=True)  # Custom method if 'custom' is chosen
    
    # Relationships
    datasets = relationship("Dataset", secondary="benchmark_datasets", back_populates="benchmark_models")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the benchmark_models table."""
        return sample_BenchmarkModel
    
class Model(Base):
    __tablename__ = "models"

    model_id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String, nullable=False)
    asset_class = Column(String, nullable=False)
    product = Column(String, nullable=False)
    model_type = Column(String)
    business_line = Column(String)
    business_name = Column(String)  # Added business_name
    model_tier = Column(String)  # Added model_tier
    questionnaire_tier = Column(String)  # Added questionnaire_tier
    algorithm = Column(String)
    model_developer = Column(String)
    creation_date = Column(Date)
    last_modified_date = Column(Date)
    owner_entity = Column(String)
    materiality = Column(String)
    complexity = Column(String)

    # Framework and language related fields
    model_framework = Column(
        String,
        CheckConstraint(
            "model_framework IN ('scikit-learn', 'TensorFlow', 'PyTorch', 'XGBoost', 'custom')"
        ),
        nullable=False,
    )
    custom_framework = Column(
        String, nullable=True
    )  # Field for user-defined frameworks (if 'custom' is chosen)
    model_language = Column(
        String,
        CheckConstraint("model_language IN ('Python', 'R', 'Java', 'C++', 'custom')"),
        nullable=False,
    )
    custom_language = Column(
        String, nullable=True
    )  # Field for user-defined languages (if 'custom' is chosen)

    # Model deployment and invocation fields
    deployment_endpoint = Column(
        String, nullable=True
    )  # API or local endpoint where the model is deployed
    input_schema = Column(
        String, nullable=True
    )  # JSON or other format specifying input structure
    output_schema = Column(
        String, nullable=True
    )  # JSON or other format specifying output structure
    input_example = Column(String, nullable=True)  # Example input for the model
    output_example = Column(String, nullable=True)  # Example output for the model
    invocation_method = Column(
        String,
        CheckConstraint(
            "invocation_method IN ('REST API', 'gRPC', 'local invocation', 'custom')"
        ),
        nullable=False,
    )
    custom_invocation_method = Column(
        String, nullable=True
    )  # Field for user-defined invocation method (if 'custom' is chosen)

    # Validation-related fields
    validation_frequency = Column(
        String
    )  # Period (weekly, monthly, n-days, yearly, etc.)
    validation_days = Column(
        Integer, nullable=True
    )  # Only populated if validation_frequency is 'n-days'
    last_validation_date = Column(Date)
    next_validation_date = Column(Date)

    # Status and rating fields
    model_status = Column(
        String, CheckConstraint("model_status IN ('active', 'inactive', 'deprecated')")
    )
    risk_rating = Column(String)
    validation_rating = Column(String)  # Added validation_rating

    # Relationships
    model_validations = relationship("ModelValidation", back_populates="model")
    documents = relationship("Document", back_populates="model")
    action_plans = relationship("ActionPlan", back_populates="model")
    benchmark_mappings = relationship("ModelBenchmarkMapping", back_populates="primary_model")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the models table."""
        return sample_Model
    
class ModelBenchmarkMapping(Base):
    __tablename__ = "model_benchmark_mapping"

    primary_model_id = Column(Integer, ForeignKey("models.model_id"), primary_key=True)
    benchmark_model_id = Column(Integer, ForeignKey("benchmark_models.benchmark_model_id"), primary_key=True)
    dataset_id = Column(Integer, ForeignKey("datasets.dataset_id"), primary_key=True)
    mapping_type = Column(Enum("training", "testing", "comparison", name="mapping_type_enum"), nullable=False)

    # Optional metadata columns
    created_date = Column(Date, default=datetime.now)
    last_modified_date = Column(Date, onupdate=datetime.now)

    primary_model = relationship("Model", back_populates="benchmark_mappings")
    benchmark_model = relationship("BenchmarkModel")
    dataset = relationship("Dataset")

    # Updates to the Model class to incorporate benchmark mappings
    Model.benchmark_mappings = relationship("ModelBenchmarkMapping", back_populates="primary_model")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the model_benchmark_mapping table."""
        return sample_ModelBenchmarkMapping 
    
class Dataset(Base):
    __tablename__ = "datasets"

    dataset_id = Column(Integer, primary_key=True, autoincrement=True)
    dataset_name = Column(String, nullable=False)
    source = Column(String, nullable=True)  # e.g., "internal", "external", "public API"
    description = Column(Text, nullable=True)  # Description of the dataset's purpose
    storage_location = Column(String, nullable=False)  # Path or URL to access the dataset
    usage_type = Column(Enum("training", "validation", "benchmarking", "testing", "feature engineering", name="usage_type_enum"), nullable=False)
    data_type = Column(Enum("tabular", "image", "text", "time-series", "audio", name="data_type_enum"), nullable=False)  # Type of data in the dataset
    format = Column(String, nullable=True)  # e.g., "CSV", "JSON", "Parquet"
    created_date = Column(Date, default=datetime.now)
    last_modified_date = Column(Date, default=datetime.now)
    comments = Column(Text, nullable=True)  # Any additional notes or context
    tags = Column(String, nullable=True)  # Tags for categorizing or searching datasets

    # Relationship for benchmark mapping
    benchmark_models = relationship("BenchmarkModel", secondary="benchmark_datasets", back_populates="datasets")

    @classmethod
    def get_sample_data(cls):
        return sample_Dataset
    
VALIDATION_STATUSES = ["in progress", "completed", "rejected"]

class ModelValidation(Base):
    __tablename__ = "model_validations"

    validation_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_name = Column(String, nullable=False)
    model_id = Column(Integer, ForeignKey("models.model_id"), nullable=False)
    validation_date = Column(Date, default=date.today)
    validator_name = Column(String, nullable=False)
    validation_status = Column(
        String,
        CheckConstraint(
            "validation_status IN ('in progress', 'completed', 'rejected')"
        ),
        nullable=False,
    )
    validation_score = Column(String, nullable=True)
    validation_comments = Column(String, nullable=True)

    # Relationships
    model = relationship("Model", back_populates="model_validations")
    findings = relationship("Finding", back_populates="model_validation")
    documents = relationship("Document", back_populates="validation")
    invocations = relationship("ModelInvocation", back_populates="model_validation")
    action_plans = relationship("ActionPlan", back_populates="validation")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the model_validations table."""
        return sample_ModelValidation 
        

class Finding(Base):
    __tablename__ = "findings"

    finding_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=False
    )
    finding_type = Column(
        String, CheckConstraint("finding_type IN ('numeric', 'text')"), nullable=False
    )
    finding_value = Column(String, nullable=True)
    finding_status = Column(
        String,
        CheckConstraint("finding_status IN ('open', 'closed', 'in progress')"),
        nullable=False,
    )
    finding_comments = Column(String, nullable=True)

    # Risk assessment attributes
    risk_category = Column(
        Enum(
            "model",
            "operational",
            "compliance",
            "financial",
            "technical",
            name="risk_categories",
        ),
        nullable=True,
    )
    risk_description = Column(String, nullable=True)
    risk_score = Column(Integer, nullable=True)
    mitigation_plan = Column(String, nullable=True)
    assessment_status = Column(
        String,
        CheckConstraint("assessment_status IN ('open', 'mitigated', 'closed')"),
        nullable=True,
    )

    # Relationships
    model_validation = relationship("ModelValidation", back_populates="findings")
    action_plans = relationship("ActionPlan", back_populates="finding")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the findings table."""
        return sample_Findings
    

class Document(Base):
    __tablename__ = "documents"

    document_id = Column(Integer, primary_key=True, autoincrement=True)
    model_id = Column(Integer, ForeignKey("models.model_id"), nullable=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=True
    )
    document_name = Column(String, nullable=False)
    document_path = Column(String, nullable=False)
    document_type = Column(
        String,
        CheckConstraint("document_type IN ('model', 'validation')"),
        nullable=False,
    )
    upload_date = Column(Date, default=date.today)

    model = relationship("Model", back_populates="documents")
    validation = relationship("ModelValidation", back_populates="documents")
    action_plans = relationship("ActionPlan", back_populates="attachment")

    __table_args__ = (
        # CheckConstraint(
        #     "(model_id IS NOT NULL AND validation_id IS  NULL) OR (model_id IS NULL AND validation_id IS NOT NULL)",
        #     name="check_model_or_validation",
        # ),
    )

    @classmethod
    def get_sample_data(cls):
        """Sample data for the documents table."""
        return sample_Documents
   
class ModelInvocation(Base):
    __tablename__ = "model_invocations"

    invocation_id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=False
    )

    model_framework = Column(
        Enum(
            "scikit-learn",
            "TensorFlow",
            "PyTorch",
            "XGBoost",
            "custom",
            name="model_framework_enum",
        ),
        nullable=False,
    )
    invocation_timestamp = Column(DateTime, default=datetime.utcnow)
    model_version = Column(String, nullable=True)
    execution_environment = Column(
        Enum(
            "Spark Cluster",
            "local",
            "aws",
            "gcp",
            "azure",
            "docker",
            "custom",
            name="execution_env_enum",
        ),
        nullable=False,
    )

    input_data = Column(Text, nullable=False)  # Could be path or serialized JSON
    input_description = Column(String, nullable=True)
    output_data = Column(Text, nullable=True)  # Serialized JSON or path to output

    metrics = Column(Text, nullable=True)  # JSON or string for key-value metric pairs
    runtime_seconds = Column(Float, nullable=True)
    hardware_used = Column(String, nullable=True)
    status = Column(
        Enum("success", "failed", name="invocation_status_enum"), nullable=False
    )
    error_message = Column(String, nullable=True)

    hyperparameters = Column(
        Text, nullable=True
    )  # Optional: hyperparameters in JSON format
    deployment_endpoint = Column(String, nullable=True)
    invocation_mode = Column(
        Enum("batch", "real-time", name="invocation_mode_enum"), nullable=False
    )
    triggered_by_user = Column(Boolean, default=True)

    comments = Column(String, nullable=True)

    # Relationship with ModelValidation
    model_validation = relationship("ModelValidation", back_populates="invocations")

    @classmethod
    def get_sample_data(cls):
        return sample_ModelInvocation
    

class ActionPlan(Base):
    __tablename__ = "action_plans"

    action_id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String, nullable=False)
    type = Column(
        Enum(
            "preventive",
            "corrective",
            "mitigative",
            "other",
            name="action_plan_type_enum",
        ),
        nullable=False,
    )
    priority = Column(
        Enum("low", "medium", "high", name="priority_enum"), nullable=False
    )
    description = Column(Text, nullable=True)
    finding_id = Column(
        Integer, ForeignKey("findings.finding_id"), nullable=True
    )  # Foreign key to Findings table
    validation_id = Column(
        Integer, ForeignKey("model_validations.validation_id"), nullable=True
    )  # Foreign key to ModelValidations table
    model_id = Column(
        Integer, ForeignKey("models.model_id"), nullable=True
    )  # Foreign key to Models table
    attachment_id = Column(
        Integer, ForeignKey("documents.document_id"), nullable=True
    )  # Foreign key to Documents table
    due_date = Column(Date, nullable=False)
    reported_by = Column(String, nullable=False)
    affected_entities = Column(
        String, nullable=True
    )  # Could be a list of affected entities or individuals
    created_date = Column(Date, default=datetime.now)
    updated_date = Column(Date, onupdate=datetime.now)

    # Relationships
    finding = relationship("Finding", back_populates="action_plans")
    validation = relationship("ModelValidation", back_populates="action_plans")
    model = relationship("Model", back_populates="action_plans")
    attachment = relationship("Document", back_populates="action_plans")

    @classmethod
    def get_sample_data(cls):
        """Sample data for the action_plans table."""
        return sample_ActionPlan
        