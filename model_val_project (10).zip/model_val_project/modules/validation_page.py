import streamlit as st
from database.crud import get_all_model_validations, create_model_validation, get_model_validation, update_model_validation, get_model_for_validation
import pandas as pd
from utils.db_common import *
from datetime import datetime
from database.models import (
    VALIDATION_STATUSES,
    RISK_RATINGS,
)

from streamlit_extras.stylable_container import stylable_container

#  general validation information and editing form
def validation_information_section(db, validation):
    with st.form("validation_information_form"):
        st.markdown("#### Validation General Information")
        col1, col2 = st.columns(2)
        with col1:
            validation_name = st.text_input("Validation Name", value=validation.validation_name, max_chars=100)
            validation_date = st.date_input("Validation Date", value=validation.validation_date)
            validator_name = st.text_input("Validator Name", value=validation.validator_name, max_chars=100)
        with col2:
            validation_status = st.selectbox("Validation Status", VALIDATION_STATUSES, index=VALIDATION_STATUSES.index(validation.validation_status) if validation.validation_status in VALIDATION_STATUSES else 0)
            validation_score = st.text_input("Validation Score", value=validation.validation_score)
            validation_comments = st.text_area("Comments", value=validation.validation_comments)

        submit_button = st.form_submit_button("Update Validation Information")
        if submit_button:
            update_data = {
                "validation_name": validation_name,
                "validation_date": validation_date,
                "validator_name": validator_name,
                "validation_status": validation_status,
                "validation_score": validation_score,
                "validation_comments": validation_comments
            }
            update_model_validation(db, validation.validation_id, update_data)
            st.success("Validation Information updated successfully.")

# Section for displaying model details associated with a validation
def associated_model_section(db, validation):
    model = get_model_for_validation(db, validation.validation_id)
    if model:
        st.markdown("#### Associated Model Information")
        st.write(f"**Model Name:** {model.model_name}")
        st.write(f"**Model Type:** {model.model_type}")
        st.write(f"**Business Line:** {model.business_line}")
        st.write(f"**Model Tier:** {model.model_tier}")
        st.write(f"**Algorithm:** {model.algorithm}")
        st.write(f"**Risk Rating:** {model.risk_rating}")
    else:
        st.info("No associated model found for this validation.")

# Section for viewing related findings
def related_findings_section(db, validation):
    findings = validation.findings
    if findings:
        st.markdown("#### Related Findings")
        findings_data = [{
            "Finding ID": finding.finding_id,
            "Type": finding.finding_type,
            "Value": finding.finding_value,
            "Status": finding.finding_status,
            "Risk Category": finding.risk_category,
            "Risk Score": finding.risk_score,
            "Mitigation Plan": finding.mitigation_plan,
            "Comments": finding.finding_comments,
        } for finding in findings]
        findings_df = pd.DataFrame(findings_data)
        st.dataframe(findings_df)
    else:
        st.info("No findings associated with this validation.")

# Section for viewing related action plans
def related_action_plans_section(db, validation):
    action_plans = validation.action_plans
    if action_plans:
        st.markdown("#### Related Action Plans")
        action_plans_data = [{
            "Action ID": action.action_id,
            "Title": action.title,
            "Priority": action.priority,
            "Due Date": action.due_date,
            "Reported By": action.reported_by,
            "Affected Entities": action.affected_entities,
            "Description": action.description,
        } for action in action_plans]
        action_plans_df = pd.DataFrame(action_plans_data)
        st.dataframe(action_plans_df)
    else:
        st.info("No action plans associated with this validation.")

# Main function for viewing/editing validation details
def view_edit_validation(db, validation_id):
    validation = get_model_validation(db, validation_id)
    
    if not validation:
        st.error("Validation not found.")
        return

    st.subheader("Validation Details")
    e0x = st.empty()
    e1x = st.empty()
    with st.sidebar:
        with stylable_container(
            key="blue_button",
            css_styles="""
                {
                    background-color: #1E2A38;
                    color: lightcyan;
                    border-radius: 2px;
                    padding:5px;
                }
                """,
        ):
            optx = st.radio(
                "Select a view",
                [
                    ":clipboard: Validation Information",
                    ":bar_chart: Associated Model",
                    ":warning: Related Findings",
                    ":memo: Action Plans",
                ],
            )
        if st.checkbox("Show Related Findings and Action Plans"):
            with e0x:
                with st.expander("Expand to view findings and action plans", expanded=True):
                    st.markdown("<h6 style='color: #4A90E2; font-weight: bold;'>Related Information</h6>", unsafe_allow_html=True)
                    related_findings_section(db, validation)
                    related_action_plans_section(db, validation)

    # Main logic to call sections based on selected option
    if optx == ":clipboard: Validation Information":
        validation_information_section(db, validation)
    elif optx == ":bar_chart: Associated Model":
        associated_model_section(db, validation)
    elif optx == ":warning: Related Findings":
        related_findings_section(db, validation)
    elif optx == ":memo: Action Plans":
        related_action_plans_section(db, validation)

# Main page function for validations
def validations_page(db):
    if "active_validation_id" in st.session_state.keys():
        v = int(st.session_state["active_validation_id"])
        view_edit_validation(db, v)



# import streamlit as st
# from database.crud import create_model_validation, get_all_models
# from datetime import datetime
# from database.models import Model, VALIDATION_STATUSES 


# def add_validation_form(db):
#     st.subheader("Add New Validation")

#     models_list = get_all_models(db)
#     model_options = {model.model_name: model.model_id for model in models_list}

#     if not model_options:
#         st.warning("No models available. Please add a model first.")
#         return

#     with st.form("add_validation_form"):
#         # Validation Information Section
#         with st.container():
#             st.markdown("### Validation Information")
#             col1, col2 = st.columns(2)
#             with col1:
#                 validation_name = st.text_input("Validation Name", max_chars=100)
#                 model_name = st.selectbox("Associated Model", list(model_options.keys()))
#                 validation_date = st.date_input("Validation Date", value=datetime.now())
#             with col2:
#                 validator_name = st.text_input("Validator Name", max_chars=100)
#                 validation_status = st.selectbox("Validation Status", VALIDATION_STATUSES)

#         # Additional Details Section
#         with st.container():
#             st.markdown("### Additional Details")
#             col1, col2 = st.columns(2)
#             with col1:
#                 validation_score = st.text_input("Validation Score", max_chars=10)  # This can be an integer or float input if needed
#             with col2:
#                 validation_comments = st.text_area("Comments")

#         # Submit Button
#         submit_button = st.form_submit_button(label="Add Validation")

#         # Submit Action
#         if submit_button:
#             if validation_name:
#                 new_validation_data = {
#                     "validation_name": validation_name,
#                     "model_id": model_options[model_name],
#                     "validation_date": validation_date,
#                     "validator_name": validator_name,
#                     "validation_status": validation_status,
#                     "validation_score": validation_score,
#                     "validation_comments": validation_comments
#                 }
                
#                 # Call the CRUD function to add a new validation to the database
#                 create_model_validation(db, new_validation_data)
#                 st.success(f"Validation '{validation_name}' has been added successfully!")
#             else:
#                 st.error("Validation name is required.")


# def load_validation(db):
#     st.write("### validations ")
#     add_validation_form(db)
