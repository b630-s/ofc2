import streamlit as st


import streamlit as st
import pandas as pd
from datetime import datetime
from database.crud import (
    create_document,
    get_document,
    get_all_documents,
    update_document,
    delete_document,
)
from database.models import Document, Model, ModelInvocation, ModelValidation
from utils.misc_common import *
from streamlit_pdf_viewer import pdf_viewer
from PIL import Image
import docx
import base64


DOCUMENT_TYPES = ["data", "model", "testing", "regulatory"]

def display_document(file_path):
    file_extension = file_path.split('.')[-1].lower()

    if file_extension in ["png", "jpg", "jpeg", "bmp", "gif", "tiff"]:
        st.image(file_path, use_column_width=True)
    elif file_extension == "pdf":
        # pdf_viewer(file_path)
        with open(file_path, "rb") as pdf_file:
            pdf_data = pdf_file.read()
            pdf_base64 = base64.b64encode(pdf_data).decode("utf-8")
            pdf_display = f"""
            <div style="border: 1px solid #ddd; border-radius: 5px; overflow: auto; height: 600px;">
                <iframe src="data:application/pdf;base64,{pdf_base64}" width="100%" height="100%" style="border: none;"></iframe>
            </div>
            """
            st.markdown(pdf_display, unsafe_allow_html=True)
    elif file_extension == "docx":
        doc = docx.Document(file_path)
        text = '\n'.join([para.text for para in doc.paragraphs])
        st.text_area("Document Content", text, height=400)
    else:
        st.error("Unsupported file type")

def manage_documents(db):
    st.sidebar.header("Documents")

    with st.sidebar:
        selected_type = st.radio("Filter by Document Type",  ["All"]+DOCUMENT_TYPES, index=0)
        action = st.radio(
            "Actions",
            options=["View Documents", "Add Document", "Edit Document", "Delete Document"],
        )
        pdf_file = st.file_uploader("Upload PDF file", type=('pdf'))

    if action == "View Documents":
        styled_header("View All Documents")
        documents = get_all_documents(db)

        if selected_type != "All":
            documents = [doc for doc in documents if doc.document_type == selected_type]

        if documents:
            document_records = []
            for doc in documents:
                model_name = (
                    db.query(Model.model_name)
                    .filter(Model.model_id == doc.model_id)
                    .scalar()
                    if doc.model_id else None
                )
                validation_name = (
                    db.query(ModelValidation.validation_name)
                    .filter(ModelValidation.validation_id == doc.validation_id)
                    .scalar()
                    if doc.validation_id else None
                )
                document_records.append({
                    "Document ID": doc.document_id,
                    "Name": doc.document_name,
                    "Type": doc.document_type,
                    
                    "Model Name": model_name or "N/A",
                    "Validation Name": validation_name or "N/A",
                    "Path": doc.document_path,
                    "Upload Date": doc.upload_date,
                })

            # Display the documents in a DataFrame
            documents_df = pd.DataFrame(document_records)
            # st.dataframe(documents_df, use_container_width=True)
            selected_index = st.dataframe(
            data=documents_df,  
            use_container_width=True,
            hide_index=True,
            # height=300,
            selection_mode="single-row",
            on_select="rerun",
        )


        if selected_index and len(selected_index.selection["rows"]):
            selected_row = selected_index.selection["rows"][0]
            doc_id = documents_df.iloc[selected_row]["Document ID"]
            doc_name = documents_df.iloc[selected_row]["Name"]

            # Set selected document in session state
            st.session_state["active_document_id"] = doc_id
            st.session_state["active_document_name"] = doc_name
            doc_path = documents_df.iloc[selected_row]["Path"]

            # st.success(f"Selected Document: {doc_path} (ID: {doc_id})")
            display_document(doc_path)

            


        # else:
        #     st.info(f"No documents found for type '{selected_type}'.")

    elif action == "Add Document":
        styled_header("Add New Document")
        with st.form("add_document_form"):
            document_name = st.text_input("Document Name")
            document_path = st.text_input("Document Path")
            document_type = st.selectbox("Document Type", DOCUMENT_TYPES)
            model_id = st.number_input("Model ID (Optional)", min_value=0, step=1)
            validation_id = st.number_input("Validation ID (Optional)", min_value=0, step=1)
            submit_button = st.form_submit_button("Add Document")

            if submit_button:
                new_document = {
                    "document_name": document_name,
                    "document_path": document_path,
                    "document_type": document_type,
                    "model_id": model_id if model_id > 0 else None,
                    "validation_id": validation_id if validation_id > 0 else None,
                    "upload_date": datetime.now(),
                }
                create_document(db, new_document)
                st.success(f"Document '{document_name}' added successfully.")

    elif action == "Edit Document":
        styled_header("Edit a Document")
        # st.subheader("Edit Document")
        documents = get_all_documents(db)
        if documents:
            document_options = {f"{doc.document_name} (ID: {doc.document_id})": doc.document_id for doc in documents}
            selected_document = st.selectbox("Select Document", list(document_options.keys()))
            document_id = document_options[selected_document]

            document = get_document(db, document_id)
            if document:
                with st.form("edit_document_form"):
                    document_name = st.text_input("Document Name", value=document.document_name)
                    document_path = st.text_input("Document Path", value=document.document_path)
                    document_type = st.selectbox("Document Type", DOCUMENT_TYPES, index=DOCUMENT_TYPES.index(document.document_type))
                    model_id = st.number_input("Model ID (Optional)", value=document.model_id or 0, min_value=0, step=1)
                    validation_id = st.number_input("Validation ID (Optional)", value=document.validation_id or 0, min_value=0, step=1)
                    submit_button = st.form_submit_button("Update Document")

                    if submit_button:
                        update_data = {
                            "document_name": document_name,
                            "document_path": document_path,
                            "document_type": document_type,
                            "model_id": model_id if model_id > 0 else None,
                            "validation_id": validation_id if validation_id > 0 else None,
                        }
                        update_document(db, document_id, update_data)
                        st.success(f"Document '{document_name}' updated successfully.")
            else:
                st.error("Document not found.")

    elif action == "Delete Document":
        # st.subheader("Delete Document")
        styled_header("Delete a Document")
        documents = get_all_documents(db)
        if documents:
            document_options = {f"{doc.document_name} (ID: {doc.document_id})": doc.document_id for doc in documents}
            selected_document = st.selectbox("Select Document to Delete", list(document_options.keys()))
            document_id = document_options[selected_document]

            if st.button("Delete Document"):
                delete_document(db, document_id)
                st.success(f"Document '{selected_document}' deleted successfully.")
        else:
            st.info("No documents available to delete.")



def load_documentation(db):
    
    manage_documents(db)