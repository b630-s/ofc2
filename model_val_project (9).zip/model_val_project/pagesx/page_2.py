import streamlit as st
from utils.db_common import *
from streamlit_extras.stylable_container import stylable_container

st.write("page2 Documentation")

col = st.columns((10,2), gap='medium')
custom_css = """
<style>
.my-bg {
    background-color: #f0f2f6;
}
</style>

"""
st.markdown(custom_css, unsafe_allow_html=True)
with col[0]:
    st.write("content area....")
    e1= st.empty()

with col[1]:
    with stylable_container(
        key="green_button",
        css_styles="""
             {
                background-color: #112233;
                color: cyan;
                border-radius: 2px;
                padding:5px;
            }
            """,
    ):
        st.write("options area....")
        # how to update content area from here
        if st.checkbox('Show Invocations'):
            with e1:
                display_table_data(ModelInvocation, db)

        if st.checkbox('Show ActionPlan'):
            with e1:
                display_table_data(ActionPlan, db)

        if st.button('Recreate Database'):
            with e1:
                recreate_database()

        if st.button('Load Sample Data'):
            with e1:
                load_sample_data()