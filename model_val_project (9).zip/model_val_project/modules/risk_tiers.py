import streamlit as st

def load_risk_tiers(validation_id):
    st.write("### Risk/Tier Assessment")
    st.write(f"Displaying risk tier details for Validation ID: {validation_id}")