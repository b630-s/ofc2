import streamlit as st
from utils.db_common import *
import os

def get_db_size(db_path: str) -> str:
    """Get the size of the SQLite database in megabytes."""
    if os.path.exists(db_path):
        db_size = os.path.getsize(db_path) / (1024 * 1024)  # Convert bytes to MB
        return f"{db_size:.2f} MB"
    else:
        return "Database not found"
    
def settings_page():
    # st.title("Settings")


    st.markdown(
        """
        <style>
        .settings-container {
            background-color: #f9f9f9;
            padding: 1px;
            border-radius: 1px;
            border: 1px solid #e0e0e0;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
            margin-top: 10px;
        }
        .button-style {
            font-size: 16px;
            color: white;
            background-color: #4A90E2;
            border-radius: 5px;
            padding: 10px 20px;
        }
        </style>
        """, unsafe_allow_html=True
    )

    # Settings container
    with st.container():
        st.markdown("<div class='settings-container'>", unsafe_allow_html=True)

        st.subheader("Database Management")
        if st.button("Create Database", key="create_db", help="Initialize the database schema"):
            recreate_database()

        if st.button("Load Sample Data", key="load_data", help="Load sample records into the database"):
            load_sample_data()

        if st.button("Clear Database", key="clear_db", help="Remove all records from the database"):
            recreate_database()
        
        st.markdown("</div>", unsafe_allow_html=True)

    # System Information
    with st.container():
        st.markdown("<div class='settings-container'>", unsafe_allow_html=True)
        st.subheader("System Information")

        st.write("Database Path: ",DATABASE_URL)
        st.write("Database Size: ~MB ", get_db_size("database.db"))
        st.write("Last Updated: 2024-11-04")
        
        st.markdown("</div>", unsafe_allow_html=True)
