import streamlit as st
from nbconvert import HTMLExporter
import nbformat
import os
from bs4 import BeautifulSoup
import subprocess
import socket
import webbrowser


import pandas as pd
import plotly.express as px
from datetime import datetime
from database.crud import get_model, get_model_validations, get_historical_metrics
import streamlit_antd_components as sac
from utils.misc_common import *


notebook_port = 8888
venv_path = "../.venv"


def upload_jupyter_notebook(notebooks_folder="notebooks"):
    # Create the notebooks folder if it doesn't exist
    if not os.path.exists(notebooks_folder):
        os.makedirs(notebooks_folder)

    uploaded_file = st.file_uploader(
        "Upload a Jupyter Notebook (.ipynb)",
        type=["ipynb"],
    )

    if uploaded_file is not None:
        save_path = os.path.join(notebooks_folder, uploaded_file.name)
        with open(save_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        st.success(f"Notebook '{uploaded_file.name}' uploaded successfully to '{notebooks_folder}'.")
        return save_path

    return None

def select_jupyter_notebook(notebooks_folder="notebooks"):
    notebook_files = [
        os.path.join(notebooks_folder, f)
        for f in os.listdir(notebooks_folder)
        if f.endswith(".ipynb")
    ]

    if not notebook_files:
        st.warning("No Jupyter notebooks found in the 'notebooks' folder.")
        return None
    selected_notebook = st.selectbox(
        "Select a Jupyter Notebook", notebook_files, format_func=lambda x: os.path.basename(x)
    )

    return selected_notebook



def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0
    
def start_jupyter_notebook():
    if not is_port_in_use(notebook_port):
        jupyter_executable = os.path.join(venv_path, "Scripts", "jupyter.exe")
        subprocess.Popen([jupyter_executable, "notebook", "--no-browser", "--port", str(notebook_port)], shell=True)
        st.success(f"Jupyter Notebook launched on http://localhost:{notebook_port}")
        webbrowser.open(f"http://localhost:{notebook_port}")
    else:
        st.info(f"Jupyter Notebook is already running on http://localhost:{notebook_port}")

def display_notebook_as_html(notebook_path):
    notebook_name = os.path.basename(notebook_path).replace(".ipynb", "")
    st.markdown(f"## 🗒️ {notebook_name}")
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    html_exporter = HTMLExporter()
    html_exporter.exclude_input = False
    html_exporter.embed_images = True
    html_exporter.exclude_output = False
    html_exporter.exclude_code_cell = False
    html_exporter.exclude_anchor_links = False
    html_exporter.exclude_markdown = False
    html_exporter.exclude_raw = False
    html_data, _ = html_exporter.from_notebook_node(notebook_content)
    soup = BeautifulSoup(html_data, "html.parser")
    toc = []
    for header in soup.find_all(["h1", "h2", "h3"]):
        section_id = header.text.replace(" ", "-").lower()
        header["id"] = section_id
        toc.append((header.text, f"#{section_id}"))
    st.markdown("### Table of Contents")
    for title, link in toc:
        st.markdown(f"- [{title}]({link})", unsafe_allow_html=True)
    st.components.v1.html(
        f"<div style='border: 1px solid #ddd; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>{str(soup)}</div>",
        height=800,
        scrolling=True
    )

def display_notebook_as_sections(notebook_path):
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    html_exporter = HTMLExporter()
    html_exporter.exclude_input = False
    html_exporter.embed_images = True
    html_exporter.exclude_output = False
    html_exporter.exclude_code_cell = False
    html_exporter.exclude_anchor_links = False
    html_exporter.exclude_markdown = False
    html_exporter.exclude_raw = False
    html_data, _ = html_exporter.from_notebook_node(notebook_content)
    soup = BeautifulSoup(html_data, "html.parser")
    sections = [(header.text, header.find_next_sibling().decode() if header.find_next_sibling() else "") for header in soup.find_all(["h1", "h2", "h3"])]
    st.markdown("### Table of Contents")
    for i, (title, _) in enumerate(sections):
        if st.button(f"Go to {title}", key=f"toc_{i}"):
            st.session_state.selected_section = i
    if "selected_section" in st.session_state:
        st.markdown(f"### {sections[st.session_state.selected_section][0]}")
        st.components.v1.html(sections[st.session_state.selected_section][1], height=800, scrolling=True)

def execute_cells_with_keyword(notebook_path, keyword):
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)
    for cell in notebook_content.cells:
        if cell.cell_type == 'code' and cell.source.startswith(keyword):
            st.code(cell.source, language='python')
            exec(cell.source, globals())

def connect_to_jupyter_notebook():
    st.write("### Connect to Jupyter Notebook")
    
    # Select between local and remote Jupyter Notebook
    connection_type = st.radio("Connection Type", ["Local", "Remote"])

    if connection_type == "Local":
        local_port = st.number_input("Enter Jupyter Notebook Port", value=8888, step=1)
        jupyter_url = f"http://localhost:{local_port}"
        st.write(f"Connecting to local Jupyter instance at {jupyter_url}")
    else:
        remote_ip = st.text_input("Enter Remote Jupyter IP or Domain")
        remote_port = st.number_input("Enter Remote Jupyter Port", value=8888, step=1)
        jupyter_url = f"http://{remote_ip}:{remote_port}"
        st.write(f"Connecting to remote Jupyter instance at {jupyter_url}")

def display_model_performance_metrics(db, model_id):
    model = get_model(db, model_id)
    if not model:
        st.error("Model not found.")
        return

    st.write(f"## {model.model_name} - Performance Overview")

    # Display basic model details
    st.markdown("### General Information")
    col1, col2 = st.columns(2)
    col1.metric("Model Type", model.model_type)
    col1.metric("Business Line", model.business_line)
    col1.metric("Algorithm", model.algorithm)
    col2.metric("Risk Rating", model.risk_rating)
    col2.metric("Validation Rating", model.validation_rating)
    col2.metric("Status", model.model_status)

    # Historical Performance Trends
    st.markdown("### Historical Performance Trends")
    historical_data = get_historical_metrics(db, model_id)
    if historical_data:
        history_df = pd.DataFrame(historical_data)
        
        # Adjust chart with available columns
        fig = px.line(history_df, x="invocation_timestamp", y=["metrics"],
                      title="Historical Performance Metrics")
        st.plotly_chart(fig)
    else:
        st.info("No historical data available.")

    # Related Validations and Findings
    st.markdown("### Related Validations")
    validations = get_model_validations(db, model_id)
    if validations:
        validations_df = pd.DataFrame([{
            "Validation Date": v.validation_date,
            "Validator Name": v.validator_name,
            "Status": v.validation_status,
            "Validation Score": v.validation_score,
            "Comments": v.validation_comments
        } for v in validations])
        st.dataframe(validations_df)
    else:
        st.info("No validation data available.")

# def load_tests(db):
#     # st.write("### Tests Overview")
#     styled_header("Testing and Results")
#     notebook_path = select_jupyter_notebook()
#     upload_jupyter_notebook()
#     if "active_model_id" in st.session_state.keys():
#         model_id = int(st.session_state["active_model_id"])
#         # print(model_id)
#     with st.sidebar:
#         option = sac.menu(
#                     [
#                         sac.MenuItem(
#                             "Actions",
#                             icon="list-task",
#                             children=[
#                                 sac.MenuItem("Connect to Jupyter", icon="journal-code"),
#                                 sac.MenuItem("View Model Notebook", icon="book"),
#                                 sac.MenuItem("Segmented View", icon="columns-gap"),
#                                 sac.MenuItem("Execute Keyword Cells", icon="play-circle"),
#                                 sac.MenuItem("Display Performance Metrics", icon="bar-chart-line"),
#                                 sac.MenuItem("Excel Models", icon="file-earmark-excel"),
#                             ],
#                         ),
#                         sac.MenuItem(type="divider"),
#                         sac.MenuItem(
#                             "Results",
#                             icon="clipboard-data",
#                             children=[
#                                 sac.MenuItem("Capital Spread", icon="currency-exchange"),
#                                 sac.MenuItem("Expected Exposure (EE)", icon="graph-up-arrow"),
#                                 sac.MenuItem("Expected Potential Exposure (EPE)", icon="activity"),
#                                 sac.MenuItem("Expected Potential Future Exposure (EPFE)", icon="bar-chart"),
#                                 sac.MenuItem("Expected Shortfall (ES)", icon="percent"),
#                                 sac.MenuItem("Trade Summary", icon="file-spreadsheet"),
#                                 sac.MenuItem("Counter Party Summary", icon="people-fill"),
#                                 sac.MenuItem("Reference Data", icon="bookmarks-fill"),
#                             ],
#                         ),
                        
                        
#                     ],
#                     size="xs",
#                     variant="right-bar",
#                     indent=5,
#                     color="indigo",
#                     open_all=True,
#                 )

#     if option == "Connect to Jupyter":
#         connect_to_jupyter_notebook()
#     elif option == "View Model Notebook":
#         display_notebook_as_html(notebook_path)
#     elif option == "Segmented View":
#         display_notebook_as_sections(notebook_path)
#     elif option == "Execute Keyword Cells":
#         keyword = st.text_input("Enter keyword to execute cells", value="# Execute")
#         if keyword:
#             execute_cells_with_keyword(notebook_path, keyword)
#     elif option == "Display Performance Metrics":
#         display_model_performance_metrics(db, model_id)

def load_tests(db):
    styled_header("Testing and Results")
    

    if "active_model_id" in st.session_state.keys():
        model_id = int(st.session_state["active_model_id"])

    # Sidebar menu
    with st.sidebar:
        option = sac.menu(
            [
                sac.MenuItem(
                    "Actions",
                    icon="list-task",
                    children=[
                        sac.MenuItem("Connect to Jupyter", icon="journal-code"),
                        sac.MenuItem("View Model Notebook", icon="book"),
                        sac.MenuItem("Segmented View", icon="columns-gap"),
                        sac.MenuItem("Execute Keyword Cells", icon="play-circle"),
                        sac.MenuItem("Display Performance Metrics", icon="bar-chart-line"),
                        sac.MenuItem("Excel Models", icon="file-earmark-excel"),
                    ],
                ),
                sac.MenuItem(type="divider"),
                sac.MenuItem(
                    "Results",
                    icon="clipboard-data",
                    children=[
                        sac.MenuItem("Capital Spread", icon="currency-exchange"),
                        sac.MenuItem("Expected Exposure (EE)", icon="graph-up-arrow"),
                        sac.MenuItem("Expected Potential Exposure (EPE)", icon="activity"),
                        sac.MenuItem("Expected Potential Future Exposure (EPFE)", icon="bar-chart"),
                        sac.MenuItem("Expected Shortfall (ES)", icon="percent"),
                        sac.MenuItem("Trade Summary", icon="file-spreadsheet"),
                        sac.MenuItem("Counter Party Summary", icon="people-fill"),
                        sac.MenuItem("Reference Data", icon="bookmarks-fill"),
                    ],
                ),
            ],
            size="xs",
            variant="right-bar",
            indent=5,
            color="indigo",
            open_all=True,
        )

    # Empty element to display output
    output_element = st.empty()

    # Actions menu
    if option == "Connect to Jupyter":
        with st.expander("Notebook Management", expanded=True):
            notebook_column, upload_column = st.columns([1, 2])
            with notebook_column:
                notebook_path = select_jupyter_notebook()
            with upload_column:
                upload_jupyter_notebook()
                
        output_element.empty()
        with output_element.container():
            connect_to_jupyter_notebook()

    elif option == "View Model Notebook":
        with st.expander("Notebook Management", expanded=True):
            notebook_column, upload_column = st.columns([1, 2])
            with notebook_column:
                notebook_path = select_jupyter_notebook()
            with upload_column:
                upload_jupyter_notebook()
        
        # output_element.empty()
        with output_element.container():
            display_notebook_as_html(notebook_path)

    elif option == "Segmented View":
        output_element.empty()
        with output_element.container():
            display_notebook_as_sections(notebook_path)

    elif option == "Execute Keyword Cells":
        output_element.empty()
        with output_element.container():
            keyword = st.text_input("Enter keyword to execute cells", value="# Execute")
            if keyword:
                execute_cells_with_keyword(notebook_path, keyword)

    elif option == "Display Performance Metrics":
        output_element.empty()
        with output_element.container():
            display_model_performance_metrics(db, model_id)

    # Results menu
    elif option in [
        "Capital Spread",
        "Expected Exposure (EE)",
        "Expected Potential Exposure (EPE)",
        "Expected Potential Future Exposure (EPFE)",
        "Expected Shortfall (ES)",
        "Trade Summary",
        "Counter Party Summary",
        "Reference Data",
    ]:
        output_element.empty()
        with output_element.container():
            result_col1, result_col2 = st.columns([1,1])
            st.markdown("""
                <style>
                .small-latex {
                    font-size: 0.3em;  /* Adjust size as needed */
                }
                </style>
                """, unsafe_allow_html=True)

            with result_col1:
                # st.subheader(f"{option} - Analysis")
                # Add specific analysis for the selected result
                styled_header(f"{option} Basic CVA Capital Charge")

                # Explanation text
                st.markdown("""
                The **Basic CVA capital charge** is calculated as:
                """)

                # Equation using LaTeX
                st.latex(r"K = K_{spread} + K_{EE}")
                st.latex(r"K_{spread} : \text{Contribution of credit spread variability}")
                st.latex(r"K_{EE} : \text{Contribution of EE variability to CVA capital}")

                st.latex(r"The \( K_{EE} \) is further calculated as:")
                st.latex(r"K_{EE} = \beta K_{unhedged\_spread}")

                st.markdown("""
                Where:
                - \( \beta \): Parameter set to **0.5**.
                """)

            with result_col2:
                styled_header(f"{option} - Detailed Result")
                data = {
                    "Level": ["Counterparty credit spread", "Exposure risk", "Total"],
                    "Value": ["841,411.05", "420,705.52", "1,262,116.57"],
                }

                df = pd.DataFrame(data)
                st.table(df)
                # styled_header(f"{option} ")
                # Add detailed information for the selected result


