# Scripts Guide

This folder contains the operator workflow that starts after AWS infrastructure exists.

## Current Execution Order

From the repo root:

```bash
./infra/aws-proto/deploy-infra.sh --apply
./scripts/02-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
export POLARIS_DB_PASSWORD='polaris'
./scripts/03-deploy-platform.sh
./scripts/04-validate-platform.sh
```

From inside the `scripts/` folder:

```bash
./02-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
export POLARIS_DB_PASSWORD='polaris'
./03-deploy-platform.sh
./04-validate-platform.sh
```

## Before Running 03

These happen before `./03-deploy-platform.sh`:

1. Infra apply has completed successfully:
   `../infra/aws-proto/deploy-infra.sh --apply`

2. Your shell is connected to the EKS cluster:
   `./02-connect-cluster.sh`

3. Quick cluster sanity check passes:

```bash
kubectl get nodes
kubectl get pods -n kube-system
```

4. Helm is installed:

```bash
helm version
```

If Helm is missing in CloudShell, install it with:

```bash
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

5. Polaris database password is exported:

```bash
export POLARIS_DB_PASSWORD='polaris'
```

For this prototype, `polaris` is acceptable. It is not production-grade.

## What Each Script Does

- `00-aws-access-smoke-test.sh`
  Creates a small AWS-only smoke environment to verify IAM and infra permissions before the main Terraform path.

- `02-connect-cluster.sh`
  Updates kubeconfig so `kubectl` and Helm point to the EKS cluster named in `infra/aws-proto/terraform.tfvars`.

- `03-deploy-platform.sh`
  Installs namespaces, service accounts, Strimzi, Spark Operator, Airflow, Polaris, and Prometheus/Grafana.

- `04-validate-platform.sh`
  Checks nodes plus the deployed platform components and prints namespace pod state when something is not healthy.

- `05-deploy-workloads.sh`
  Placeholder for future sample batch and streaming workloads.

- `06-cleanup-platform.sh`
  Removes platform services from Kubernetes without deleting AWS infrastructure.

AWS destroy remains separate:

- `../infra/aws-proto/destroy-infra.sh`

## Notes For 03

- `03-deploy-platform.sh` tries to resolve the Spark, Airflow, and Polaris IAM role ARNs from Terraform outputs automatically.
- If Terraform state is not available locally, export those role ARNs manually before running `03`.
- `03` requires a working `kubectl` connection and Helm.
- `03` ends with:
  - `Platform services deployment completed.`
  - `Next steps: run 04-validate-platform.sh, then bootstrap Polaris if enabled.`

## AWS Prototype Storage Note

The current Airflow values explicitly set:

```text
storageClass: gp2
```

for the Airflow PostgreSQL PVC in AWS.

This is intentional for the current EKS prototype so Airflow persistence does not depend on a default StorageClass.

## Infra State Backup

After a successful `../infra/aws-proto/deploy-infra.sh --apply`, the infra script creates timestamped backups of:

- `terraform.tfstate`
- `terraform.tfstate.backup` if present

under:

```text
infra/aws-proto/bkp/
```

Example backup names:

```text
infra/aws-proto/bkp/terraform.tfstate.2026-04-28-184500
infra/aws-proto/bkp/terraform.tfstate.backup.2026-04-28-184500
```

This is a local safety net in case the primary state file is lost later.

If you ever need to restore state manually, copy the chosen backup back to:

```text
infra/aws-proto/terraform.tfstate
```

This is not a substitute for a remote Terraform backend.

## Quick Verification

After `04-validate-platform.sh` passes, these are the most important checks.

Kubernetes:

```bash
kubectl get pods -n platform-system
kubectl get pods -n monitoring
kubectl get pods -n airflow
kubectl get pods -n polaris
kubectl get pvc -A
```

AWS Console:

- EKS cluster `dc-platform-bss-eks-proto` is `Active`
- EKS add-ons are healthy, especially `aws-ebs-csi-driver`
- both managed node groups exist
- EC2 worker nodes are running
- S3 bucket `dc-platform-bss-proto-lakehouse-7901580-us-east-1` exists
- shared IAM roles exist

## Cleanup And Destroy Safety

Before running cleanup or destroy, verify that `kubectl` is connected to the intended cluster:

```bash
kubectl config current-context
kubectl get nodes
```

Important:

- `06-cleanup-platform.sh` deletes resources from the currently connected Kubernetes cluster
- it does not independently verify the cluster name before deleting
- always run `02-connect-cluster.sh` first, or manually confirm the active kubeconfig context

To remove everything created by this workflow:

1. Remove platform services from the currently connected cluster:

```bash
./06-cleanup-platform.sh
```

2. Destroy Terraform-managed AWS infrastructure:

```bash
../infra/aws-proto/destroy-infra.sh
```

What is not deleted automatically:

- shared IAM roles
- external S3 bucket `dc-platform-bss-proto-lakehouse-7901580-us-east-1`

## Troubleshooting Note

`02-connect-cluster.sh` is normally used after infra apply and before platform install.

You can also run `02-connect-cluster.sh` from another shell during infra troubleshooting if you need to inspect nodes or `kube-system` pods while Terraform is still running.
