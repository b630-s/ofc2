#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../../.." && pwd)"
WORKLOAD_ROOT="${REPO_ROOT}/reference-workloads/orders-reference"
# shellcheck source=../../scripts/lib/load-platform-config.sh
source "${WORKLOAD_ROOT}/scripts/lib/load-platform-config.sh"
load_reference_workload_config "${REPO_ROOT}" "${WORKLOAD_ROOT}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

render_check() {
  local file_path="$1"
  envsubst < "${file_path}" >/dev/null
  printf '[render-check] ok: %s\n' "${file_path#${REPO_ROOT}/}"
}

preflight() {
  require_cmd envsubst

  if [[ -z "${REFERENCE_SPARK_IMAGE:-}" ]]; then
    REFERENCE_SPARK_IMAGE="example.invalid/dc-platform-reference-spark:test"
  fi

  : "${KAFKA_NAMESPACE:=kafka}"
  : "${KAFKA_TOPIC:=orders_raw}"
  : "${KAFKA_DLQ_TOPIC:=orders_dlq}"
  : "${KAFKA_CLUSTER_NAME:=reference-kafka}"
  : "${KAFKA_BOOTSTRAP_SERVICE:=reference-kafka-kafka-bootstrap}"
  : "${KAFKA_BOOTSTRAP_PORT:=9092}"
  : "${KAFKA_BOOTSTRAP_SERVER:=${KAFKA_BOOTSTRAP_SERVICE}.${KAFKA_NAMESPACE}.svc.cluster.local:${KAFKA_BOOTSTRAP_PORT}}"
  : "${SPARK_NAMESPACE:=spark}"
  : "${SPARK_SERVICE_ACCOUNT:=spark-sa}"
  : "${SPARK_OBJECT_STORE_SECRET_NAME:=reference-object-store-hadoop-config}"
  : "${SPARK_NODE_SELECTOR_GROUP:=workload}"
  : "${POLARIS_NAMESPACE:=polaris}"
  : "${POLARIS_SERVICE:=polaris}"
  : "${POLARIS_CATALOG_URI:=http://${POLARIS_SERVICE}.${POLARIS_NAMESPACE}.svc.cluster.local:8181/api/catalog}"
  : "${POLARIS_SECRET_NAME:=reference-polaris-spark-credentials}"
  : "${REFERENCE_CATALOG:=polaris}"
  : "${LAKEHOUSE_BUCKET:=example-lakehouse-bucket}"
  : "${REFERENCE_SPARK_BASE_PATH:=s3a://${LAKEHOUSE_BUCKET}/reference}"
  : "${SPARK_EVENT_LOG_DIR:=${REFERENCE_SPARK_BASE_PATH}/spark-event-logs}"
  : "${ORDERS_RAW_PATH:=${REFERENCE_SPARK_BASE_PATH}/raw/orders/}"
  : "${ORDERS_CURATED_PATH:=${REFERENCE_SPARK_BASE_PATH}/curated/orders/}"
  : "${ORDERS_ICEBERG_TABLE:=${REFERENCE_CATALOG}.bronze.orders_raw}"
}

main() {
  preflight

  render_check "${WORKLOAD_ROOT}/kafka/topics.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-kafka-to-raw.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-raw-to-curated.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-curated-to-iceberg.yaml"
  render_check "${WORKLOAD_ROOT}/spark/manifests/spark-app-sparkpi.yaml"
}

main "$@"
