#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
WORKLOAD_ROOT="${REPO_ROOT}/reference-workloads/orders-reference"
# shellcheck source=lib/load-platform-config.sh
source "${WORKLOAD_ROOT}/scripts/lib/load-platform-config.sh"
load_reference_workload_config "${REPO_ROOT}" "${WORKLOAD_ROOT}"

SPARK_NAMESPACE="${SPARK_NAMESPACE:-spark}"
SPARK_OBJECT_STORE_SECRET_NAME="${SPARK_OBJECT_STORE_SECRET_NAME:-reference-object-store-hadoop-config}"
OBJECT_STORE_ENDPOINT="${OBJECT_STORE_ENDPOINT:-}"
OBJECT_STORE_PATH_STYLE_ACCESS="${OBJECT_STORE_PATH_STYLE_ACCESS:-false}"
OBJECT_STORE_SSL_ENABLED="${OBJECT_STORE_SSL_ENABLED:-true}"
OBJECT_STORE_REGION="${OBJECT_STORE_REGION:-}"
OBJECT_STORE_ACCESS_KEY_ID="${OBJECT_STORE_ACCESS_KEY_ID:-}"
OBJECT_STORE_SECRET_ACCESS_KEY="${OBJECT_STORE_SECRET_ACCESS_KEY:-}"
OBJECT_STORE_SESSION_TOKEN="${OBJECT_STORE_SESSION_TOKEN:-}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[orders-object-store-secret] %s\n' "$*"
}

preflight() {
  require_cmd kubectl

  if [[ -z "${OBJECT_STORE_ACCESS_KEY_ID}" || -z "${OBJECT_STORE_SECRET_ACCESS_KEY}" ]]; then
    cat >&2 <<EOF
Set OBJECT_STORE_ACCESS_KEY_ID and OBJECT_STORE_SECRET_ACCESS_KEY before running this script.
Optional overrides:
  OBJECT_STORE_ENDPOINT
  OBJECT_STORE_PATH_STYLE_ACCESS
  OBJECT_STORE_SSL_ENABLED
  OBJECT_STORE_REGION
  OBJECT_STORE_SESSION_TOKEN
EOF
    exit 1
  fi
}

render_core_site() {
  local credentials_provider

  if [[ -n "${OBJECT_STORE_SESSION_TOKEN}" ]]; then
    credentials_provider="org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider"
  else
    credentials_provider="org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
  fi

  cat <<EOF
<?xml version="1.0"?>
<configuration>
  <property>
    <name>fs.s3a.impl</name>
    <value>org.apache.hadoop.fs.s3a.S3AFileSystem</value>
  </property>
  <property>
    <name>fs.s3a.aws.credentials.provider</name>
    <value>${credentials_provider}</value>
  </property>
  <property>
    <name>fs.s3a.access.key</name>
    <value>${OBJECT_STORE_ACCESS_KEY_ID}</value>
  </property>
  <property>
    <name>fs.s3a.secret.key</name>
    <value>${OBJECT_STORE_SECRET_ACCESS_KEY}</value>
  </property>
  <property>
    <name>fs.s3a.path.style.access</name>
    <value>${OBJECT_STORE_PATH_STYLE_ACCESS}</value>
  </property>
  <property>
    <name>fs.s3a.connection.ssl.enabled</name>
    <value>${OBJECT_STORE_SSL_ENABLED}</value>
  </property>
EOF

  if [[ -n "${OBJECT_STORE_ENDPOINT}" ]]; then
    cat <<EOF
  <property>
    <name>fs.s3a.endpoint</name>
    <value>${OBJECT_STORE_ENDPOINT}</value>
  </property>
EOF
  fi

  if [[ -n "${OBJECT_STORE_REGION}" ]]; then
    cat <<EOF
  <property>
    <name>fs.s3a.endpoint.region</name>
    <value>${OBJECT_STORE_REGION}</value>
  </property>
EOF
  fi

  if [[ -n "${OBJECT_STORE_SESSION_TOKEN}" ]]; then
    cat <<EOF
  <property>
    <name>fs.s3a.session.token</name>
    <value>${OBJECT_STORE_SESSION_TOKEN}</value>
  </property>
EOF
  fi

  cat <<'EOF'
</configuration>
EOF
}

main() {
  local rendered_file

  preflight
  rendered_file="$(mktemp)"
  render_core_site > "${rendered_file}"

  kubectl create secret generic "${SPARK_OBJECT_STORE_SECRET_NAME}" \
    --namespace "${SPARK_NAMESPACE}" \
    --from-file=core-site.xml="${rendered_file}" \
    --dry-run=client -o yaml | kubectl apply -f -

  rm -f "${rendered_file}"
  log "Created or updated secret ${SPARK_NAMESPACE}/${SPARK_OBJECT_STORE_SECRET_NAME}"
}

main "$@"
