#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
WORKLOAD_ROOT="${REPO_ROOT}/reference-workloads/orders-reference"
# shellcheck source=lib/load-platform-config.sh
source "${WORKLOAD_ROOT}/scripts/lib/load-platform-config.sh"
load_reference_workload_config "${REPO_ROOT}" "${WORKLOAD_ROOT}"

SPARK_NAMESPACE="${SPARK_NAMESPACE:-spark}"
SPARK_SERVICE_ACCOUNT="${SPARK_SERVICE_ACCOUNT:-spark-sa}"
SPARK_OBJECT_STORE_SECRET_NAME="${SPARK_OBJECT_STORE_SECRET_NAME:-reference-object-store-hadoop-config}"
SPARK_NODE_SELECTOR_GROUP="${SPARK_NODE_SELECTOR_GROUP:-workload}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"
KAFKA_BOOTSTRAP_SERVER="${KAFKA_BOOTSTRAP_SERVER:-reference-kafka-kafka-bootstrap.kafka.svc.cluster.local:9092}"
KAFKA_TOPIC="${KAFKA_TOPIC:-orders_raw}"
REFERENCE_CATALOG="${REFERENCE_CATALOG:-polaris}"
REFERENCE_SPARK_BASE_PATH="${REFERENCE_SPARK_BASE_PATH:-}"
LAKEHOUSE_BUCKET="${LAKEHOUSE_BUCKET:-}"
if [[ -z "${REFERENCE_SPARK_BASE_PATH}" && -n "${LAKEHOUSE_BUCKET}" ]]; then
  REFERENCE_SPARK_BASE_PATH="s3a://${LAKEHOUSE_BUCKET}/reference"
fi
ORDERS_RAW_PATH="${ORDERS_RAW_PATH:-${REFERENCE_SPARK_BASE_PATH}/raw/orders/}"
SPARK_EVENT_LOG_DIR="${SPARK_EVENT_LOG_DIR:-${REFERENCE_SPARK_BASE_PATH}/spark-event-logs}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

preflight() {
  require_cmd kubectl
  require_cmd envsubst

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  if [[ -z "${REFERENCE_SPARK_IMAGE:-}" ]]; then
    echo "Set REFERENCE_SPARK_IMAGE before running this script." >&2
    exit 1
  fi

  if [[ -z "${REFERENCE_SPARK_BASE_PATH}" ]]; then
    echo "Set REFERENCE_SPARK_BASE_PATH or LAKEHOUSE_BUCKET before running this script." >&2
    exit 1
  fi

  if ! kubectl get secret "${SPARK_OBJECT_STORE_SECRET_NAME}" -n "${SPARK_NAMESPACE}" >/dev/null 2>&1; then
    echo "Missing secret ${SPARK_OBJECT_STORE_SECRET_NAME} in namespace ${SPARK_NAMESPACE}." >&2
    exit 1
  fi
}

main() {
  local rendered_manifest

  preflight
  rendered_manifest="$(mktemp)"
  envsubst < "${REPO_ROOT}/reference-workloads/orders-reference/spark/manifests/spark-app-kafka-to-raw.yaml" > "${rendered_manifest}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    reference_strip_node_scheduling_blocks "${rendered_manifest}"
  fi
  kubectl apply -f "${rendered_manifest}"
  rm -f "${rendered_manifest}"
}

main "$@"
