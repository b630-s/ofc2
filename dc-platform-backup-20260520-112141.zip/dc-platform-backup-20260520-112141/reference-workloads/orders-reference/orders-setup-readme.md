# Orders Reference Workload

This folder contains the orders reference workload assets, including:

- workload-owned config defaults
- Kafka topic manifests
- Spark job code
- SparkApplication manifests
- Airflow DAG bundle assets
- workload-level smoke checks
- use-case-specific workload scripts
- the repo-owned Spark image Dockerfile

The goal is to move away from ConfigMap-mounted job code over time and toward a more production-style model where:

- the Spark runtime image is pinned and owned by this repo
- reference jobs are baked into the image
- Airflow submits Spark jobs that all use the same image
- Polaris and Iceberg configuration remain part of the SparkApplication runtime config

## Image Build Pattern

The image build intentionally stays simple for the current iteration:

- base image: `docker.io/library/spark:3.5.3-python3`
- baked-in job code copied from `spark/jobs/` into `/opt/dc-platform/jobs`
- build-time resolution of generic Spark Kafka and Iceberg runtime dependencies into `/opt/spark/jars`

That keeps the base image more portable while leaving cloud-specific runtime dependencies in the SparkApplication specs.

## Spark Job Code

- `spark/jobs/01_read_kafka_to_raw.py`
- `spark/jobs/02_transform_raw_to_curated.py`
- `spark/jobs/03_write_curated_to_iceberg.py`

These numbered jobs are the current canonical staged orders flow.

The orders workload targets:

- Kafka topic: `orders_raw`
- raw landing path under `reference/raw/`
- curated parquet path under `reference/curated/`
- Iceberg target table in the Polaris `reference` catalog

## Polaris For Orders

The shared Polaris bootstrap remains in `platform/`, but the orders-specific table model belongs to this use case.

Shared Polaris bootstrap creates:

- catalog `polaris`
- namespaces `bronze` and `silver`
- Spark principal and role wiring needed for runtime access

The orders-specific tables are intended to be created by Spark jobs during first successful write, not by the shared Polaris bootstrap script.

Current orders table ownership:

- `polaris.bronze.orders_raw`
  - current default Iceberg target in the staged image-baked path
  - written by `spark/jobs/03_write_curated_to_iceberg.py` unless overridden

Current ownership split:

- `platform/scripts/50-bootstrap-polaris-reference.sh`
  - shared catalog, namespace, and access bootstrap

- `reference-workloads/orders-reference/`
  - use-case-specific Spark jobs and manifests
  - use-case-specific Bronze and Silver table meaning

So the platform layer creates the shared Polaris structure, and the orders workload creates its own tables through Spark.

## Execution Sequence

Shared prerequisites live under `platform/`:

1. `platform/scripts/aws/10-connect-cluster.sh`
2. `platform/scripts/20-deploy-platform.sh`
3. `platform/scripts/30-deploy-kafka.sh`
4. `platform/scripts/40-bootstrap-polaris-admin.sh`
5. `platform/scripts/50-bootstrap-polaris-reference.sh`

Then use the orders-reference entrypoints in this folder:

1. `./reference-workloads/orders-reference/scripts/05-deploy-orders-kafka-topics.sh`
2. `./reference-workloads/orders-reference/scripts/10-load-orders-events-to-kafka.sh`
3. `./reference-workloads/orders-reference/scripts/15-check-orders-events-in-kafka.sh`
4. `./reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh`
5. `./reference-workloads/orders-reference/scripts/25-deploy-orders-kafka-to-raw.sh`
6. `./reference-workloads/orders-reference/scripts/30-deploy-orders-raw-to-curated.sh`
7. `./reference-workloads/orders-reference/scripts/35-deploy-orders-curated-to-iceberg.sh`

Current intent:

- `scripts/05-deploy-orders-kafka-topics.sh` applies the workload-owned Kafka topics for the orders path
- `scripts/10-load-orders-events-to-kafka.sh` loads sample order events into Kafka topic `orders_raw`
- `scripts/15-check-orders-events-in-kafka.sh` verifies the events are present in Kafka
- `scripts/20-create-orders-polaris-runtime-secret.sh` stores the orders runtime Polaris principal credentials in the `spark` namespace
- `scripts/25-deploy-orders-kafka-to-raw.sh` submits the Kafka-to-raw SparkApplication
- `scripts/30-deploy-orders-raw-to-curated.sh` submits the raw-to-curated SparkApplication
- `scripts/35-deploy-orders-curated-to-iceberg.sh` submits the curated-to-Iceberg SparkApplication

These scripts assume shared Kafka and shared Polaris reference bootstrap are already complete.
They first look for the shared non-secret platform handoff file in `platform/config/platform-config.env`, then apply workload-local defaults and optional local overrides from `reference-workloads/orders-reference/config/`.

## Generated Platform Config

The shared non-secret handoff file is now generated incrementally by the real deploy/bootstrap stages at:

- `platform/config/platform-config.env`

Current producers:

- `infra/aws/deploy-infra.sh`
- `platform/scripts/20-deploy-platform.sh`
- `platform/scripts/30-deploy-kafka.sh`
- `platform/scripts/50-bootstrap-polaris-reference.sh`

Secrets remain separate. Optional workload-local files can still live under:

- `platform/config/platform-secrets.env`
- `reference-workloads/orders-reference/config/platform-secrets.env`

Optional local developer overrides can go in:

- `reference-workloads/orders-reference/config/workload.local.env`

The workload scripts load `platform/config/platform-config.env`, optional `platform/config/platform-secrets.env`, `reference-workloads/orders-reference/config/workload-defaults.env`, optional workload-local overrides, and optional local secret files so the workload-specific topic names, paths, and Spark defaults remain visible in one place.

## Workload-Owned Kafka Assets

The orders workload now treats its Kafka topics as first-class manifests under:

- `reference-workloads/orders-reference/kafka/topics.yaml`

Apply them with:

```bash
./reference-workloads/orders-reference/scripts/05-deploy-orders-kafka-topics.sh
```

That keeps the topic contract versioned with the workload instead of leaving it implicit in scripts.

To load the sample order events into Kafka:

```bash
INSTALL_KAFKA_TEST_CLIENT=true ./platform/scripts/30-deploy-kafka.sh
./reference-workloads/orders-reference/scripts/10-load-orders-events-to-kafka.sh
```

The loader uses:

- local file `reference-workloads/orders-reference/sample-data/sample-events.json`
- Kafka topic `orders_raw`
- client pod `kafka-test-client` in namespace `kafka`

To verify the events are present in Kafka before running Spark:

```bash
./reference-workloads/orders-reference/scripts/15-check-orders-events-in-kafka.sh
```

Optional override:

```bash
MAX_MESSAGES=5 ./reference-workloads/orders-reference/scripts/15-check-orders-events-in-kafka.sh
```

## Shared Prerequisite Notes

### Shared Kafka Verification

```bash
kubectl get kafka -n kafka
kubectl get kafkanodepool -n kafka
kubectl get kafkatopic -n kafka
kubectl get pods -n kafka -o wide
```

### Kafka / Strimzi Troubleshooting

```bash
kubectl logs -n platform-system deployment/strimzi-cluster-operator --tail=300
kubectl describe kafka reference-kafka -n kafka
kubectl get kafkanodepool -n kafka -o yaml
kubectl get events -n kafka --sort-by=.lastTimestamp
kubectl get pvc -n kafka
```

### Install Polaris Admin Tool

```bash
sudo apt update
sudo apt install -y openjdk-21-jre-headless jq curl tar
java --version
jq --version
```

Alternate package commands for Amazon Linux 2023 on EC2:

```bash
sudo dnf install -y java-21-amazon-corretto-headless jq curl tar
java --version
jq --version
```

```bash
mkdir -p ~/tools
cd ~/tools
curl -L https://downloads.apache.org/incubator/polaris/1.3.0-incubating/polaris-bin-1.3.0-incubating.tgz | tar xz
mkdir -p ~/.local/bin
cat > ~/.local/bin/polaris <<'EOF'
#!/usr/bin/env bash
exec "$HOME/tools/polaris-bin-1.3.0-incubating/bin/admin" "$@"
EOF
chmod +x ~/.local/bin/polaris
export PATH="$HOME/.local/bin:$HOME/tools/polaris-bin-1.3.0-incubating/bin:$PATH"
polaris --help
```

The local `polaris` wrapper is only for the admin bootstrap step.
`platform/scripts/50-bootstrap-polaris-reference.sh` now uses the Polaris REST APIs through `kubectl`, `curl`, and `jq` instead of a separate local catalog CLI.

### Polaris Bootstrap Inputs

```bash
export POLARIS_ADMIN_CLIENT_ID='polaris-root'
export POLARIS_ADMIN_CLIENT_SECRET='change-this-secret'
export POLARIS_ROLE_ARN='<polaris-irsa-role-arn>'
```

Get the role ARN from Terraform output:

```bash
cd infra/aws
terraform output -json workload_identities | jq -r '.polaris.role_arn'
```

Bootstrap the Polaris root/admin credentials first:

```bash
./platform/scripts/40-bootstrap-polaris-admin.sh
```

Run the shared bootstrap with:

```bash
./platform/scripts/50-bootstrap-polaris-reference.sh
```

The shared bootstrap prints the reference Spark principal credentials when it creates them. Store those in the runtime Kubernetes secret used by the orders flow:

```bash
export POLARIS_USER_CLIENT_ID='<reference-spark-client-id>'
export POLARIS_USER_CLIENT_SECRET='<reference-spark-client-secret>'
./reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh
```

If `reference-workloads/orders-reference/config/platform-secrets.env` already contains those values, the runtime secret script can use them directly without re-exporting them in your shell. A safe template lives at `reference-workloads/orders-reference/config/platform-secrets.env.example`.

## Build

From repo root:

```bash
docker build -t dc-platform-reference-spark:0.1 reference-workloads/orders-reference
```

The Docker build resolves and bakes in these Spark-side dependencies:

- Kafka source support for Spark 3.5
- Iceberg Spark runtime for Spark 3.5

The SparkApplication manifests now follow two separate storage patterns:

- direct object-store writes and Spark event logs use Hadoop S3A with a Kubernetes-managed object-store secret
- Iceberg writes go through Polaris with vended credentials, while still using the Iceberg AWS bundle and Hadoop S3A connector for the current S3-compatible backend

If the image URI is known when the platform handoff is generated, `REFERENCE_SPARK_IMAGE` can be included in `platform/config/platform-config.env`. Otherwise export it explicitly or place it in `reference-workloads/orders-reference/config/workload.local.env`.

Tag and push later to your registry:

```bash
docker tag dc-platform-reference-spark:0.1 <your-registry>/dc-platform-reference-spark:0.1
docker push <your-registry>/dc-platform-reference-spark:0.1
```

## Intended Spark Usage

The intended staged Spark pattern is:

1. Kafka to raw parquet
2. raw parquet to curated parquet
3. curated parquet to Iceberg

The image-baked jobs use the same image and different `mainApplicationFile` values:

- `local:///opt/dc-platform/jobs/01_read_kafka_to_raw.py`
- `local:///opt/dc-platform/jobs/02_transform_raw_to_curated.py`
- `local:///opt/dc-platform/jobs/03_write_curated_to_iceberg.py`

## SparkApplication Manifests

The orders reference currently includes:

- `reference-workloads/orders-reference/spark/manifests/spark-app-kafka-to-raw.yaml`
- `reference-workloads/orders-reference/spark/manifests/spark-app-raw-to-curated.yaml`
- `reference-workloads/orders-reference/spark/manifests/spark-app-curated-to-iceberg.yaml`
- `reference-workloads/orders-reference/spark/manifests/spark-app-sparkpi.yaml`

The staged path uses the repo-owned Spark image and the baked-in jobs:

- `01_read_kafka_to_raw.py`
- `02_transform_raw_to_curated.py`
- `03_write_curated_to_iceberg.py`

There is also a SparkPi smoke-test manifest under `reference-workloads/orders-reference/spark/manifests/`. That is the cleanest first validation of:

- Spark Operator submission
- cluster-mode Spark execution
- image pull behavior
- driver and executor scheduling

Apply SparkPi like this:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
envsubst < reference-workloads/orders-reference/spark/manifests/spark-app-sparkpi.yaml | kubectl apply -f -
```

Apply the staged orders manifests like this:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
export POLARIS_USER_CLIENT_ID='<reference-spark-client-id>'
export POLARIS_USER_CLIENT_SECRET='<reference-spark-client-secret>'
./reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh
./reference-workloads/orders-reference/scripts/25-deploy-orders-kafka-to-raw.sh
./reference-workloads/orders-reference/scripts/30-deploy-orders-raw-to-curated.sh
./reference-workloads/orders-reference/scripts/35-deploy-orders-curated-to-iceberg.sh
```

Current hardening additions in these manifests:

- workload-owned path and table config comes from env files rather than hardcoded values
- restart policy retries are enabled
- driver and executor security contexts are explicitly set
- Spark resource knobs are exposed through workload defaults instead of only inline manifest literals

## Airflow Orchestration

Airflow is the intended orchestrator for the staged orders path.

Use:

- `reference-workloads/orders-reference/airflow/bundle/orders_reference.py`

The DAG runs the three SparkApplication steps in order:

1. Kafka to raw parquet
2. raw parquet to curated parquet
3. curated parquet to Iceberg through Polaris

For Airflow, set the image as an Airflow Variable:

```text
reference_spark_image=<your-registry>/dc-platform-reference-spark:0.1
```

The bundle DAG loads the same manifest files used by the shell scripts, replaces the image field from the Airflow Variable at runtime, and adds a run-specific SparkApplication name suffix so repeated DAG runs do not collide.

The Airflow bundle folder is now the canonical DAG home for this workload.

Before running the DAG, make sure:

- the shared platform and Kafka prerequisites are complete
- the runtime secret `reference-polaris-spark-credentials` exists in namespace `spark`
- the Airflow deployment includes `reference-workloads/orders-reference/airflow/bundle/orders_reference.py` and the neighboring `spark/manifests` directory

Useful checks:

```bash
kubectl get sparkapplications -n spark
kubectl describe sparkapplication reference-orders-kafka-to-raw -n spark
kubectl get pods -n spark -l sparkoperator.k8s.io/app-name=reference-orders-kafka-to-raw
```

## Layout

Current layout:

```text
orders-reference/
  Dockerfile
  orders-setup-readme.md
  config/
  kafka/
  scripts/
  monitoring/
  tests/
  spark/
    manifests/
    jobs/
  airflow/
    bundle/
```

## Notes

- The image build files now live at the use-case root instead of a separate `spark-image/` folder.
- `config/workload-defaults.env` is the workload-owned home for topic names, data paths, table names, and Spark runtime defaults.
- `spark/jobs/` is the single source of truth for Spark job code in this reference workload.
- `scripts/` still provide the easiest operator UX, but the workload contract now lives more explicitly in `config/`, `kafka/`, `spark/`, and `airflow/bundle/`.
- The base image keeps generic Spark dependencies baked in, while the manifests continue to carry AWS-specific runtime packages for the current deployment target.
- The Docker build still needs network access to resolve Maven artifacts during image creation.
