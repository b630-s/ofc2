from datetime import datetime, timedelta
import os
from pathlib import Path
import shlex

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import (
    SparkKubernetesOperator,
)
import yaml


BUNDLE_DIR = Path(__file__).resolve().parent
WORKLOAD_ROOT = BUNDLE_DIR.parents[1]
REPO_ROOT = BUNDLE_DIR.parents[3]
MANIFESTS_DIR = WORKLOAD_ROOT / "spark" / "manifests"
WORKLOAD_CONFIG_DIR = WORKLOAD_ROOT / "config"
PLATFORM_CONFIG_DIR = REPO_ROOT / "platform" / "config"
AIRFLOW_IMAGE_TEMPLATE = "{{ var.value.reference_spark_image }}"


def load_env_defaults() -> None:
    for env_file in (
        PLATFORM_CONFIG_DIR / "platform-config.env",
        PLATFORM_CONFIG_DIR / "example.platform-config.env",
        PLATFORM_CONFIG_DIR / "platform-secrets.env",
        PLATFORM_CONFIG_DIR / "example.platform-secrets.env",
        WORKLOAD_CONFIG_DIR / "platform-config.env",
        WORKLOAD_CONFIG_DIR / "platform-secrets.env",
        WORKLOAD_CONFIG_DIR / "workload-defaults.env",
        WORKLOAD_CONFIG_DIR / "workload.local.env",
    ):
        if not env_file.exists():
            continue

        for raw_line in env_file.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            parsed = shlex.split(f"export {line}")
            if len(parsed) != 2 or "=" not in parsed[1]:
                continue
            key, value = parsed[1].split("=", 1)
            os.environ.setdefault(key, value)


def load_spark_application(filename: str) -> dict:
    manifest_path = MANIFESTS_DIR / filename
    manifest_text = os.path.expandvars(manifest_path.read_text(encoding="utf-8"))
    spec = yaml.safe_load(manifest_text)

    spec["spec"]["image"] = AIRFLOW_IMAGE_TEMPLATE
    spec["metadata"]["name"] = f"{spec['metadata']['name']}-{{{{ ts_nodash }}}}"

    return spec


load_env_defaults()


with DAG(
    dag_id=os.environ.get("ORDERS_AIRFLOW_DAG_ID", "orders_reference_staged"),
    start_date=datetime(2026, 4, 1),
    catchup=False,
    dagrun_timeout=timedelta(minutes=30),
    schedule=None,
    tags=["reference", "spark", "orders"],
) as dag:
    spark_namespace = os.environ.get("SPARK_NAMESPACE", "spark")

    run_kafka_to_raw = SparkKubernetesOperator(
        task_id="orders_kafka_to_raw",
        namespace=spark_namespace,
        template_spec=load_spark_application("spark-app-kafka-to-raw.yaml"),
        get_logs=True,
    )

    run_raw_to_curated = SparkKubernetesOperator(
        task_id="orders_raw_to_curated",
        namespace=spark_namespace,
        template_spec=load_spark_application("spark-app-raw-to-curated.yaml"),
        get_logs=True,
    )

    run_curated_to_iceberg = SparkKubernetesOperator(
        task_id="orders_curated_to_iceberg",
        namespace=spark_namespace,
        template_spec=load_spark_application("spark-app-curated-to-iceberg.yaml"),
        get_logs=True,
    )

    run_kafka_to_raw >> run_raw_to_curated >> run_curated_to_iceberg
