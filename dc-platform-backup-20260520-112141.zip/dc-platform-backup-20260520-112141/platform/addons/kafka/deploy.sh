#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"

KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"
INSTALL_KAFKA_TEST_CLIENT="${INSTALL_KAFKA_TEST_CLIENT:-false}"
KAFKA_READY_TIMEOUT="${KAFKA_READY_TIMEOUT:-15m}"
KAFKA_TOPIC_READY_TIMEOUT="${KAFKA_TOPIC_READY_TIMEOUT:-5m}"
KAFKA_TEST_CLIENT_READY_TIMEOUT="${KAFKA_TEST_CLIENT_READY_TIMEOUT:-5m}"
KAFKA_STORAGE_CLASS="${KAFKA_STORAGE_CLASS:-${PLATFORM_STORAGE_CLASS:-gp2}}"
PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-kafka] %s\n' "$*"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${KAFKA_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

wait_for_kafka_topic() {
  local topic_name="$1"

  log "Waiting for Kafka topic ${topic_name} readiness"
  kubectl wait "kafkatopic/${topic_name}" \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${KAFKA_TOPIC_READY_TIMEOUT}"
}

wait_for_pod_ready() {
  local pod_name="$1"

  log "Waiting for pod ${pod_name} readiness"
  kubectl wait "pod/${pod_name}" \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${KAFKA_TEST_CLIENT_READY_TIMEOUT}"
}

preflight() {
  require_cmd kubectl

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  if ! kubectl get deployment strimzi-cluster-operator -n "${PLATFORM_NAMESPACE}" >/dev/null 2>&1; then
    echo "Strimzi operator is not installed in ${PLATFORM_NAMESPACE}. Run platform/scripts/20-deploy-platform.sh first." >&2
    exit 1
  fi
}

main() {
  preflight

  local kafka_controller_manifest kafka_broker_manifest
  kafka_controller_manifest="$(render_storage_class_template "${SCRIPT_DIR}/kafka-nodepool-controller.yaml")"
  kafka_broker_manifest="$(render_storage_class_template "${SCRIPT_DIR}/kafka-nodepool-broker.yaml")"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${kafka_controller_manifest}"
    platform_config_strip_node_scheduling_blocks "${kafka_broker_manifest}"
  fi

  log "Using Kafka storage class ${KAFKA_STORAGE_CLASS}"
  log "Deploying shared Kafka node pools and cluster into ${KAFKA_NAMESPACE}"
  kubectl apply -f "${kafka_controller_manifest}"
  kubectl apply -f "${kafka_broker_manifest}"
  kubectl apply -f "${SCRIPT_DIR}/kafka-cluster.yaml"

  log "Waiting for Kafka cluster readiness"
  kubectl wait kafka/reference-kafka \
    --namespace "${KAFKA_NAMESPACE}" \
    --for=condition=Ready \
    --timeout="${KAFKA_READY_TIMEOUT}"

  log "Creating shared Kafka topics"
  kubectl apply -f "${SCRIPT_DIR}/kafka-topic-orders.yaml"
  kubectl apply -f "${SCRIPT_DIR}/kafka-topic-orders-dlq.yaml"
  wait_for_kafka_topic orders-raw
  wait_for_kafka_topic orders-dlq

  if [[ "${INSTALL_KAFKA_TEST_CLIENT}" == "true" ]]; then
    local kafka_test_client_manifest
    kafka_test_client_manifest="$(mktemp)"
    cp "${SCRIPT_DIR}/kafka-test-client.yaml" "${kafka_test_client_manifest}"
    if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
      platform_config_strip_node_scheduling_blocks "${kafka_test_client_manifest}"
    fi
    log "Deploying optional Kafka test client pod"
    kubectl apply -f "${kafka_test_client_manifest}"
    wait_for_pod_ready kafka-test-client
    rm -f "${kafka_test_client_manifest}"
  else
    log "Skipping Kafka test client pod; set INSTALL_KAFKA_TEST_CLIENT=true to install it"
  fi

  echo "Shared Kafka baseline deployed."
  echo "Bootstrap server: reference-kafka-kafka-bootstrap.${KAFKA_NAMESPACE}.svc.cluster.local:9092"
  echo "Topics: orders_raw, orders_dlq"

  rm -f "${kafka_controller_manifest}" "${kafka_broker_manifest}"
}

main "$@"
