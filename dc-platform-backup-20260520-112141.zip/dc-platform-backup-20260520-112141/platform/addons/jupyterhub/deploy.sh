#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
# shellcheck source=../../scripts/lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"

JUPYTER_NAMESPACE="${JUPYTER_NAMESPACE:-jupyter}"
JUPYTERHUB_CHART_VERSION="${JUPYTERHUB_CHART_VERSION:-4.0.0}"
JUPYTER_NOTEBOOK_SERVICE_ACCOUNT="${JUPYTER_NOTEBOOK_SERVICE_ACCOUNT:-jupyter-sa}"
JUPYTERHUB_NOTEBOOK_IMAGE_NAME="${JUPYTERHUB_NOTEBOOK_IMAGE_NAME:-quay.io/jupyter/pyspark-notebook}"
JUPYTERHUB_NOTEBOOK_IMAGE_TAG="${JUPYTERHUB_NOTEBOOK_IMAGE_TAG:-2025-03-14}"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/aws}"
CLOUD_REGION="${CLOUD_REGION:-${AWS_REGION:-}}"
POLARIS_CATALOG_URI="${POLARIS_CATALOG_URI:-http://polaris.polaris.svc.cluster.local:8181/api/catalog}"
REFERENCE_CATALOG="${REFERENCE_CATALOG:-polaris}"
EXAMPLES_DIR="${SCRIPT_DIR}/examples"
WORKLOAD_IDENTITY_ANNOTATION_KEY="${WORKLOAD_IDENTITY_ANNOTATION_KEY:-eks.amazonaws.com/role-arn}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[addon-jupyterhub] %s\n' "$*"
}

resolve_role_arn() {
  if [[ -n "${JUPYTER_S3_ROLE_ARN:-}" ]]; then
    printf '%s\n' "${JUPYTER_S3_ROLE_ARN}"
    return 0
  fi

  if command -v jq >/dev/null 2>&1 && [[ -f "${WORKLOAD_IDENTITIES_FILE}" ]]; then
    jq -r '.jupyter.identity_binding // .jupyter.role_arn // empty' "${WORKLOAD_IDENTITIES_FILE}" 2>/dev/null
    return 0
  fi

  if ! command -v terraform >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -json workload_identities 2>/dev/null \
    | jq -r '.jupyter.identity_binding // .jupyter.role_arn // empty'
}

main() {
  require_cmd kubectl
  require_cmd helm
  require_cmd envsubst

  if [[ -z "${JUPYTERHUB_SHARED_PASSWORD:-}" ]]; then
    echo "Set JUPYTERHUB_SHARED_PASSWORD before enabling JupyterHub." >&2
    exit 1
  fi

  log "Applying JupyterHub namespace and service account"
  kubectl apply -f "${SCRIPT_DIR}/namespace.yaml"
  kubectl apply -f "${SCRIPT_DIR}/service-account.yaml"

  kubectl create configmap jupyter-sample-notebooks \
    --namespace "${JUPYTER_NAMESPACE}" \
    --from-file="${EXAMPLES_DIR}" \
    --dry-run=client -o yaml | kubectl apply -f -

  local secret_manifest
  secret_manifest="$(mktemp)"
  {
    printf 'jupyterhub-shared-password=%s\n' "${JUPYTERHUB_SHARED_PASSWORD}"
    if [[ -n "${POLARIS_USER_CLIENT_ID:-}" ]]; then
      printf 'polaris-user-client-id=%s\n' "${POLARIS_USER_CLIENT_ID}"
    fi
    if [[ -n "${POLARIS_USER_CLIENT_SECRET:-}" ]]; then
      printf 'polaris-user-client-secret=%s\n' "${POLARIS_USER_CLIENT_SECRET}"
    fi
  } > "${secret_manifest}"

  kubectl create secret generic jupyterhub-runtime-secrets \
    --namespace "${JUPYTER_NAMESPACE}" \
    --from-env-file="${secret_manifest}" \
    --dry-run=client -o yaml | kubectl apply -f -

  rm -f "${secret_manifest}"

  local role_arn=""
  role_arn="$(resolve_role_arn || true)"
  if [[ -n "${role_arn}" ]]; then
    log "Annotating ${JUPYTER_NAMESPACE}/${JUPYTER_NOTEBOOK_SERVICE_ACCOUNT} with IAM role ${role_arn}"
    kubectl annotate serviceaccount "${JUPYTER_NOTEBOOK_SERVICE_ACCOUNT}" \
      --namespace "${JUPYTER_NAMESPACE}" \
      "${WORKLOAD_IDENTITY_ANNOTATION_KEY}=${role_arn}" \
      --overwrite
  else
    log "No Jupyter role ARN resolved; continuing without IRSA annotation"
  fi

  local rendered_values
  rendered_values="$(mktemp)"
  envsubst < "${SCRIPT_DIR}/values.yaml" > "${rendered_values}"
  if [[ "${DISABLE_NODE_SELECTORS}" == "true" ]]; then
    platform_config_strip_node_scheduling_blocks "${rendered_values}"
  fi

  log "Installing JupyterHub into ${JUPYTER_NAMESPACE}"
  helm upgrade --install jupyterhub jupyterhub/jupyterhub \
    --namespace "${JUPYTER_NAMESPACE}" \
    --create-namespace \
    --version "${JUPYTERHUB_CHART_VERSION}" \
    --values "${rendered_values}" \
    --wait \
    --timeout 15m

  rm -f "${rendered_values}"

  cat <<EOF
JupyterHub installed.

Access it locally with:
  kubectl port-forward -n ${JUPYTER_NAMESPACE} svc/proxy-public 8080:80

Then open:
  http://127.0.0.1:8080
EOF
}

main "$@"
