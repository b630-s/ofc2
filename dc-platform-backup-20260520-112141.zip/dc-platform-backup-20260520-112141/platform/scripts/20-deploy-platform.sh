#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
# shellcheck source=lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"
TF_DIR="${TF_DIR:-${REPO_ROOT}/infra/aws}"
CORE_DIR="${REPO_ROOT}/platform/core"
SPARK_OPERATOR_DIR="${REPO_ROOT}/platform/addons/spark-operator"
AIRFLOW_DIR="${REPO_ROOT}/platform/addons/airflow"
POLARIS_DIR="${REPO_ROOT}/platform/addons/polaris"
STRIMZI_DIR="${REPO_ROOT}/platform/addons/strimzi"
MONITORING_DIR="${REPO_ROOT}/platform/addons/monitoring"
INGRESS_DIR="${REPO_ROOT}/platform/addons/ingress-nginx"
UI_INGRESS_DIR="${REPO_ROOT}/platform/addons/ui-ingress"
METRICS_SERVER_DIR="${REPO_ROOT}/platform/addons/metrics-server"
JUPYTERHUB_DIR="${REPO_ROOT}/platform/addons/jupyterhub"
TENANTS_DIR="${REPO_ROOT}/platform/tenants"

PLATFORM_NAMESPACE="${PLATFORM_NAMESPACE:-platform-system}"
MONITORING_NAMESPACE="${MONITORING_NAMESPACE:-monitoring}"
INGRESS_NAMESPACE="${INGRESS_NAMESPACE:-ingress-nginx}"
AIRFLOW_CHART_VERSION="${AIRFLOW_CHART_VERSION:-1.20.0}"
SPARK_OPERATOR_CHART_VERSION="${SPARK_OPERATOR_CHART_VERSION:-2.4.0}"
STRIMZI_CHART_VERSION="${STRIMZI_CHART_VERSION:-0.51.0}"
INGRESS_NGINX_CHART_VERSION="${INGRESS_NGINX_CHART_VERSION:-4.14.1}"
KUBE_PROMETHEUS_STACK_CHART_VERSION="${KUBE_PROMETHEUS_STACK_CHART_VERSION:-80.13.3}"
POLARIS_CHART_VERSION="${POLARIS_CHART_VERSION:-1.3.0-incubating}"
METRICS_SERVER_CHART_VERSION="${METRICS_SERVER_CHART_VERSION:-3.13.0}"
JUPYTERHUB_CHART_VERSION="${JUPYTERHUB_CHART_VERSION:-4.0.0}"

ENABLE_AIRFLOW="${ENABLE_AIRFLOW:-true}"
ENABLE_SPARK="${ENABLE_SPARK:-true}"
ENABLE_STRIMZI="${ENABLE_STRIMZI:-true}"
ENABLE_INGRESS="${ENABLE_INGRESS:-false}"
ENABLE_MONITORING="${ENABLE_MONITORING:-true}"
ENABLE_POLARIS="${ENABLE_POLARIS:-true}"
ENABLE_METRICS_SERVER="${ENABLE_METRICS_SERVER:-true}"
ENABLE_JUPYTERHUB="${ENABLE_JUPYTERHUB:-true}"
DISABLE_NODE_SELECTORS="${DISABLE_NODE_SELECTORS:-false}"
PLATFORM_STORAGE_CLASS="${PLATFORM_STORAGE_CLASS:-}"
POLARIS_SECRET_NAME="${POLARIS_SECRET_NAME:-reference-polaris-spark-credentials}"
UI_INGRESS_BASE_DOMAIN="${UI_INGRESS_BASE_DOMAIN:-platform.local}"
WORKLOAD_IDENTITY_ANNOTATION_KEY="${WORKLOAD_IDENTITY_ANNOTATION_KEY:-eks.amazonaws.com/role-arn}"
WORKLOAD_IDENTITIES_JSON=""

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[platform] %s\n' "$*"
}

apply_manifest_if_present() {
  local manifest_path="$1"

  if [[ ! -s "${manifest_path}" ]]; then
    return
  fi

  if ! grep -Eq '^(apiVersion|kind):' "${manifest_path}"; then
    return
  fi

  kubectl apply -f "${manifest_path}"
}

render_storage_class_template() {
  local source_file="$1"
  local rendered_file

  rendered_file="$(mktemp)"
  sed "s|__STORAGE_CLASS__|${PLATFORM_STORAGE_CLASS}|g" "${source_file}" > "${rendered_file}"
  printf '%s\n' "${rendered_file}"
}

requires_platform_storage_class() {
  [[ "${ENABLE_AIRFLOW}" == "true" || "${ENABLE_MONITORING}" == "true" || "${ENABLE_POLARIS}" == "true" ]]
}

load_workload_identities_output() {
  if ! command -v terraform >/dev/null 2>&1; then
    return 1
  fi

  if [[ ! -d "${TF_DIR}" ]]; then
    return 1
  fi

  terraform -chdir="${TF_DIR}" output -json workload_identities 2>/dev/null
}

build_workload_identities_from_legacy_env() {
  jq -n \
    --arg polaris_role_arn "${POLARIS_S3_ROLE_ARN:-}" \
    '{
      polaris: {
        namespace: "polaris",
        service_account: "polaris-sa",
        identity_type: "irsa",
        identity_binding: $polaris_role_arn
      }
    }
    | with_entries(select(.value.identity_binding != ""))'
}

ensure_workload_identity_handoff() {
  local identities_json=""
  local profile_workload_identities_file=""

  if [[ -f "${WORKLOAD_IDENTITIES_FILE}" ]]; then
    identities_json="$(jq -c '.' "${WORKLOAD_IDENTITIES_FILE}" 2>/dev/null || true)"
    if [[ -n "${identities_json}" && "${identities_json}" != "null" && "${identities_json}" != "{}" ]]; then
      WORKLOAD_IDENTITIES_JSON="${identities_json}"
      log "Resolved workload identity handoff from platform/config/workload-identities.json"
      return
    fi
  fi

  if [[ -n "${PLATFORM_PROFILE:-}" ]]; then
    profile_workload_identities_file="${PLATFORM_CONFIG_PROFILES_DIR}/${PLATFORM_PROFILE}/workload-identities.json"
  fi

  if [[ -n "${profile_workload_identities_file}" && -f "${profile_workload_identities_file}" ]]; then
    identities_json="$(jq -c '.' "${profile_workload_identities_file}" 2>/dev/null || true)"
    if [[ -n "${identities_json}" && "${identities_json}" != "null" ]]; then
      WORKLOAD_IDENTITIES_JSON="${identities_json}"
      log "Resolved workload identity handoff from ${profile_workload_identities_file}"
      return
    fi
  fi

  identities_json="$(load_workload_identities_output || true)"
  if [[ -n "${identities_json}" && "${identities_json}" != "null" ]]; then
    WORKLOAD_IDENTITIES_JSON="${identities_json}"
    log "Resolved workload identity handoff from Terraform output workload_identities"
    return
  fi

  identities_json="$(build_workload_identities_from_legacy_env)"
  if [[ -n "${identities_json}" && "${identities_json}" != "{}" ]]; then
    WORKLOAD_IDENTITIES_JSON="${identities_json}"
    log "Using workload identity handoff from legacy per-service role ARN environment variables"
    return
  fi

  cat >&2 <<EOF
Unable to resolve workload identity handoff.
Provide Terraform state with output workload_identities in ${TF_DIR}, or export the legacy role ARN environment variable:
  POLARIS_S3_ROLE_ARN
EOF
  exit 1
}

annotate_workload_service_accounts() {
  local services=()
  local service namespace service_account identity_binding

  if kubectl get serviceaccount airflow-sa --namespace airflow >/dev/null 2>&1; then
    log "Ensuring airflow/airflow-sa does not carry a cloud workload identity annotation"
    kubectl annotate serviceaccount airflow-sa \
      --namespace airflow \
      "${WORKLOAD_IDENTITY_ANNOTATION_KEY}-" >/dev/null 2>&1 || true
  fi

  mapfile -t services < <(echo "${WORKLOAD_IDENTITIES_JSON}" | jq -r 'keys[]')

  for service in "${services[@]}"; do
    namespace="$(echo "${WORKLOAD_IDENTITIES_JSON}" | jq -r --arg service "${service}" '.[$service].namespace')"
    service_account="$(echo "${WORKLOAD_IDENTITIES_JSON}" | jq -r --arg service "${service}" '.[$service].service_account')"
    identity_binding="$(echo "${WORKLOAD_IDENTITIES_JSON}" | jq -r --arg service "${service}" '.[$service].identity_binding // .[$service].role_arn')"

    if [[ "${service}" == spark* || "${service}" == team_a || "${service}" == airflow ]]; then
      log "Ensuring ${namespace}/${service_account} does not carry a cloud workload identity annotation"
      kubectl annotate serviceaccount "${service_account}" \
        --namespace "${namespace}" \
        "${WORKLOAD_IDENTITY_ANNOTATION_KEY}-" >/dev/null 2>&1 || true
      continue
    fi

    if [[ -z "${identity_binding}" || "${identity_binding}" == "null" ]]; then
      log "Skipping ${service} service account annotation because no identity binding was provided"
      continue
    fi

    if ! kubectl get serviceaccount "${service_account}" --namespace "${namespace}" >/dev/null 2>&1; then
      log "Skipping ${namespace}/${service_account}; service account does not exist in the cluster yet"
      continue
    fi

    log "Annotating ${namespace}/${service_account} with workload identity binding ${identity_binding}"
    kubectl annotate serviceaccount "${service_account}" \
      --namespace "${namespace}" \
      "${WORKLOAD_IDENTITY_ANNOTATION_KEY}=${identity_binding}" \
      --overwrite
  done
}

preflight() {
  require_cmd kubectl
  require_cmd helm
  require_cmd jq

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  ensure_workload_identity_handoff

  if requires_platform_storage_class && [[ -z "${PLATFORM_STORAGE_CLASS}" ]]; then
    echo "Set PLATFORM_STORAGE_CLASS for your cluster (e.g. gp2/gp3 on EKS, standard on kind, local-path on k3s)." >&2
    exit 1
  fi

  if [[ "${ENABLE_POLARIS}" == "true" ]]; then
    if [[ -z "${POLARIS_DB_PASSWORD:-}" ]]; then
      echo "POLARIS_DB_PASSWORD is required when ENABLE_POLARIS=true." >&2
      exit 1
    fi
  fi

  if [[ "${ENABLE_JUPYTERHUB}" == "true" ]]; then
    if [[ -z "${JUPYTERHUB_SHARED_PASSWORD:-}" ]]; then
      echo "JUPYTERHUB_SHARED_PASSWORD is required when ENABLE_JUPYTERHUB=true." >&2
      exit 1
    fi
  fi
}

add_helm_repos() {
  if [[ "${ENABLE_AIRFLOW}" == "true" ]]; then
    helm repo add apache-airflow https://airflow.apache.org --force-update
  fi

  if [[ "${ENABLE_SPARK}" == "true" ]]; then
    helm repo add spark-operator https://kubeflow.github.io/spark-operator --force-update
  fi

  if [[ "${ENABLE_STRIMZI}" == "true" ]]; then
    helm repo add strimzi https://strimzi.io/charts/ --force-update
  fi

  if [[ "${ENABLE_POLARIS}" == "true" ]]; then
    helm repo add polaris https://downloads.apache.org/incubator/polaris/helm-chart --force-update
  fi

  if [[ "${ENABLE_INGRESS}" == "true" ]]; then
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx --force-update
  fi

  if [[ "${ENABLE_MONITORING}" == "true" ]]; then
    helm repo add prometheus-community https://prometheus-community.github.io/helm-charts --force-update
  fi

  if [[ "${ENABLE_METRICS_SERVER}" == "true" ]]; then
    helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/ --force-update
  fi

  if [[ "${ENABLE_JUPYTERHUB}" == "true" ]]; then
    helm repo add jupyterhub https://hub.jupyter.org/helm-chart/ --force-update
  fi

  helm repo update
}

install_foundations() {
  local tenant_dir deploy_script

  log "Applying platform namespaces and shared service accounts"
  apply_manifest_if_present "${CORE_DIR}/namespaces.yaml"
  apply_manifest_if_present "${AIRFLOW_DIR}/namespace.yaml"
  apply_manifest_if_present "${AIRFLOW_DIR}/service-account.yaml"
  apply_manifest_if_present "${POLARIS_DIR}/namespace.yaml"
  apply_manifest_if_present "${POLARIS_DIR}/service-account.yaml"
  apply_manifest_if_present "${STRIMZI_DIR}/namespace.yaml"
  apply_manifest_if_present "${MONITORING_DIR}/namespace.yaml"
  apply_manifest_if_present "${INGRESS_DIR}/namespace.yaml"

  if [[ -d "${TENANTS_DIR}" ]]; then
    for tenant_dir in "${TENANTS_DIR}"/*; do
      [[ -d "${tenant_dir}" ]] || continue
      deploy_script="${tenant_dir}/deploy.sh"
      if [[ -x "${deploy_script}" ]]; then
        log "Deploying tenant bundle $(basename "${tenant_dir}")"
        "${deploy_script}"
      fi
    done
  fi

  annotate_workload_service_accounts
}

install_strimzi() {
  if [[ "${ENABLE_STRIMZI}" != "true" ]]; then
    echo "Skipping Strimzi. Set ENABLE_STRIMZI=true to install it."
    return
  fi

  "${STRIMZI_DIR}/deploy.sh"
}

install_spark_operator() {
  if [[ "${ENABLE_SPARK}" != "true" ]]; then
    echo "Skipping Spark Operator. Set ENABLE_SPARK=true to install it."
    return
  fi

  "${SPARK_OPERATOR_DIR}/deploy.sh"
}

install_airflow() {
  if [[ "${ENABLE_AIRFLOW}" != "true" ]]; then
    echo "Skipping Airflow. Set ENABLE_AIRFLOW=true to install it."
    return
  fi

  "${AIRFLOW_DIR}/deploy.sh"
}

install_ingress() {
  if [[ "${ENABLE_INGRESS}" != "true" ]]; then
    echo "Skipping ingress-nginx. Set ENABLE_INGRESS=true to install it."
    return
  fi

  "${INGRESS_DIR}/deploy.sh"
}

install_monitoring() {
  if [[ "${ENABLE_MONITORING}" != "true" ]]; then
    echo "Skipping monitoring stack. Set ENABLE_MONITORING=true to install it."
    return
  fi

  "${MONITORING_DIR}/deploy.sh"
}

install_metrics_server() {
  if [[ "${ENABLE_METRICS_SERVER}" != "true" ]]; then
    echo "Skipping metrics-server. Set ENABLE_METRICS_SERVER=true to install it."
    return
  fi

  "${METRICS_SERVER_DIR}/deploy.sh"
}

install_polaris() {
  if [[ "${ENABLE_POLARIS}" != "true" ]]; then
    echo "Skipping Polaris installation. Polaris is required by default; set ENABLE_POLARIS=false only for troubleshooting."
    return
  fi

  "${POLARIS_DIR}/deploy.sh"
}

install_jupyterhub() {
  if [[ "${ENABLE_JUPYTERHUB}" != "true" ]]; then
    echo "Skipping JupyterHub. Set ENABLE_JUPYTERHUB=true to install it."
    return
  fi

  "${JUPYTERHUB_DIR}/deploy.sh"
}

install_ui_ingress() {
  if [[ "${ENABLE_INGRESS}" != "true" ]]; then
    return
  fi

  "${UI_INGRESS_DIR}/deploy.sh"
}

write_platform_config_platform_section() {
  platform_config_write_section "platform" "platform/scripts/20-deploy-platform.sh" <<EOF
$(platform_config_write_env_var KAFKA_NAMESPACE "kafka")
$(platform_config_write_env_var SPARK_NAMESPACE "spark")
$(platform_config_write_env_var SPARK_SERVICE_ACCOUNT "spark-sa")
$(platform_config_write_env_var SPARK_NODE_SELECTOR_GROUP "workload")
$(platform_config_write_env_var POLARIS_NAMESPACE "polaris")
$(platform_config_write_env_var POLARIS_SERVICE "polaris")
$(platform_config_write_env_var POLARIS_CATALOG_URI "http://polaris.polaris.svc.cluster.local:8181/api/catalog")
$(platform_config_write_env_var POLARIS_SECRET_NAME "${POLARIS_SECRET_NAME}")
$(platform_config_write_env_var JUPYTER_NAMESPACE "jupyter")
$(platform_config_write_env_var JUPYTER_SERVICE "proxy-public")
$(platform_config_write_env_var JUPYTER_BASE_URL "http://proxy-public.jupyter.svc.cluster.local")
$(platform_config_write_env_var JUPYTER_NOTEBOOK_SERVICE_ACCOUNT "jupyter-sa")
$(platform_config_write_env_var UI_INGRESS_BASE_DOMAIN "${UI_INGRESS_BASE_DOMAIN}")
$(platform_config_write_env_var GRAFANA_INGRESS_HOST "${GRAFANA_INGRESS_HOST:-grafana.${UI_INGRESS_BASE_DOMAIN}}")
$(platform_config_write_env_var PROMETHEUS_INGRESS_HOST "${PROMETHEUS_INGRESS_HOST:-prometheus.${UI_INGRESS_BASE_DOMAIN}}")
$(platform_config_write_env_var GRAFANA_UI_SERVICE "${GRAFANA_UI_SERVICE:-kube-prometheus-stack-grafana}")
$(platform_config_write_env_var PROMETHEUS_UI_SERVICE "${PROMETHEUS_UI_SERVICE:-kube-prometheus-stack-prometheus}")
$(platform_config_write_env_var AIRFLOW_INGRESS_HOST "${AIRFLOW_INGRESS_HOST:-airflow.${UI_INGRESS_BASE_DOMAIN}}")
$(platform_config_write_env_var AIRFLOW_UI_SERVICE "${AIRFLOW_UI_SERVICE:-airflow-api-server}")
$(platform_config_write_env_var POLARIS_INGRESS_HOST "${POLARIS_INGRESS_HOST:-polaris.${UI_INGRESS_BASE_DOMAIN}}")
$(platform_config_write_env_var JUPYTER_INGRESS_HOST "${JUPYTER_INGRESS_HOST:-jupyter.${UI_INGRESS_BASE_DOMAIN}}")
EOF
}

main() {
  export DISABLE_NODE_SELECTORS
  preflight
  log "Using platform storage class ${PLATFORM_STORAGE_CLASS}"
  add_helm_repos
  install_foundations
  install_strimzi
  install_spark_operator
  install_airflow
  install_ingress
  install_monitoring
  install_metrics_server
  install_polaris
  install_jupyterhub
  install_ui_ingress
  write_platform_config_platform_section

  echo "Platform services deployment completed."
  echo "Next steps: run platform/scripts/60-validate-platform.sh, then bootstrap Polaris if enabled."
}

main "$@"
