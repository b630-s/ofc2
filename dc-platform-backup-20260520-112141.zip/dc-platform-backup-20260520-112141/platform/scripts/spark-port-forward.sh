#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
# shellcheck source=lib/platform-config.sh
source "${REPO_ROOT}/platform/scripts/lib/platform-config.sh"
platform_config_load_runtime_env "${REPO_ROOT}"

SPARK_NAMESPACE="${SPARK_NAMESPACE:-spark}"
SPARK_UI_LOCAL_PORT="${SPARK_UI_LOCAL_PORT:-4040}"
SPARK_UI_REMOTE_PORT="${SPARK_UI_REMOTE_PORT:-4040}"
SPARK_APP_NAME="${SPARK_APP_NAME:-${1:-}}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing required command: $1" >&2
    exit 1
  fi
}

log() {
  printf '[spark-port-forward] %s\n' "$*"
}

usage() {
  cat <<EOF
Usage:
  ./platform/scripts/spark-port-forward.sh <spark-application-name>

Examples:
  ./platform/scripts/spark-port-forward.sh reference-orders-kafka-to-raw
  SPARK_NAMESPACE=team-a ./platform/scripts/spark-port-forward.sh my-spark-job

This forwards the Spark driver UI to:
  http://127.0.0.1:${SPARK_UI_LOCAL_PORT}
EOF
}

list_candidates() {
  echo "Available SparkApplications in namespace ${SPARK_NAMESPACE}:"
  kubectl get sparkapplications -n "${SPARK_NAMESPACE}" 2>/dev/null || true
  echo
  echo "Driver pods in namespace ${SPARK_NAMESPACE}:"
  kubectl get pods -n "${SPARK_NAMESPACE}" -l spark-role=driver 2>/dev/null || true
}

resolve_driver_pod() {
  local app_name="$1"
  local pod_name=""

  if kubectl get sparkapplication "${app_name}" -n "${SPARK_NAMESPACE}" >/dev/null 2>&1; then
    pod_name="$(kubectl get sparkapplication "${app_name}" -n "${SPARK_NAMESPACE}" -o jsonpath='{.status.driverInfo.podName}' 2>/dev/null || true)"
    if [[ -n "${pod_name}" ]]; then
      printf '%s\n' "${pod_name}"
      return 0
    fi
  fi

  pod_name="$(kubectl get pods -n "${SPARK_NAMESPACE}" \
    -l "sparkoperator.k8s.io/app-name=${app_name},spark-role=driver" \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)"
  if [[ -n "${pod_name}" ]]; then
    printf '%s\n' "${pod_name}"
    return 0
  fi

  if kubectl get pod "${app_name}" -n "${SPARK_NAMESPACE}" >/dev/null 2>&1; then
    printf '%s\n' "${app_name}"
    return 0
  fi

  return 1
}

main() {
  require_cmd kubectl

  if ! kubectl cluster-info >/dev/null 2>&1; then
    echo "kubectl is not connected to a cluster. Connect kubectl to a cluster before running this script." >&2
    exit 1
  fi

  if [[ -z "${SPARK_APP_NAME}" ]]; then
    usage
    echo
    list_candidates
    exit 1
  fi

  local driver_pod
  if ! driver_pod="$(resolve_driver_pod "${SPARK_APP_NAME}")"; then
    echo "Could not find a Spark driver pod for ${SPARK_APP_NAME} in namespace ${SPARK_NAMESPACE}." >&2
    echo
    list_candidates
    exit 1
  fi

  if ! kubectl get pod "${driver_pod}" -n "${SPARK_NAMESPACE}" >/dev/null 2>&1; then
    echo "Resolved driver pod ${driver_pod} was not found in namespace ${SPARK_NAMESPACE}." >&2
    exit 1
  fi

  log "Forwarding Spark UI for ${SPARK_APP_NAME} via pod/${driver_pod}"
  log "Open http://127.0.0.1:${SPARK_UI_LOCAL_PORT}"

  kubectl port-forward -n "${SPARK_NAMESPACE}" "pod/${driver_pod}" "${SPARK_UI_LOCAL_PORT}:${SPARK_UI_REMOTE_PORT}"
}

main "$@"
