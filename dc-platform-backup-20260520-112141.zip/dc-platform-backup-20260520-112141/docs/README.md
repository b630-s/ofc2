# Docs Guide

This folder is intentionally minimal.

The core docs are:

- `architecture.md`
  Source of truth for platform principles, portability boundaries, AWS prototype constraints, and target operating model.
- `to-do-list.md`
  Current action-oriented backlog and next implementation priorities.

This file is the lightweight index and operating guide around those two.

## Current Reading Order

Use these in order:

1. `docs/architecture.md`
   Read this first for the portability rules, platform boundaries, and what is and is not allowed to become cloud-specific.
2. `SETUP_README.md`
   Use this for the actual operator runbook and current scripted deployment flow.
3. `docs/to-do-list.md`
   Use this for what we are actively trying to fix, harden, or implement next.

## Current Deployment Flow

The working deployment order for the AWS prototype is:

1. Provision infrastructure with `infra/aws/deploy-infra.sh`.
2. Connect `kubectl` to the cluster with `platform/scripts/aws/10-connect-cluster.sh`.
3. Deploy the platform baseline with `platform/scripts/20-deploy-platform.sh`.
4. Validate the platform with `platform/scripts/60-validate-platform.sh`.
5. Deploy or validate workload steps such as Kafka, Polaris bootstrap, and Spark reference flows.
6. Clean up Kubernetes services with `platform/scripts/90-cleanup-platform.sh`.
7. Destroy AWS infrastructure with `infra/aws/destroy-infra.sh` when needed.

The exact commands and environment variables live in `SETUP_README.md`.

## Current Shared Environment Notes

For the current EKS prototype:

- cluster access is AWS-specific at the infra boundary
- workload behavior should still follow the architecture rules in `architecture.md`
- reference workloads currently assume namespaces such as `spark`, `airflow`, `polaris`, and `kafka`
- runtime identity in the AWS prototype currently uses IRSA wiring, but workload logic should still be written against Kubernetes identity and object storage contracts

## Team Access Notes

For the shared AWS prototype, the practical short version is:

- developers need AWS permission to describe the EKS cluster and update kubeconfig
- developers also need Kubernetes authorization inside the cluster
- for a small prototype team, broad EKS cluster access may be acceptable temporarily
- this is an operating shortcut, not the long-term production access model

Keep any detailed access procedure close to the actual AWS scripts or operator runbooks rather than as a standalone durable architecture doc.

## Rules

- If `architecture.md` and another doc disagree, `architecture.md` wins.
- If a doc becomes mostly historical, duplicated, or a redirect, prefer deleting it.
- Keep durable principles in `architecture.md`, active work in `to-do-list.md`, and procedural runbooks in `SETUP_README.md`.
