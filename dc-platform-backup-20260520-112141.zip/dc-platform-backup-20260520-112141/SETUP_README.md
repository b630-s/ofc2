# Unified Setup Guide

This is the primary operator setup runbook for the current AWS EKS prototype.

Use this document first when you need to:

- prepare or review the AWS infrastructure inputs
- deploy the platform layer
- deploy and validate Kafka
- install Polaris CLI prerequisites
- bootstrap the shared Polaris catalog for the reference workload
- run the first orders reference workload steps

The older docs under `infra/aws/` and `platform/scripts/` still contain useful context, but this file is the main end-to-end setup guide.

## Profile Overlays

Platform config now supports optional provider profile overlays under:

- `platform/config/profiles/common.env`
- `platform/config/profiles/aws.env`
- `platform/config/profiles/gcp.env`
- `platform/config/profiles/azure.env`
- `platform/config/profiles/onprem.env`

Set `PLATFORM_PROFILE` in your shell or in `platform/config/platform-config.env` if
you want one of those overlays applied. The loader keeps the existing "first set
wins" behavior, so explicit values in `platform-config.env` still override profile
defaults, and profile defaults only fill gaps.

For workload identity examples, use:

- `platform/config/profiles/examples/aws.workload-identities.json`

The active per-deployment override file remains:

- `platform/config/workload-identities.json`

## Parameters To Review First

Before first deploy, review only the environment-shaping values in `infra/aws/terraform.tfvars`.

Check:

- naming: `project_name`, `environment`, `eks_cluster_name`
- region and network: `aws_region`, `vpc_cidr`, `availability_zones`, subnet CIDRs
- cluster sizing: `eks_cluster_version`, node instance types, node min/max/desired sizes, disk sizes
- shared storage: `lakehouse_bucket_name`
- existing IAM role names: cluster, node, and `ebs_csi_role_name`
- workload identity inventory: `workload_identities`

`workload_identities` matters most going forward:

- each entry defines `namespace`, `service_account`, and `role_name`
- current entries cover the remaining platform-side cloud-identity bindings such as `polaris` and optional `jupyter`
- Spark runtime tenants such as `spark` and `team_a` should use Kubernetes identity plus Polaris-vended credentials or Kubernetes-managed object-store secrets instead of role bindings
- new workload namespaces or future services such as Flink should be added there rather than as separate per-service Terraform variables

### Core Environment Variables Used During Setup

These are the main shell parameters to check before each stage. Most can stay at defaults.

`POLARIS_DB_PASSWORD`
Required: yes for platform deploy
Default: none
Used by: `platform/scripts/20-deploy-platform.sh`
Notes: required when Polaris is enabled.

`PLATFORM_STORAGE_CLASS`
Required: yes when deploying storage-backed platform services
Default: none
Used by: `platform/scripts/20-deploy-platform.sh`
Notes: controls Airflow PostgreSQL, Prometheus, and Polaris PostgreSQL persistence class. Set it explicitly for your cluster, for example `gp3` on EKS, `standard` on kind, or `local-path` on k3s.

`KAFKA_STORAGE_CLASS`
Required: no
Default: profile-specific value (AWS profile: `gp3`), otherwise `PLATFORM_STORAGE_CLASS`, then the Kafka script fallback
Used by: `platform/scripts/30-deploy-kafka.sh`
Notes: overrides Kafka node pool PVC storage class if needed.

`POLARIS_S3_ROLE_ARN`
Required: sometimes
Default: auto from Terraform output `workload_identities`, with legacy environment-variable fallback
Used by: `platform/scripts/20-deploy-platform.sh`
Notes: same note as above.

`INSTALL_KAFKA_TEST_CLIENT`
Required: no
Default: `false`
Used by: `platform/scripts/30-deploy-kafka.sh`
Notes: set to `true` if you want the helper pod for produce/consume testing.

`REFERENCE_SPARK_IMAGE`
Required: yes for Spark workload deploys
Default: none
Used by: orders workload scripts and Airflow DAG
Notes: registry image for the repo-owned Spark runtime.

`POLARIS_ADMIN_CLIENT_ID`
Required: yes for Polaris bootstrap
Default: none
Used by: `platform/scripts/40-bootstrap-polaris-admin.sh` and `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: admin credentials used only for bootstrap.

`POLARIS_ADMIN_CLIENT_SECRET`
Required: yes for Polaris bootstrap
Default: none
Used by: `platform/scripts/40-bootstrap-polaris-admin.sh` and `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: admin credentials used only for bootstrap.

`POLARIS_ROLE_ARN`
Required: yes for Polaris bootstrap
Default: auto from `POLARIS_S3_ROLE_ARN`, otherwise Terraform output `workload_identities.polaris.role_arn`
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: role ARN Polaris should vend for catalog storage access. In this prototype it should match the Polaris IRSA role used during platform deploy.

`POLARIS_STORAGE_TYPE`
Required: no
Default: `S3`
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: selects the Polaris provider adapter. Supported values are `S3`, `GCS`, and `AZURE`. The matching adapter is loaded from `platform/scripts/polaris_providers/`.

`POLARIS_STORAGE_REGION`
Required: no for the current S3 flow
Default: `us-east-1`
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: feeds the Polaris storage config region field for the current S3 implementation.

`POLARIS_GCS_SERVICE_ACCOUNT`
Required: yes when `POLARIS_STORAGE_TYPE=GCS`
Default: none
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: service account email Polaris should use for GCS-backed catalog storage.

`POLARIS_AZURE_TENANT_ID`
Required: yes when `POLARIS_STORAGE_TYPE=AZURE`
Default: none
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: Azure tenant ID for Polaris catalog storage access.

`POLARIS_AZURE_MULTI_TENANT_APP_NAME`
Required: yes when `POLARIS_STORAGE_TYPE=AZURE`
Default: none
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: Azure multi-tenant application name Polaris should use.

`POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS`
Required: yes when `POLARIS_STORAGE_TYPE=AZURE`
Default: none
Used by: `platform/scripts/50-bootstrap-polaris-reference.sh`
Notes: comma-separated Azure subscription IDs that Polaris should include in the storage config payload.

`POLARIS_USER_CLIENT_ID`
Required: yes for runtime secret creation
Default: none
Used by: `reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh`
Notes: runtime principal credential for Spark catalog access.

`POLARIS_USER_CLIENT_SECRET`
Required: yes for runtime secret creation
Default: none
Used by: `reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh`
Notes: runtime principal credential for Spark catalog access.

### Useful Optional Overrides

Most setups can use defaults. The overrides below are the ones you are most likely to use.

Infra and cluster selection:

- `TFVARS_FILE`
  Default: `infra/aws/terraform.tfvars`
- `AWS_REGION_OVERRIDE`
  Use if you want `10-connect-cluster.sh` to bypass Terraform-derived region discovery.
- `EKS_CLUSTER_NAME_OVERRIDE`
  Use if you want `10-connect-cluster.sh` to target a specific cluster name directly.

Platform component toggles:

- `ENABLE_AIRFLOW`, `ENABLE_SPARK`, `ENABLE_STRIMZI`, `ENABLE_MONITORING`, `ENABLE_METRICS_SERVER`, `ENABLE_POLARIS`
  Default: `true`
- `ENABLE_INGRESS`
  Default: `false`
- `ENABLE_JUPYTERHUB`
  Default: `true`
- `DISABLE_NODE_SELECTORS`
  Default: `false`

Ingress and UI hostnames:

- `UI_INGRESS_BASE_DOMAIN`
  Default: `platform.local`
- `GRAFANA_INGRESS_HOST`, `PROMETHEUS_INGRESS_HOST`, `AIRFLOW_INGRESS_HOST`, `POLARIS_INGRESS_HOST`, `JUPYTER_INGRESS_HOST`
  Default: `<service>.${UI_INGRESS_BASE_DOMAIN}`
- `GRAFANA_UI_SERVICE`, `PROMETHEUS_UI_SERVICE`
  Defaults: `kube-prometheus-stack-grafana`, `kube-prometheus-stack-prometheus`
- `AIRFLOW_UI_SERVICE`
  Default: `airflow-api-server`

Kafka flow:

- `KAFKA_NAMESPACE`
  Default: `kafka`
- `KAFKA_TOPIC`
  Default: `orders_raw`
- `KAFKA_CLIENT_POD`
  Default: `kafka-test-client`
- `KAFKA_BOOTSTRAP_SERVER`
  Default: in-cluster bootstrap service
- `EVENTS_FILE`
  Default: `reference-workloads/orders-reference/sample-data/sample-events.json`
- `MAX_MESSAGES`
  Default: `20`
- `KAFKA_READY_TIMEOUT`, `KAFKA_TOPIC_READY_TIMEOUT`, `KAFKA_TEST_CLIENT_READY_TIMEOUT`
  Defaults: `15m`, `5m`, `5m`

Polaris and reference workload:

- `POLARIS_NAMESPACE`
  Default: `polaris`
- `POLARIS_REALM`
  Default: `POLARIS`
- `POLARIS_ADMIN_TOOL_IMAGE`
  Default: `apache/polaris-admin-tool:1.3.0-incubating`
- `REFERENCE_BUCKET`
  Default: auto from Terraform output `lakehouse_bucket_name`
- `REFERENCE_CATALOG`
  Default: `polaris`
- `REFERENCE_BASE_LOCATION`
  Default: none; set explicitly for your chosen object-store backend
- `POLARIS_STORAGE_TYPE`
  Default: `S3`
- `POLARIS_STORAGE_REGION`
  Default: `us-east-1`
- `POLARIS_GCS_SERVICE_ACCOUNT`
  Default: empty; required for `POLARIS_STORAGE_TYPE=GCS`
- `POLARIS_AZURE_TENANT_ID`
  Default: empty; required for `POLARIS_STORAGE_TYPE=AZURE`
- `POLARIS_AZURE_MULTI_TENANT_APP_NAME`
  Default: empty; required for `POLARIS_STORAGE_TYPE=AZURE`
- `POLARIS_AZURE_CONSENTED_SUBSCRIPTION_IDS`
  Default: empty; required for `POLARIS_STORAGE_TYPE=AZURE`
- `POLARIS_S3_PATH_STYLE_ACCESS`
  Default: `false`

Runtime and validation:

- `SPARK_NAMESPACE`
  Default: `spark`
- `POLARIS_SECRET_NAME`
  Default: `reference-polaris-spark-credentials`
- `VALIDATION_TIMEOUT`
  Default: `300s`

## Prerequisites

Install or verify these first:

- AWS CLI
- Terraform
- `kubectl`
- Helm
- `jq`
- `curl`
- `tar`
- Java 21 runtime for Polaris CLI
- `envsubst` for Spark manifest rendering
- Docker if you want to build the repo-owned Spark image locally

Ubuntu (for Ubuntu-based EC2 instances):

```bash
sudo apt update
sudo apt install -y openjdk-21-jre-headless jq curl tar gettext-base unzip gnupg ca-certificates lsb-release
java --version
jq --version
```

Amazon Linux 2023 (alternate EC2 package commands):

```bash
sudo dnf install -y java-21-amazon-corretto-headless jq curl tar gettext unzip gnupg2 ca-certificates
java --version
jq --version
```

Install AWS CLI v2:

Ubuntu or Amazon Linux 2023:

```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
aws --version
```

If `aws` is already installed and you want to update it in place:

```bash
sudo ./aws/install --bin-dir /usr/local/bin --install-dir /usr/local/aws-cli --update
aws --version
```

Install Terraform:

Ubuntu:

```bash
wget -O - https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(grep -oP '(?<=UBUNTU_CODENAME=).*' /etc/os-release || lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update
sudo apt install -y terraform
terraform version
```

Amazon Linux 2023:

```bash
sudo yum install -y yum-utils shadow-utils
sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/AmazonLinux/hashicorp.repo
sudo yum install -y terraform
terraform version
```

Install `kubectl`:

Use a `kubectl` version within one minor version of the EKS cluster version. This repo currently uses EKS `1.34`, so the examples below install `kubectl` from the `1.34` package channel.

Ubuntu:

```bash
sudo mkdir -p -m 755 /etc/apt/keyrings
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.34/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.34/deb/ /' | sudo tee /etc/apt/sources.list.d/kubernetes.list
sudo apt update
sudo apt install -y kubectl
kubectl version --client
```

Amazon Linux 2023:

```bash
cat <<'EOF' | sudo tee /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.34/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.34/rpm/repodata/repomd.xml.key
EOF
sudo yum install -y kubectl
kubectl version --client
```

Install Helm:

Ubuntu:

```bash
curl -fsSL https://packages.buildkite.com/helm-linux/helm-debian/gpgkey | gpg --dearmor | sudo tee /usr/share/keyrings/helm.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/helm.gpg] https://packages.buildkite.com/helm-linux/helm-debian/any/ any main" | sudo tee /etc/apt/sources.list.d/helm-stable-debian.list
sudo apt update
sudo apt install -y helm
helm version
```

Amazon Linux 2023:

```bash
curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
chmod 700 get_helm.sh
./get_helm.sh
helm version
```

If Helm is still missing and you want the one-line installer:

```bash
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

## Install Polaris Admin Tool

The current local Polaris setup used by this repo installs the Polaris admin tool plus Java 21.
This is needed for the one-time root/admin bootstrap in `40-bootstrap-polaris-admin.sh`.

Important:

- the current binary layout we installed locally exposes `bin/admin` and `bin/server`
- `bin/admin` is for realm/root bootstrap and maintenance tasks
- this install is valid for `40-bootstrap-polaris-admin.sh`
- `50-bootstrap-polaris-reference.sh` now uses the Polaris REST APIs instead of a separate local Polaris catalog CLI
- for `50-bootstrap-polaris-reference.sh`, the important local tools are `kubectl`, `curl`, and `jq`

```bash
mkdir -p ~/tools
cd ~/tools
curl -L https://downloads.apache.org/incubator/polaris/1.3.0-incubating/polaris-bin-1.3.0-incubating.tgz | tar xz
mkdir -p ~/.local/bin
cat > ~/.local/bin/polaris <<'EOF'
#!/usr/bin/env bash
exec "$HOME/tools/polaris-bin-1.3.0-incubating/bin/admin" "$@"
EOF
chmod +x ~/.local/bin/polaris
export PATH="$HOME/.local/bin:$HOME/tools/polaris-bin-1.3.0-incubating/bin:$PATH"
polaris --help
```

Expected result:

- `polaris --help` should show the Polaris administration tool commands such as `bootstrap` and `purge`
- that confirms the admin tool is installed correctly for `40-bootstrap-polaris-admin.sh`

Use this wrapper for the admin/bootstrap flow in `40-bootstrap-polaris-admin.sh`.
The reference-workload Polaris bootstrap in `50-bootstrap-polaris-reference.sh` no longer depends on a separate local Polaris catalog CLI.

## End-To-End Setup Order

From the repo root:

```bash
./infra/aws/deploy-infra.sh
./infra/aws/deploy-infra.sh --apply --yes
./platform/scripts/aws/10-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
helm version
export POLARIS_DB_PASSWORD='polaris'
export PLATFORM_STORAGE_CLASS=gp3
cp platform/config/example.platform-secrets.env platform/config/platform-secrets.env
# Update JUPYTERHUB_SHARED_PASSWORD in platform/config/platform-secrets.env before deploy.
# Set any `ENABLE_*` overrides before running `20-deploy-platform.sh` if you want to change the default addon set.
./platform/scripts/20-deploy-platform.sh
./platform/scripts/60-validate-platform.sh
INSTALL_KAFKA_TEST_CLIENT=true ./platform/scripts/30-deploy-kafka.sh
./platform/scripts/60-validate-platform.sh
export POLARIS_ADMIN_CLIENT_ID='polaris-root'
export POLARIS_ADMIN_CLIENT_SECRET='change-this-secret'
./platform/scripts/40-bootstrap-polaris-admin.sh
./platform/scripts/50-bootstrap-polaris-reference.sh
./platform/scripts/70-validate-polaris-config.sh
```



## Step 1: Review And Apply Infrastructure

From repo root:

`./infra/aws/deploy-infra.sh` prepares and runs the AWS Terraform workflow for this prototype. The `--apply` form provisions the VPC, EKS cluster, node groups, IAM roles, IRSA trust wiring, and lakehouse bucket path used by the platform.

```bash
./infra/aws/deploy-infra.sh
./infra/aws/deploy-infra.sh --apply
```

During apply, the script:

- runs `terraform fmt -recursive`
- bootstraps networking first
- bootstraps the EKS control plane next
- updates IRSA trust policies from the cluster OIDC issuer
- then runs the full Terraform apply

After a successful apply, the script writes timestamped Terraform state backups into `infra/aws/bkp/`.

After infra apply succeeds, this is the right time to inspect Terraform outputs:

```bash
cd ~/work/dc-platform/infra/aws
terraform output -raw lakehouse_bucket_name
terraform output -raw eks_cluster_name
terraform output -json workload_identities | jq -r '.polaris.role_arn'
terraform output -json workload_identities | jq -r '.jupyter.role_arn // empty'
```

Important:

- you can reliably run these after `./infra/aws/deploy-infra.sh --apply` has completed successfully
- the current prototype bucket value has changed across earlier notes and sessions
- always trust the current `terraform.tfvars` and Terraform outputs over older docs

**ALWAYS SYNC THE BUCKET NAME FROM `infra/aws/terraform.tfvars` OR `terraform output -raw lakehouse_bucket_name` BEFORE ANY PLATFORM OR POLARIS BOOTSTRAP STEP.**

Where to look it up:

- primary source: `infra/aws/terraform.tfvars` field `lakehouse_bucket_name`
- preferred runtime check: `cd ~/work/dc-platform/infra/aws && terraform output -raw lakehouse_bucket_name`

Where platform uses it:

- `platform/scripts/50-bootstrap-polaris-reference.sh` resolves `REFERENCE_BUCKET` from Terraform output by default
- if you need to override it manually, set `export REFERENCE_BUCKET='<bucket-name>'`
- set `REFERENCE_BASE_LOCATION` explicitly for the storage backend you are using, for example:
  `export REFERENCE_BASE_LOCATION='s3://bucket/reference/'`
  `export REFERENCE_BASE_LOCATION='gs://bucket/reference/'`
  `export REFERENCE_BASE_LOCATION='abfss://container@account.dfs.core.windows.net/reference/'`

**ALWAYS SYNC THE POLARIS ROLE ARN FROM TERRAFORM OUTPUT BEFORE PLATFORM OR POLARIS BOOTSTRAP.**

Where to look it up:

- preferred structured check: `cd ~/work/dc-platform/infra/aws && terraform output -json workload_identities | jq -r '.polaris.role_arn'`
- related identity inventory: `infra/aws/terraform.tfvars` field `workload_identities.polaris`

Where platform uses it:

- `platform/scripts/20-deploy-platform.sh` prefers Terraform output `workload_identities` to annotate the `polaris/polaris-sa` service account and still accepts `POLARIS_S3_ROLE_ARN` as a manual fallback
- `platform/scripts/50-bootstrap-polaris-reference.sh` uses `POLARIS_ROLE_ARN` for the Polaris catalog storage config
- in this prototype those should refer to the same AWS IAM role
- if you need to set them manually, use:
  `export POLARIS_S3_ROLE_ARN='<polaris-role-arn>'`
  `export POLARIS_ROLE_ARN='<polaris-role-arn>'`

Useful diagnostics while apply is running:

```bash
aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto --query 'cluster.status' --output text
aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto
aws eks list-nodegroups --region us-east-1 --cluster-name dc-platform-bss-eks-proto
aws eks describe-addon --region us-east-1 --cluster-name dc-platform-bss-eks-proto --addon-name aws-ebs-csi-driver --query 'addon.status' --output text
```

## Step 2: Connect `kubectl` To The Cluster

`./platform/scripts/aws/10-connect-cluster.sh` reads the current AWS region and cluster name from the repo inputs and updates your kubeconfig. Run it after infra is ready so all later `kubectl` and Helm commands point at the correct cluster.

```bash
./platform/scripts/aws/10-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
```

Optional overrides:

```bash
export TFVARS_FILE=~/work/dc-platform/infra/aws/terraform.tfvars
export AWS_REGION_OVERRIDE=us-east-1
export EKS_CLUSTER_NAME_OVERRIDE=dc-platform-bss-eks-proto
./platform/scripts/aws/10-connect-cluster.sh
```

## Step 3: Deploy The Platform Layer

`./platform/scripts/20-deploy-platform.sh` installs the shared platform services and their base Kubernetes resources. This is the main bootstrap step for Strimzi, Spark Operator, Airflow, monitoring, and Polaris.

It also updates the shared non-secret handoff file at `platform/config/platform-config.env`. Later workload scripts consume that generated file instead of calling Terraform directly.
Structured workload identities are written alongside it at `platform/config/workload-identities.json`.

Required minimum input:

```bash
export POLARIS_DB_PASSWORD='polaris'
```

If you are using the new defaults, also create `platform/config/platform-secrets.env` from [example.platform-secrets.env](/home/ubuntu/work/dc-platform/platform/config/example.platform-secrets.env) so JupyterHub can read `JUPYTERHUB_SHARED_PASSWORD` automatically during platform deploy.

Optional but common overrides:

```bash
export PLATFORM_STORAGE_CLASS=gp3
export POLARIS_S3_ROLE_ARN='<polaris-role-arn>'
```

Run:

```bash
./platform/scripts/20-deploy-platform.sh
```

Set any `ENABLE_*` overrides before this step if you want to skip or include optional addons such as ingress or JupyterHub.

Spark runtime storage no longer uses `SPARK_S3_ROLE_ARN`. For direct Spark writes and Spark event logs, create the object-store Hadoop config secret in the Spark namespace before deploying workload jobs.

JupyterHub is enabled by default. Ingress is disabled by default for dev environments; use `platform/scripts/port-forward.sh` for local browser access, or set `ENABLE_INGRESS=true` if you intentionally want ingress resources installed. `port-forward.sh` is conservative and does not forward JupyterHub unless you set `ENABLE_JUPYTERHUB=true` in the shell you use to run it.

What this installs:

- namespaces and service accounts
- Strimzi operator
- Spark Operator
- Airflow
- Prometheus and Grafana
- metrics-server
- Polaris
- reference tenant namespace, service account, RBAC, and `iceberg-client-config` ConfigMap via `platform/tenants/reference/deploy.sh`
- ingress-nginx only if `ENABLE_INGRESS=true`
- UI ingress resources for Grafana, Prometheus, Airflow, and Polaris only if `ENABLE_INGRESS=true`
- JupyterHub and its ingress too unless `ENABLE_JUPYTERHUB=false`; Jupyter ingress also still depends on `ENABLE_INGRESS=true`

The script will try to resolve the Airflow, Polaris, and Jupyter role ARNs automatically from Terraform outputs. Export them manually only if local Terraform state is not available.

### Node Labels And Portable Scheduling

By default, the current AWS prototype expects nodes to carry the `NodeGroupType`
labels used by the EKS node-group layout:

- `NodeGroupType=core` for shared platform services
- `NodeGroupType=workload` for Spark jobs, Kafka test clients, and notebook workloads

If your cluster does not use those labels, set:

```bash
export DISABLE_NODE_SELECTORS=true
```

Do that before running platform deploy or the reference Spark workload deploy
scripts. With that flag set, the deploy scripts strip the `nodeSelector` and
related `affinity` blocks from the rendered YAML so the cluster scheduler can
place pods using its own defaults.

## Step 4: Validate The Platform Layer

`./platform/scripts/60-validate-platform.sh` checks that the deployed platform services are actually healthy and reachable enough to continue. Use it after platform install and again after Kafka deploy so readiness issues surface before you move into Polaris or Spark work.

```bash
./platform/scripts/60-validate-platform.sh
```

This now validates:

- node readiness
- Strimzi operator
- Spark Operator
- monitoring stack
- metrics-server
- Airflow
- Polaris
- Kafka cluster, node pools, and topics if Kafka has already been deployed

Optional timeout override:

```bash
export VALIDATION_TIMEOUT=600s
./platform/scripts/60-validate-platform.sh
```

## Step 5: Deploy And Validate Kafka

`./platform/scripts/30-deploy-kafka.sh` creates the shared Kafka cluster, node pools, reference topics, and optionally the Kafka test client pod. It waits for the Kafka cluster and topics to become ready before reporting success.

Recommended first run:

```bash
export KAFKA_STORAGE_CLASS=gp3   # optional; on AWS the profile already defaults this to gp3

INSTALL_KAFKA_TEST_CLIENT=true ./platform/scripts/30-deploy-kafka.sh

./platform/scripts/60-validate-platform.sh
```

The Kafka deploy script now waits for:

- the `reference-kafka` cluster to become `Ready`
- `orders-raw` and `orders-dlq` Kafka topics to become `Ready`
- the optional `kafka-test-client` pod to become `Ready` if requested

Useful Kafka inspection commands:

```bash
kubectl get kafka -n kafka
kubectl get kafkanodepool -n kafka
kubectl get kafkatopic -n kafka
kubectl get pods -n kafka -o wide
kubectl logs -n platform-system deployment/strimzi-cluster-operator --tail=300
kubectl describe kafka reference-kafka -n kafka
kubectl get kafkanodepool -n kafka -o yaml
kubectl get events -n kafka --sort-by=.lastTimestamp
kubectl get pvc -n kafka
```

## Step 6: Bootstrap Polaris Root/Admin Credentials

This is a one-time metastore bootstrap step for the Polaris realm.

`./platform/scripts/40-bootstrap-polaris-admin.sh` runs a one-off Polaris admin-tool pod against the live PostgreSQL metastore and bootstraps the Polaris realm with explicit root/admin credentials that you choose. This gives you stable admin credentials for later catalog bootstrap steps instead of relying on hidden or randomized internal credentials.

Why this step exists:

- Polaris internal authentication is enabled in this deployment
- the current Helm deployment path does not give you reusable root/admin credentials in a Kubernetes secret
- `50-bootstrap-polaris-reference.sh` needs valid Polaris admin credentials to create the `polaris` catalog and principal wiring

Pick the admin credentials you want to keep for this prototype:

```bash
export POLARIS_ADMIN_CLIENT_ID='polaris-root'
export POLARIS_ADMIN_CLIENT_SECRET='change-this-secret'
```

Run:

```bash
./platform/scripts/40-bootstrap-polaris-admin.sh
```

Optional overrides:

```bash
export POLARIS_NAMESPACE=polaris
export POLARIS_REALM=POLARIS
export POLARIS_PERSISTENCE_SECRET=polaris-persistence
export POLARIS_ADMIN_TOOL_IMAGE=apache/polaris-admin-tool:1.3.0-incubating
```

Important:

- run this after Polaris is deployed and healthy
- these are bootstrap-only admin credentials, not Spark runtime credentials
- keep these values; you will reuse them in the next step
- if you have not run this step yet, do it before attempting `50-bootstrap-polaris-reference.sh`

## Step 7: Bootstrap Polaris Catalog For The Reference Workload

`./platform/scripts/50-bootstrap-polaris-reference.sh` uses the Polaris admin credentials to create the shared `polaris` catalog, namespaces, and Spark principal wiring for the reference workload. This is the bridge between the shared platform layer and the workload-specific Spark catalog access path.

By default, the script resolves these from Terraform automatically:

- `POLARIS_ROLE_ARN` from `workload_identities.polaris.role_arn`
- `REFERENCE_BUCKET` from `lakehouse_bucket_name` when available
- `REFERENCE_BASE_LOCATION` set explicitly for your chosen object-store backend

Only export these manually if you want to override the defaults or if Terraform output is not available locally.

Run the bootstrap:

```bash
./platform/scripts/50-bootstrap-polaris-reference.sh
```

Important migration note:

- older environments may already have a Polaris catalog named `reference`
- this script now defaults `REFERENCE_CATALOG` to `polaris`
- rerunning bootstrap with the new default will create or validate a separate `polaris` catalog; it will not move data out of the older `reference` catalog
- if you need to keep using the older layout, run the bootstrap and validation steps with `REFERENCE_CATALOG=reference` until you deliberately migrate

What this creates or verifies:

- catalog `polaris`
- namespaces `bronze` and `silver`
- reference Spark principal
- principal role and catalog role wiring
- `CATALOG_MANAGE_CONTENT` on the `polaris` catalog
- local access to Polaris is handled through an on-demand `kubectl port-forward` if needed

If a new principal is created, the script prints:

```bash
export POLARIS_USER_CLIENT_ID=...
export POLARIS_USER_CLIENT_SECRET=...
```

Save those immediately for the runtime secret step.

## Step 8: Validate Polaris Reference Configuration

`./platform/scripts/70-validate-polaris-config.sh` verifies that the Polaris configuration work from `40-bootstrap-polaris-admin.sh` and `50-bootstrap-polaris-reference.sh` is really present, not just that the Polaris pods are running. This is the focused check for the reference-workload catalog wiring before you move on to Spark runtime secret creation.

Run:

```bash
./platform/scripts/70-validate-polaris-config.sh
```

This checks:

- admin authentication works
- catalog `polaris` exists
- namespaces `bronze` and `silver` exist
- principal `reference_spark_user` exists
- principal role `reference_spark_role` exists
- catalog role `reference_catalog_role` exists
- the principal is bound to the principal role
- the principal role is bound to the catalog role
- the catalog role has `CATALOG_MANAGE_CONTENT`

## Step 9: Verify Kafka Produce/Consume Helpers

`10-load-orders-events-to-kafka.sh` copies the sample events file into the Kafka test client pod and produces those records into `orders_raw`. `15-check-orders-events-in-kafka.sh` then consumes records back out so you can confirm the reference topic is usable before Spark runs.

Load the sample events:

```bash
./reference-workloads/orders-reference/scripts/10-load-orders-events-to-kafka.sh
```

Verify the events:

```bash
./reference-workloads/orders-reference/scripts/15-check-orders-events-in-kafka.sh
MAX_MESSAGES=5 ./reference-workloads/orders-reference/scripts/15-check-orders-events-in-kafka.sh
```

## Step 10: Create Polaris Runtime Secret For Spark

`20-create-orders-polaris-runtime-secret.sh` stores the reference Spark principal credentials in a Kubernetes secret in the `spark` namespace. The curated-to-Iceberg Spark job reads these credentials from that secret at runtime.

Use the Spark runtime principal credentials from the bootstrap step:

```bash
export POLARIS_USER_CLIENT_ID='<reference-spark-client-id>'
export POLARIS_USER_CLIENT_SECRET='<reference-spark-client-secret>'
./reference-workloads/orders-reference/scripts/20-create-orders-polaris-runtime-secret.sh
```

Optional overrides:

```bash
export SPARK_NAMESPACE=spark
export POLARIS_SECRET_NAME=reference-polaris-spark-credentials
```

## Step 11: Build And Push The Reference Spark Image

The local Docker build packages the repo-owned Spark jobs into one reusable runtime image. That image is then referenced by the shell deploy scripts and by the Airflow DAG.

Build locally:

```bash
docker build -t dc-platform-reference-spark:0.1 reference-workloads/orders-reference
```

Tag and push:

```bash
docker tag dc-platform-reference-spark:0.1 <your-registry>/dc-platform-reference-spark:0.1
docker push <your-registry>/dc-platform-reference-spark:0.1
```

Then export:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
```

## Step 12: Run The Orders Reference Spark Flow

`25-deploy-orders-kafka-to-raw.sh`, `30-deploy-orders-raw-to-curated.sh`, and `35-deploy-orders-curated-to-iceberg.sh` each render and submit one SparkApplication manifest. Together they run the staged reference pipeline from Kafka to raw, raw to curated, and curated to Iceberg through Polaris.

Smoke test Spark first if desired:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
envsubst < reference-workloads/orders-reference/spark/manifests/spark-app-sparkpi.yaml | kubectl apply -f -
```

Run the staged orders path:

```bash
./reference-workloads/orders-reference/scripts/25-deploy-orders-kafka-to-raw.sh
./reference-workloads/orders-reference/scripts/30-deploy-orders-raw-to-curated.sh
./reference-workloads/orders-reference/scripts/35-deploy-orders-curated-to-iceberg.sh
```

Useful checks:

```bash
kubectl get sparkapplications -n spark
kubectl describe sparkapplication reference-orders-kafka-to-raw -n spark
kubectl get pods -n spark -l sparkoperator.k8s.io/app-name=reference-orders-kafka-to-raw
```

## Airflow Note

Airflow is intended to orchestrate the staged orders path through:

- `reference-workloads/orders-reference/airflow/bundle/orders_reference.py`

Before running the DAG, make sure:

- the shared platform and Kafka prerequisites are complete
- the runtime secret `reference-polaris-spark-credentials` exists in namespace `spark`
- the Airflow deployment includes the DAG file and the neighboring Spark manifests
- the Airflow Variable `reference_spark_image` is set to your pushed image

## JupyterHub

JupyterHub is enabled by default. Before the main platform deploy, create `platform/config/platform-secrets.env` from [example.platform-secrets.env](/home/ubuntu/work/dc-platform/platform/config/example.platform-secrets.env), then set at least:

- `JUPYTERHUB_SHARED_PASSWORD`

If you also want the sample notebook to test Polaris catalog access, make sure Step 7 has already printed and you have saved:

- `POLARIS_USER_CLIENT_ID`
- `POLARIS_USER_CLIENT_SECRET`

If you previously deployed without it, enable JupyterHub by rerunning platform deploy:

```bash
ENABLE_JUPYTERHUB=true ./platform/scripts/20-deploy-platform.sh
```

If you need to turn both JupyterHub and ingress back on explicitly, use:

```bash
ENABLE_INGRESS=true ENABLE_JUPYTERHUB=true ./platform/scripts/20-deploy-platform.sh
```

Access it locally:

```bash
kubectl port-forward -n jupyter svc/proxy-public 8080:80
```

Then open `http://127.0.0.1:8080`.

Login behavior for this prototype:

- use any username you want
- use the shared password from `JUPYTERHUB_SHARED_PASSWORD`

After login, start the notebook server and open:

- `/home/jovyan/examples/reference-platform-smoke.ipynb`

That sample notebook checks the environment, starts a local Spark session, and tests Polaris namespace access. It is prepared for Polaris/Iceberg access by default. Direct object-store reads such as `s3a://...` are no longer preloaded with AWS-specific connector packages; load any extra connector packages explicitly in the notebook or a custom image if you want to test those paths interactively.

## Access Service UIs

For local dev, use the repo-owned port-forward helper instead of ingress.

Recommended dev access flow:

```bash
./platform/scripts/port-forward.sh
```

That script starts background `kubectl port-forward` sessions for the enabled services and keeps running until you press `Ctrl-C`. By default it exposes:

- Grafana: `http://127.0.0.1:3000`
- Prometheus: `http://127.0.0.1:9090`
- Airflow: `http://127.0.0.1:8080`
- Polaris: `http://127.0.0.1:18181`

To include JupyterHub too, run:

```bash
ENABLE_JUPYTERHUB=true ./platform/scripts/port-forward.sh
```

You can override the local ports if needed:

```bash
export GRAFANA_LOCAL_PORT=13000
export AIRFLOW_LOCAL_PORT=18080
./platform/scripts/port-forward.sh
```

If you do want ingress for a shared or more staging-like environment, enable it explicitly before deploy:

```bash
export ENABLE_INGRESS=true
export GRAFANA_INGRESS_HOST=grafana.example.internal
export PROMETHEUS_INGRESS_HOST=prometheus.example.internal
export AIRFLOW_INGRESS_HOST=airflow.example.internal
export POLARIS_INGRESS_HOST=polaris.example.internal
export JUPYTER_INGRESS_HOST=jupyter.example.internal
export AIRFLOW_UI_SERVICE=airflow-api-server
./platform/scripts/20-deploy-platform.sh
```

Ingress endpoints when enabled:

- Grafana: `http://${GRAFANA_INGRESS_HOST:-grafana.platform.local}`
- Prometheus: `http://${PROMETHEUS_INGRESS_HOST:-prometheus.platform.local}`
- Airflow: `http://${AIRFLOW_INGRESS_HOST:-airflow.platform.local}`
- Polaris: `http://${POLARIS_INGRESS_HOST:-polaris.platform.local}`
- JupyterHub: `http://${JUPYTER_INGRESS_HOST:-jupyter.platform.local}` when `ENABLE_JUPYTERHUB=true`

You can inspect the ingress controller endpoint with:

```bash
kubectl get svc -n ingress-nginx ingress-nginx-controller
kubectl get ingress -A
```

The helper script is the preferred dev path, but the equivalent manual commands are:

```bash
kubectl port-forward -n monitoring svc/kube-prometheus-stack-grafana 3000:80
kubectl port-forward -n monitoring svc/kube-prometheus-stack-prometheus 9090:9090
kubectl port-forward -n airflow svc/airflow-api-server 8080:8080
kubectl port-forward -n polaris svc/polaris 18181:8181
kubectl port-forward -n jupyter svc/proxy-public 8888:80
```

Spark UI is separate because it is tied to a running Spark driver pod rather than a long-lived shared service. Use:

```bash
./platform/scripts/spark-port-forward.sh <spark-application-name>
```

Example:

```bash
./platform/scripts/spark-port-forward.sh reference-orders-kafka-to-raw
```

Then open:

```text
http://127.0.0.1:4040
```

Notes:

- `metrics-server` has no normal web UI; it is mainly for `kubectl top` and autoscaling support.
- Kafka and Strimzi do not expose a web UI in this repo by default.
- if you rename the monitoring Helm release or service names, override `GRAFANA_UI_SERVICE` and `PROMETHEUS_UI_SERVICE` before redeploying the ingress layer
- if your environment uses a different Airflow UI service name, override `AIRFLOW_UI_SERVICE` before redeploying the platform ingress layer
- if you later want TLS, cert-manager, or authenticated edge ingress, add the needed annotations and `tls:` blocks to the manifests under [platform/addons/ui-ingress](/home/ubuntu/work/dc-platform/platform/addons/ui-ingress)

## Cleanup

When you want to remove the platform layer but keep AWS infra:

```bash
./platform/scripts/90-cleanup-platform.sh --yes
```

When you want to destroy the AWS prototype environment:

```bash
./infra/aws/destroy-infra.sh --yes
```
