# Unified Setup Guide

This is the primary operator setup runbook for the current AWS EKS prototype.

Use this document first when you need to:

- prepare or review the AWS infrastructure inputs
- deploy the platform layer
- deploy and validate Kafka
- install Polaris CLI prerequisites
- bootstrap the shared Polaris reference catalog
- run the first orders reference workload steps

The older docs under `infra/aws-proto/` and `platform/scripts/` still contain useful context, but this file is the main end-to-end setup guide.

## Parameters To Review First

Review these before you deploy anything.

### Terraform Inputs In `infra/aws-proto/terraform.tfvars`

These are the main infrastructure parameters you are expected to review or change for a new environment.

`project_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `dc-platform-bss`
Why: naming prefix for AWS resources.

`environment`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `proto`
Why: environment suffix used in naming.

`aws_region`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `us-east-1`
Why: AWS region for the prototype.

`vpc_cidr`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `10.0.0.0/16`
Why: VPC address space.

`availability_zones`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `["us-east-1a", "us-east-1b"]`
Why: AZ placement for subnets and nodes.

`private_subnet_cidrs`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file values
Why: private subnet ranges.

`public_subnet_cidrs`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file values
Why: public subnet ranges.

`eks_cluster_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `dc-platform-bss-eks-proto`
Why: cluster name used by AWS and kubeconfig update flow.

`eks_cluster_version`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `1.34`
Why: EKS control plane version.

`node_instance_types`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `["t3.medium"]`
Why: workload node group instance types.

`node_desired_size`, `node_min_size`, `node_max_size`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `2 / 2 / 3`
Why: workload node scaling bounds.

`node_disk_size`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `50`
Why: workload node root disk size in GiB.

`core_node_instance_types`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `["t3.medium"]`
Why: core platform node group instance types.

`core_node_desired_size`, `core_node_min_size`, `core_node_max_size`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `2 / 2 / 2`
Why: core node scaling bounds.

`core_node_disk_size`
Where: `infra/aws-proto/terraform.tfvars`
Current example: `50`
Why: core node root disk size in GiB.

`eks_cluster_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IAM role name for the EKS control plane.

`eks_node_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IAM role name for managed node groups.

`lakehouse_bucket_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: shared S3 lakehouse bucket used by Spark, Airflow, and Polaris.

`ebs_csi_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IRSA role for the EBS CSI driver.

`polaris_s3_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IRSA role name for Polaris S3 access.

`spark_s3_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IRSA role name for Spark S3 access.

`airflow_s3_role_name`
Where: `infra/aws-proto/terraform.tfvars`
Current example: current file value
Why: IRSA role name for Airflow S3 access.

### Core Environment Variables Used During Setup

These are the main shell parameters to check before each stage.

`POLARIS_DB_PASSWORD`
Required: yes for platform deploy
Default: none
Used by: `platform/scripts/03-0-deploy-platform.sh`
Notes: required when Polaris is enabled.

`PLATFORM_STORAGE_CLASS`
Required: no
Default: `gp2`
Used by: `platform/scripts/03-0-deploy-platform.sh`
Notes: controls Airflow PostgreSQL, Prometheus, and Polaris PostgreSQL persistence class.

`KAFKA_STORAGE_CLASS`
Required: no
Default: `PLATFORM_STORAGE_CLASS`, then `gp2`
Used by: `platform/scripts/03-1-deploy-kafka.sh`
Notes: overrides Kafka node pool PVC storage class if needed.

`SPARK_S3_ROLE_ARN`
Required: sometimes
Default: auto from Terraform output
Used by: `platform/scripts/03-0-deploy-platform.sh`
Notes: export manually if Terraform state is not available locally.

`AIRFLOW_S3_ROLE_ARN`
Required: sometimes
Default: auto from Terraform output
Used by: `platform/scripts/03-0-deploy-platform.sh`
Notes: same note as above.

`POLARIS_S3_ROLE_ARN`
Required: sometimes
Default: auto from Terraform output
Used by: `platform/scripts/03-0-deploy-platform.sh`
Notes: same note as above.

`INSTALL_KAFKA_TEST_CLIENT`
Required: no
Default: `false`
Used by: `platform/scripts/03-1-deploy-kafka.sh`
Notes: set to `true` if you want the helper pod for produce/consume testing.

`REFERENCE_SPARK_IMAGE`
Required: yes for Spark workload deploys
Default: none
Used by: orders workload scripts and Airflow DAG
Notes: registry image for the repo-owned Spark runtime.

`POLARIS_ADMIN_CLIENT_ID`
Required: yes for Polaris bootstrap
Default: none
Used by: `platform/scripts/03-4-bootstrap-polaris-admin.sh` and `platform/scripts/03-5-bootstrap-polaris-reference.sh`
Notes: admin credentials used only for bootstrap.

`POLARIS_ADMIN_CLIENT_SECRET`
Required: yes for Polaris bootstrap
Default: none
Used by: `platform/scripts/03-4-bootstrap-polaris-admin.sh` and `platform/scripts/03-5-bootstrap-polaris-reference.sh`
Notes: admin credentials used only for bootstrap.

`POLARIS_ROLE_ARN`
Required: yes for Polaris bootstrap
Default: auto from `POLARIS_S3_ROLE_ARN`, otherwise Terraform output `polaris_s3_role_arn`
Used by: `platform/scripts/03-5-bootstrap-polaris-reference.sh`
Notes: role ARN Polaris should vend for catalog storage access. In this prototype it should match the Polaris IRSA role used during platform deploy.

`POLARIS_USER_CLIENT_ID`
Required: yes for runtime secret creation
Default: none
Used by: `reference-workloads/orders-reference/scripts/create-orders-polaris-runtime-secret.sh`
Notes: runtime principal credential for Spark catalog access.

`POLARIS_USER_CLIENT_SECRET`
Required: yes for runtime secret creation
Default: none
Used by: `reference-workloads/orders-reference/scripts/create-orders-polaris-runtime-secret.sh`
Notes: runtime principal credential for Spark catalog access.

### Useful Optional Overrides

These are not usually required for the happy path, but they are configurable.

`TF_DIR`
Default: `infra/aws-proto`
Used by: infra deploy script and platform deploy script.

`TF_PLAN_FILE`
Default: `tfplan`
Used by: `infra/aws-proto/deploy-infra.sh`.

`BKP_DIR`
Default: `infra/aws-proto/bkp`
Used by: `infra/aws-proto/deploy-infra.sh`.

`TFVARS_FILE`
Default: `infra/aws-proto/terraform.tfvars`
Used by: `platform/scripts/02-connect-cluster.sh`.

`AWS_REGION_OVERRIDE`
Default: none
Used by: `platform/scripts/02-connect-cluster.sh`.

`EKS_CLUSTER_NAME_OVERRIDE`
Default: none
Used by: `platform/scripts/02-connect-cluster.sh`.

`ENABLE_AIRFLOW`
Default: `true`
Used by: platform deploy.

`ENABLE_SPARK`
Default: `true`
Used by: platform deploy.

`ENABLE_STRIMZI`
Default: `true`
Used by: platform deploy.

`ENABLE_INGRESS`
Default: `false`
Used by: platform deploy.

`ENABLE_MONITORING`
Default: `true`
Used by: platform deploy.

`ENABLE_POLARIS`
Default: `true`
Used by: platform deploy.

`KAFKA_READY_TIMEOUT`
Default: `15m`
Used by: Kafka deploy.

`KAFKA_TOPIC_READY_TIMEOUT`
Default: `5m`
Used by: Kafka deploy.

`KAFKA_TEST_CLIENT_READY_TIMEOUT`
Default: `5m`
Used by: Kafka deploy.

`VALIDATION_TIMEOUT`
Default: `300s`
Used by: platform validation.

`KAFKA_NAMESPACE`
Default: `kafka`
Used by: Kafka deploy, validation, loader, checker.

`KAFKA_TOPIC`
Default: `orders_raw`
Used by: loader and checker scripts.

`KAFKA_CLIENT_POD`
Default: `kafka-test-client`
Used by: loader and checker scripts.

`KAFKA_BOOTSTRAP_SERVER`
Default: in-cluster bootstrap service
Used by: loader and checker scripts.

`EVENTS_FILE`
Default: `reference-workloads/data/sample-events.json`
Used by: Kafka loader.

`MAX_MESSAGES`
Default: `20`
Used by: Kafka checker.

`POLARIS_HOST`
Default: `polaris.polaris.svc.cluster.local`
Used by: Polaris bootstrap.

`POLARIS_PORT`
Default: `8181`
Used by: Polaris bootstrap.

`POLARIS_NAMESPACE`
Default: `polaris`
Used by: Polaris admin bootstrap.

`POLARIS_REALM`
Default: `POLARIS`
Used by: Polaris admin bootstrap.

`POLARIS_PERSISTENCE_SECRET`
Default: `polaris-persistence`
Used by: Polaris admin bootstrap.

`POLARIS_ADMIN_TOOL_IMAGE`
Default: `apache/polaris-admin-tool:1.3.0-incubating`
Used by: Polaris admin bootstrap.

`REFERENCE_BUCKET`
Default: auto from Terraform output `lakehouse_bucket_name`
Used by: Polaris bootstrap.

`REFERENCE_CATALOG`
Default: `reference`
Used by: Polaris bootstrap.

`REFERENCE_BASE_LOCATION`
Default: `s3://<bucket>/reference/`
Used by: Polaris bootstrap.

`REFERENCE_ALLOWED_LOCATION`
Default: same as `REFERENCE_BASE_LOCATION`
Used by: Polaris bootstrap.

`REFERENCE_PRINCIPAL`
Default: `reference_spark_user`
Used by: Polaris bootstrap.

`REFERENCE_PRINCIPAL_ROLE`
Default: `reference_spark_role`
Used by: Polaris bootstrap.

`REFERENCE_CATALOG_ROLE`
Default: `reference_catalog_role`
Used by: Polaris bootstrap.

`SPARK_NAMESPACE`
Default: `spark`
Used by: runtime secret creation and curated-to-Iceberg deploy.

`POLARIS_SECRET_NAME`
Default: `reference-polaris-spark-credentials`
Used by: runtime secret creation and curated-to-Iceberg deploy.

## Prerequisites

Install or verify these first:

- AWS CLI
- Terraform
- `kubectl`
- Helm
- `jq`
- `curl`
- `tar`
- Java 21 runtime for Polaris CLI
- `envsubst` for Spark manifest rendering
- Docker if you want to build the repo-owned Spark image locally

Ubuntu:

```bash
sudo apt update
sudo apt install -y openjdk-21-jre-headless jq curl tar gettext-base
java --version
jq --version
```

If Helm is missing:

```bash
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

## Install Polaris Admin Tool

The current local Polaris setup used by this repo installs the Polaris admin tool plus Java 21.
This is needed for the one-time root/admin bootstrap in `03-4-bootstrap-polaris-admin.sh`.

Important:

- the current binary layout we installed locally exposes `bin/admin` and `bin/server`
- `bin/admin` is for realm/root bootstrap and maintenance tasks
- this install is valid for `03-4-bootstrap-polaris-admin.sh`
- `03-5-bootstrap-polaris-reference.sh` now uses the Polaris REST APIs instead of a separate local Polaris catalog CLI
- for `03-5`, the important local tools are `kubectl`, `curl`, and `jq`

```bash
mkdir -p ~/tools
cd ~/tools
curl -L https://downloads.apache.org/incubator/polaris/1.3.0-incubating/polaris-bin-1.3.0-incubating.tgz | tar xz
mkdir -p ~/.local/bin
cat > ~/.local/bin/polaris <<'EOF'
#!/usr/bin/env bash
exec "$HOME/tools/polaris-bin-1.3.0-incubating/bin/admin" "$@"
EOF
chmod +x ~/.local/bin/polaris
export PATH="$HOME/.local/bin:$HOME/tools/polaris-bin-1.3.0-incubating/bin:$PATH"
polaris --help
```

Expected result:

- `polaris --help` should show the Polaris administration tool commands such as `bootstrap` and `purge`
- that confirms the admin tool is installed correctly for `03-4-bootstrap-polaris-admin.sh`

Use this wrapper for the admin/bootstrap flow in `03-4-bootstrap-polaris-admin.sh`.
The reference-catalog bootstrap in `03-5-bootstrap-polaris-reference.sh` no longer depends on a separate local Polaris catalog CLI.

## End-To-End Setup Order

From the repo root:

```bash
./infra/aws-proto/deploy-infra.sh
./infra/aws-proto/deploy-infra.sh --apply
./platform/scripts/02-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
helm version
export POLARIS_DB_PASSWORD='polaris'
export PLATFORM_STORAGE_CLASS=gp3   # optional; omit to keep gp2 default
./platform/scripts/03-0-deploy-platform.sh
./platform/scripts/04-validate-platform.sh
INSTALL_KAFKA_TEST_CLIENT=true ./platform/scripts/03-1-deploy-kafka.sh
./platform/scripts/04-validate-platform.sh
export POLARIS_ADMIN_CLIENT_ID='polaris-root'
export POLARIS_ADMIN_CLIENT_SECRET='change-this-secret'
./platform/scripts/03-4-bootstrap-polaris-admin.sh
export POLARIS_ROLE_ARN="$(cd ~/work/dc-platform/infra/aws-proto && terraform output -raw polaris_s3_role_arn)"
export REFERENCE_BUCKET="$(cd ~/work/dc-platform/infra/aws-proto && terraform output -raw lakehouse_bucket_name)"
export REFERENCE_BASE_LOCATION="s3://${REFERENCE_BUCKET}/reference/"
./platform/scripts/03-5-bootstrap-polaris-reference.sh
./platform/scripts/04-1-validate-polaris-config.sh
```

## Step 1: Review And Apply Infrastructure

From repo root:

`./infra/aws-proto/deploy-infra.sh` prepares and runs the AWS Terraform workflow for this prototype. The `--apply` form provisions the VPC, EKS cluster, node groups, IAM roles, IRSA trust wiring, and lakehouse bucket path used by the platform.

```bash
./infra/aws-proto/deploy-infra.sh
./infra/aws-proto/deploy-infra.sh --apply
```

During apply, the script:

- runs `terraform fmt -recursive`
- bootstraps networking first
- bootstraps the EKS control plane next
- updates IRSA trust policies from the cluster OIDC issuer
- then runs the full Terraform apply

After a successful apply, the script writes timestamped Terraform state backups into `infra/aws-proto/bkp/`.

After infra apply succeeds, this is the right time to inspect Terraform outputs:

```bash
cd ~/work/dc-platform/infra/aws-proto
terraform output -raw lakehouse_bucket_name
terraform output -raw eks_cluster_name
terraform output -raw spark_s3_role_arn
terraform output -raw airflow_s3_role_arn
terraform output -raw polaris_s3_role_arn
```

Important:

- you can reliably run these after `./infra/aws-proto/deploy-infra.sh --apply` has completed successfully
- the current prototype bucket value has changed across earlier notes and sessions
- always trust the current `terraform.tfvars` and Terraform outputs over older docs

**ALWAYS SYNC THE BUCKET NAME FROM `infra/aws-proto/terraform.tfvars` OR `terraform output -raw lakehouse_bucket_name` BEFORE ANY PLATFORM OR POLARIS BOOTSTRAP STEP.**

Where to look it up:

- primary source: `infra/aws-proto/terraform.tfvars` field `lakehouse_bucket_name`
- preferred runtime check: `cd ~/work/dc-platform/infra/aws-proto && terraform output -raw lakehouse_bucket_name`

Where platform uses it:

- `platform/scripts/03-5-bootstrap-polaris-reference.sh` resolves `REFERENCE_BUCKET` from Terraform output by default
- if you need to override it manually, set `export REFERENCE_BUCKET='<bucket-name>'`
- if you set paths manually, keep `REFERENCE_BASE_LOCATION` aligned too:
  `export REFERENCE_BASE_LOCATION="s3://${REFERENCE_BUCKET}/reference/"`

**ALWAYS SYNC THE POLARIS ROLE ARN FROM TERRAFORM OUTPUT BEFORE PLATFORM OR POLARIS BOOTSTRAP.**

Where to look it up:

- preferred runtime check: `cd ~/work/dc-platform/infra/aws-proto && terraform output -raw polaris_s3_role_arn`
- related naming input: `infra/aws-proto/terraform.tfvars` field `polaris_s3_role_name`

Where platform uses it:

- `platform/scripts/03-0-deploy-platform.sh` uses `POLARIS_S3_ROLE_ARN` to annotate the `polaris/polaris-sa` service account
- `platform/scripts/03-5-bootstrap-polaris-reference.sh` uses `POLARIS_ROLE_ARN` for the Polaris catalog storage config
- in this prototype those should refer to the same AWS IAM role
- if you need to set them manually, use:
  `export POLARIS_S3_ROLE_ARN='<polaris-role-arn>'`
  `export POLARIS_ROLE_ARN='<polaris-role-arn>'`

Useful diagnostics while apply is running:

```bash
aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto --query 'cluster.status' --output text
aws eks describe-cluster --region us-east-1 --name dc-platform-bss-eks-proto
aws eks list-nodegroups --region us-east-1 --cluster-name dc-platform-bss-eks-proto
aws eks describe-addon --region us-east-1 --cluster-name dc-platform-bss-eks-proto --addon-name aws-ebs-csi-driver --query 'addon.status' --output text
```

## Step 2: Connect `kubectl` To The Cluster

`./platform/scripts/02-connect-cluster.sh` reads the current AWS region and cluster name from the repo inputs and updates your kubeconfig. Run it after infra is ready so all later `kubectl` and Helm commands point at the correct cluster.

```bash
./platform/scripts/02-connect-cluster.sh
kubectl get nodes
kubectl get pods -n kube-system
```

Optional overrides:

```bash
export TFVARS_FILE=~/work/dc-platform/infra/aws-proto/terraform.tfvars
export AWS_REGION_OVERRIDE=us-east-1
export EKS_CLUSTER_NAME_OVERRIDE=dc-platform-bss-eks-proto
./platform/scripts/02-connect-cluster.sh
```

## Step 3: Deploy The Platform Layer

`./platform/scripts/03-0-deploy-platform.sh` installs the shared platform services and their base Kubernetes resources. This is the main bootstrap step for Strimzi, Spark Operator, Airflow, monitoring, and Polaris.

Required minimum input:

```bash
export POLARIS_DB_PASSWORD='polaris'
```

Optional but common overrides:

```bash
export PLATFORM_STORAGE_CLASS=gp3
export SPARK_S3_ROLE_ARN='<spark-role-arn>'
export AIRFLOW_S3_ROLE_ARN='<airflow-role-arn>'
export POLARIS_S3_ROLE_ARN='<polaris-role-arn>'
```

Run:

```bash
./platform/scripts/03-0-deploy-platform.sh
```

What this installs:

- namespaces and service accounts
- Strimzi operator
- Spark Operator
- Airflow
- Prometheus and Grafana
- Polaris
- ingress only if `ENABLE_INGRESS=true`

The script will try to resolve the Spark, Airflow, and Polaris role ARNs automatically from Terraform outputs. Export them manually only if local Terraform state is not available.

## Step 4: Validate The Platform Layer

`./platform/scripts/04-validate-platform.sh` checks that the deployed platform services are actually healthy and reachable enough to continue. Use it after platform install and again after Kafka deploy so readiness issues surface before you move into Polaris or Spark work.

```bash
./platform/scripts/04-validate-platform.sh
```

This now validates:

- node readiness
- Strimzi operator
- Spark Operator
- monitoring stack
- Airflow
- Polaris
- Kafka cluster, node pools, and topics if Kafka has already been deployed

Optional timeout override:

```bash
export VALIDATION_TIMEOUT=600s
./platform/scripts/04-validate-platform.sh
```

## Step 5: Deploy And Validate Kafka

`./platform/scripts/03-1-deploy-kafka.sh` creates the shared Kafka cluster, node pools, reference topics, and optionally the Kafka test client pod. It waits for the Kafka cluster and topics to become ready before reporting success.

Recommended first run:

```bash
export KAFKA_STORAGE_CLASS=gp3   # optional; otherwise follows PLATFORM_STORAGE_CLASS or gp2

INSTALL_KAFKA_TEST_CLIENT=true ./platform/scripts/03-1-deploy-kafka.sh

./platform/scripts/04-validate-platform.sh
```

The Kafka deploy script now waits for:

- the `reference-kafka` cluster to become `Ready`
- `orders-raw` and `orders-dlq` Kafka topics to become `Ready`
- the optional `kafka-test-client` pod to become `Ready` if requested

Useful Kafka inspection commands:

```bash
kubectl get kafka -n kafka
kubectl get kafkanodepool -n kafka
kubectl get kafkatopic -n kafka
kubectl get pods -n kafka -o wide
kubectl logs -n platform-system deployment/strimzi-cluster-operator --tail=300
kubectl describe kafka reference-kafka -n kafka
kubectl get kafkanodepool -n kafka -o yaml
kubectl get events -n kafka --sort-by=.lastTimestamp
kubectl get pvc -n kafka
```

## Step 6: Bootstrap Polaris Root/Admin Credentials

This is a one-time metastore bootstrap step for the Polaris realm.

`./platform/scripts/03-4-bootstrap-polaris-admin.sh` runs a one-off Polaris admin-tool pod against the live PostgreSQL metastore and bootstraps the Polaris realm with explicit root/admin credentials that you choose. This gives you stable admin credentials for later catalog bootstrap steps instead of relying on hidden or randomized internal credentials.

Why this step exists:

- Polaris internal authentication is enabled in this deployment
- the current Helm deployment path does not give you reusable root/admin credentials in a Kubernetes secret
- `03-5-bootstrap-polaris-reference.sh` needs valid Polaris admin credentials to create the reference catalog and principal wiring

Pick the admin credentials you want to keep for this prototype:

```bash
export POLARIS_ADMIN_CLIENT_ID='polaris-root'
export POLARIS_ADMIN_CLIENT_SECRET='change-this-secret'
```

Run:

```bash
./platform/scripts/03-4-bootstrap-polaris-admin.sh
```

Optional overrides:

```bash
export POLARIS_NAMESPACE=polaris
export POLARIS_REALM=POLARIS
export POLARIS_PERSISTENCE_SECRET=polaris-persistence
export POLARIS_ADMIN_TOOL_IMAGE=apache/polaris-admin-tool:1.3.0-incubating
```

Important:

- run this after Polaris is deployed and healthy
- these are bootstrap-only admin credentials, not Spark runtime credentials
- keep these values; you will reuse them in the next step
- if you have not run this step yet, do it before attempting `03-5-bootstrap-polaris-reference.sh`

## Step 7: Bootstrap Polaris Reference Catalog

`./platform/scripts/03-5-bootstrap-polaris-reference.sh` uses the Polaris admin credentials to create the shared `reference` catalog, namespaces, and Spark principal wiring. This is the bridge between the shared platform layer and the workload-specific Spark catalog access path.

Get the Polaris storage role ARN from Terraform if you have not already exported it:

```bash
cd ~/work/dc-platform/infra/aws-proto
terraform output -raw polaris_s3_role_arn
```

Export the bootstrap inputs:

```bash
export POLARIS_ROLE_ARN='<polaris-irsa-role-arn>'
export REFERENCE_BUCKET="$(cd ~/work/dc-platform/infra/aws-proto && terraform output -raw lakehouse_bucket_name)"
export REFERENCE_BASE_LOCATION="s3://${REFERENCE_BUCKET}/reference/"
```

Run the bootstrap:

```bash
./platform/scripts/03-5-bootstrap-polaris-reference.sh
```

What this creates or verifies:

- catalog `reference`
- namespaces `bronze` and `silver`
- reference Spark principal
- principal role and catalog role wiring
- `CATALOG_MANAGE_CONTENT` on the reference catalog
- local access to Polaris is handled through an on-demand `kubectl port-forward` if needed

If a new principal is created, the script prints:

```bash
export POLARIS_USER_CLIENT_ID=...
export POLARIS_USER_CLIENT_SECRET=...
```

Save those immediately for the runtime secret step.

## Step 8: Validate Polaris Reference Configuration

`./platform/scripts/04-1-validate-polaris-config.sh` verifies that the Polaris configuration work from `03-4` and `03-5` is really present, not just that the Polaris pods are running. This is the focused check for the reference catalog wiring before you move on to Spark runtime secret creation.

Run:

```bash
./platform/scripts/04-1-validate-polaris-config.sh
```

This checks:

- admin authentication works
- catalog `reference` exists
- namespaces `bronze` and `silver` exist
- principal `reference_spark_user` exists
- principal role `reference_spark_role` exists
- catalog role `reference_catalog_role` exists
- the principal is bound to the principal role
- the principal role is bound to the catalog role
- the catalog role has `CATALOG_MANAGE_CONTENT`

## Step 9: Verify Kafka Produce/Consume Helpers

`load-orders-events-to-kafka.sh` copies the sample events file into the Kafka test client pod and produces those records into `orders_raw`. `check-orders-events-in-kafka.sh` then consumes records back out so you can confirm the reference topic is usable before Spark runs.

Load the sample events:

```bash
./reference-workloads/orders-reference/scripts/load-orders-events-to-kafka.sh
```

Verify the events:

```bash
./reference-workloads/orders-reference/scripts/check-orders-events-in-kafka.sh
MAX_MESSAGES=5 ./reference-workloads/orders-reference/scripts/check-orders-events-in-kafka.sh
```

## Step 10: Create Polaris Runtime Secret For Spark

`create-orders-polaris-runtime-secret.sh` stores the reference Spark principal credentials in a Kubernetes secret in the `spark` namespace. The curated-to-Iceberg Spark job reads these credentials from that secret at runtime.

Use the Spark runtime principal credentials from the bootstrap step:

```bash
export POLARIS_USER_CLIENT_ID='<reference-spark-client-id>'
export POLARIS_USER_CLIENT_SECRET='<reference-spark-client-secret>'
./reference-workloads/orders-reference/scripts/create-orders-polaris-runtime-secret.sh
```

Optional overrides:

```bash
export SPARK_NAMESPACE=spark
export POLARIS_SECRET_NAME=reference-polaris-spark-credentials
```

## Step 10: Build And Push The Reference Spark Image

The local Docker build packages the repo-owned Spark jobs into one reusable runtime image. That image is then referenced by the shell deploy scripts and by the Airflow DAG.

Build locally:

```bash
docker build -t dc-platform-reference-spark:0.1 reference-workloads/orders-reference
```

Tag and push:

```bash
docker tag dc-platform-reference-spark:0.1 <your-registry>/dc-platform-reference-spark:0.1
docker push <your-registry>/dc-platform-reference-spark:0.1
```

Then export:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
```

## Step 11: Run The Orders Reference Spark Flow

`deploy-orders-kafka-to-raw.sh`, `deploy-orders-raw-to-curated.sh`, and `deploy-orders-curated-to-iceberg.sh` each render and submit one SparkApplication manifest. Together they run the staged reference pipeline from Kafka to raw, raw to curated, and curated to Iceberg through Polaris.

Smoke test Spark first if desired:

```bash
export REFERENCE_SPARK_IMAGE='<your-registry>/dc-platform-reference-spark:0.1'
envsubst < reference-workloads/shared/spark/manifests/spark-app-sparkpi.yaml | kubectl apply -f -
```

Run the staged orders path:

```bash
./reference-workloads/orders-reference/scripts/deploy-orders-kafka-to-raw.sh
./reference-workloads/orders-reference/scripts/deploy-orders-raw-to-curated.sh
./reference-workloads/orders-reference/scripts/deploy-orders-curated-to-iceberg.sh
```

Useful checks:

```bash
kubectl get sparkapplications -n spark
kubectl describe sparkapplication reference-orders-kafka-to-raw -n spark
kubectl get pods -n spark -l sparkoperator.k8s.io/app-name=reference-orders-kafka-to-raw
```

## Airflow Note

Airflow is intended to orchestrate the staged orders path through:

- `reference-workloads/orders-reference/airflow/dag-orders-reference.py`

Before running the DAG, make sure:

- the shared platform and Kafka prerequisites are complete
- the runtime secret `reference-polaris-spark-credentials` exists in namespace `spark`
- the Airflow deployment includes the DAG file and the neighboring Spark manifests
- the Airflow Variable `reference_spark_image` is set to your pushed image

## Cleanup

When you want to remove the platform layer but keep AWS infra:

```bash
./platform/scripts/06-cleanup-platform.sh --yes
```

When you want to destroy the AWS prototype environment:

```bash
./infra/aws-proto/destroy-infra.sh --yes
```
